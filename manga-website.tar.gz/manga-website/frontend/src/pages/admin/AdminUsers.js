// AdminUsers.js
import React, { useState, useEffect } from 'react';
import axios from '../../utils/axios';
import { toast } from 'react-toastify';
import { FiShield, FiSlash, FiSearch } from 'react-icons/fi';

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');

  useEffect(() => {
    const fetch = async () => {
      try {
        const res = await axios.get('/api/admin/users');
        setUsers(res.data.users || mockUsers);
      } catch { setUsers(mockUsers); } finally { setLoading(false); }
    };
    fetch();
  }, []);

  const banUser = async (id, banned) => {
    try {
      await axios.put(`/api/admin/users/${id}`, { banned });
      setUsers(prev => prev.map(u => u._id === id ? { ...u, banned } : u));
      toast.success(banned ? 'Pengguna di-ban' : 'Ban dicabut');
    } catch { toast.error('Gagal'); }
  };

  const filtered = users.filter(u => !query || u.name?.toLowerCase().includes(query.toLowerCase()) || u.email?.toLowerCase().includes(query.toLowerCase()));

  return (
    <div style={{ minHeight: '100vh', paddingTop: '64px' }}>
      <div style={{ background: 'var(--bg-secondary)', borderBottom: '1px solid var(--border-color)', padding: '24px 32px' }}>
        <h1 style={{ fontSize: 24 }}>Kelola Pengguna</h1>
      </div>
      <div style={{ maxWidth: 1000, margin: '0 auto', padding: 24 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 8, padding: '0 12px', marginBottom: 20 }}>
          <FiSearch style={{ color: 'var(--text-muted)' }} />
          <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Cari nama atau email..." style={{ flex: 1, background: 'transparent', border: 'none', padding: '12px 0', color: 'var(--text-primary)', fontSize: 14 }} />
        </div>
        <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 12, overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border-color)' }}>
                {['Pengguna', 'Email', 'Status VIP', 'Bergabung', 'Aksi'].map(h => (
                  <th key={h} style={{ padding: '12px 16px', textAlign: 'left', fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(u => (
                <tr key={u._id} style={{ borderBottom: '1px solid rgba(255,255,255,0.03)' }}>
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <img src={u.avatar || `https://ui-avatars.com/api/?name=${u.name}&background=333&color=fff&size=32`} style={{ width: 32, height: 32, borderRadius: '50%' }} alt={u.name} />
                      <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-primary)' }}>{u.name}</span>
                      {u.banned && <span style={{ fontSize: 10, padding: '1px 6px', background: 'rgba(230,57,70,0.2)', color: 'var(--accent-primary)', borderRadius: 4, fontWeight: 700 }}>BAN</span>}
                    </div>
                  </td>
                  <td style={{ padding: '12px 16px', fontSize: 13, color: 'var(--text-muted)' }}>{u.email}</td>
                  <td style={{ padding: '12px 16px' }}>
                    {u.subscription?.tier === 'vip_plus' ? <span style={{ fontSize: 11, padding: '2px 8px', background: 'var(--gradient-vip-plus)', color: 'white', borderRadius: 4, fontWeight: 700 }}>VIP+</span> :
                     u.subscription?.tier === 'vip' ? <span style={{ fontSize: 11, padding: '2px 8px', background: 'var(--gradient-vip)', color: 'white', borderRadius: 4, fontWeight: 700 }}>VIP</span> :
                     <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>Member</span>}
                  </td>
                  <td style={{ padding: '12px 16px', fontSize: 12, color: 'var(--text-muted)' }}>{new Date(u.createdAt).toLocaleDateString('id-ID')}</td>
                  <td style={{ padding: '12px 16px' }}>
                    <button onClick={() => banUser(u._id, !u.banned)}
                      style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '5px 10px', background: u.banned ? 'rgba(34,197,94,0.1)' : 'rgba(230,57,70,0.1)', border: '1px solid', borderColor: u.banned ? 'rgba(34,197,94,0.3)' : 'rgba(230,57,70,0.3)', borderRadius: 6, color: u.banned ? '#22c55e' : 'var(--accent-primary)', fontSize: 12, cursor: 'pointer' }}>
                      {u.banned ? <><FiShield /> Unban</> : <><FiSlash /> Ban</>}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

const mockUsers = Array(15).fill(0).map((_, i) => ({
  _id: String(i), name: `Pengguna ${i + 1}`, email: `user${i + 1}@example.com`, avatar: null,
  subscription: { tier: i % 5 === 0 ? 'vip_plus' : i % 3 === 0 ? 'vip' : null },
  banned: i === 7, createdAt: new Date(Date.now() - i * 30 * 86400000)
}));
