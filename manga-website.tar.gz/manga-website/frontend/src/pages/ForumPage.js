import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from '../utils/axios';
import { useAuth } from '../context/AuthContext';
import { FiMessageSquare, FiPlus, FiEye, FiHeart } from 'react-icons/fi';
import { toast } from 'react-toastify';
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import 'dayjs/locale/id';
dayjs.extend(relativeTime);
dayjs.locale('id');

export default function ForumPage() {
  const { isLoggedIn } = useAuth();
  const navigate = useNavigate();
  const [threads, setThreads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [category, setCategory] = useState('semua');
  const [showCreate, setShowCreate] = useState(false);
  const [newThread, setNewThread] = useState({ title: '', content: '', category: 'diskusi' });

  const categories = ['semua', 'diskusi', 'rekomendasi', 'spoiler', 'pertanyaan', 'pengumuman'];

  useEffect(() => {
    const fetch = async () => {
      setLoading(true);
      try {
        const res = await axios.get(`/api/forum?category=${category}`);
        setThreads(res.data.threads || mockThreads);
      } catch { setThreads(mockThreads); } finally { setLoading(false); }
    };
    fetch();
  }, [category]);

  const createThread = async () => {
    if (!newThread.title.trim() || !newThread.content.trim()) return;
    try {
      const res = await axios.post('/api/forum', newThread);
      setThreads(prev => [res.data.thread, ...prev]);
      setShowCreate(false);
      setNewThread({ title: '', content: '', category: 'diskusi' });
      toast.success('Thread berhasil dibuat!');
    } catch {
      toast.error('Gagal membuat thread');
    }
  };

  return (
    <div style={{ minHeight: '100vh', paddingTop: '64px' }}>
      <div style={{ background: 'var(--bg-secondary)', borderBottom: '1px solid var(--border-color)', padding: '40px 24px' }}>
        <div style={{ maxWidth: 900, margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h1 style={{ fontSize: 32, marginBottom: 4 }}>Forum Diskusi</h1>
            <p style={{ color: 'var(--text-secondary)', fontSize: 15 }}>Diskusi, rekomendasi, dan berbagi tentang manga favoritmu</p>
          </div>
          {isLoggedIn && (
            <button onClick={() => setShowCreate(!showCreate)} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 20px', background: 'var(--gradient-primary)', color: 'white', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer' }}>
              <FiPlus /> Buat Thread
            </button>
          )}
        </div>
      </div>

      <div style={{ maxWidth: 900, margin: '0 auto', padding: '32px 24px 60px' }}>
        {showCreate && (
          <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 12, padding: 24, marginBottom: 24 }}>
            <h3 style={{ marginBottom: 16 }}>Buat Thread Baru</h3>
            <input value={newThread.title} onChange={e => setNewThread(p => ({ ...p, title: e.target.value }))}
              placeholder="Judul thread..." style={{ width: '100%', padding: '10px 14px', background: 'var(--bg-elevated)', border: '1px solid var(--border-color)', borderRadius: 8, color: 'var(--text-primary)', fontSize: 15, marginBottom: 12 }} />
            <textarea value={newThread.content} onChange={e => setNewThread(p => ({ ...p, content: e.target.value }))}
              placeholder="Isi thread..." rows={4} style={{ width: '100%', padding: '10px 14px', background: 'var(--bg-elevated)', border: '1px solid var(--border-color)', borderRadius: 8, color: 'var(--text-primary)', fontSize: 14, marginBottom: 12, resize: 'vertical' }} />
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <button onClick={() => setShowCreate(false)} style={{ padding: '8px 16px', background: 'transparent', border: '1px solid var(--border-color)', borderRadius: 8, color: 'var(--text-secondary)', cursor: 'pointer' }}>Batal</button>
              <button onClick={createThread} style={{ padding: '8px 16px', background: 'var(--gradient-primary)', color: 'white', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer' }}>Posting</button>
            </div>
          </div>
        )}

        <div style={{ display: 'flex', gap: 8, marginBottom: 24, flexWrap: 'wrap' }}>
          {categories.map(c => (
            <button key={c} onClick={() => setCategory(c)}
              style={{ padding: '6px 16px', borderRadius: 100, border: '1px solid', borderColor: category === c ? 'var(--accent-primary)' : 'var(--border-color)', background: category === c ? 'rgba(230,57,70,0.1)' : 'transparent', color: category === c ? 'var(--accent-primary)' : 'var(--text-secondary)', fontSize: 13, cursor: 'pointer', textTransform: 'capitalize' }}>
              {c}
            </button>
          ))}
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {loading ? Array(8).fill(0).map((_, i) => <div key={i} className="skeleton" style={{ height: 90, borderRadius: 8 }} />) :
            threads.map(t => (
              <Link key={t._id} to={`/forum/${t._id}`} style={{ display: 'flex', gap: 16, padding: 16, background: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 8, textDecoration: 'none', transition: 'background 0.2s' }}>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
                    <span style={{ padding: '2px 10px', background: 'rgba(230,57,70,0.1)', color: 'var(--accent-primary)', borderRadius: 4, fontSize: 11, fontWeight: 700, textTransform: 'uppercase' }}>{t.category}</span>
                  </div>
                  <h3 style={{ fontSize: 15, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 6, fontFamily: 'Noto Sans, sans-serif' }}>{t.title}</h3>
                  <p style={{ fontSize: 13, color: 'var(--text-muted)', display: '-webkit-box', WebkitLineClamp: 1, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{t.content}</p>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4, flexShrink: 0 }}>
                  <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{dayjs(t.createdAt).fromNow()}</span>
                  <div style={{ display: 'flex', gap: 8, fontSize: 12, color: 'var(--text-muted)' }}>
                    <span><FiMessageSquare /> {t.replyCount || 0}</span>
                    <span><FiEye /> {t.views || 0}</span>
                  </div>
                  <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{t.author?.name}</span>
                </div>
              </Link>
            ))
          }
        </div>
      </div>
    </div>
  );
}

const mockThreads = Array(12).fill(0).map((_, i) => ({
  _id: String(i), title: `Thread Diskusi Menarik ${i + 1}`,
  content: 'Isi dari thread ini sangat menarik dan penuh informasi tentang manga favorit kita semua.',
  category: ['diskusi', 'rekomendasi', 'spoiler', 'pertanyaan'][i % 4],
  author: { name: `User ${i + 1}` }, replyCount: Math.floor(Math.random() * 50),
  views: Math.floor(Math.random() * 500), createdAt: new Date(Date.now() - i * 86400000)
}));
