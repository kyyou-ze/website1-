import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from '../utils/axios';
import MangaCard from '../components/manga/MangaCard';
import { FiHeart } from 'react-icons/fi';

export default function FavoritePage() {
  const [favorites, setFavorites] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      try {
        const res = await axios.get('/api/user/favorites');
        setFavorites(res.data.favorites || []);
      } catch { setFavorites([]); } finally { setLoading(false); }
    };
    fetch();
  }, []);

  return (
    <div style={{ minHeight: '100vh', paddingTop: '64px' }}>
      <div className="container" style={{ paddingTop: 40, paddingBottom: 60 }}>
        <h1 className="section-title" style={{ marginBottom: 32 }}>
          <FiHeart /> Favorit Saya ({favorites.length})
        </h1>
        {loading ? (
          <div className="grid-manga">{Array(12).fill(0).map((_, i) => <div key={i} className="skeleton" style={{ aspectRatio: '2/3', borderRadius: 8 }} />)}</div>
        ) : favorites.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '80px 24px', color: 'var(--text-muted)' }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>❤️</div>
            <p>Belum ada favorit. <Link to="/search" style={{ color: 'var(--accent-primary)' }}>Cari manga</Link> dan tambahkan!</p>
          </div>
        ) : (
          <div className="grid-manga">{favorites.map(m => <MangaCard key={m._id} manga={m} />)}</div>
        )}
      </div>
    </div>
  );
}
