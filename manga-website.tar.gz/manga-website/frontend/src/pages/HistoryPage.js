import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from '../utils/axios';
import { FiClock, FiTrash2 } from 'react-icons/fi';
import { toast } from 'react-toastify';
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import 'dayjs/locale/id';
dayjs.extend(relativeTime);
dayjs.locale('id');

export default function HistoryPage() {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetch = async () => {
      try {
        const res = await axios.get('/api/user/history');
        setHistory(res.data.history || mockHistory);
      } catch { setHistory(mockHistory); } finally { setLoading(false); }
    };
    fetch();
  }, []);

  const clearHistory = async () => {
    if (!window.confirm('Hapus semua riwayat baca?')) return;
    try {
      await axios.delete('/api/user/history');
      setHistory([]);
      toast.success('Riwayat dihapus');
    } catch {}
  };

  return (
    <div style={{ minHeight: '100vh', paddingTop: '64px' }}>
      <div className="container" style={{ paddingTop: 40, paddingBottom: 60 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 32 }}>
          <h1 className="section-title"><FiClock /> Riwayat Baca ({history.length})</h1>
          {history.length > 0 && (
            <button onClick={clearHistory} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 16px', background: 'transparent', border: '1px solid var(--border-color)', borderRadius: 8, color: 'var(--accent-primary)', cursor: 'pointer' }}>
              <FiTrash2 /> Hapus Semua
            </button>
          )}
        </div>
        {loading ? (
          Array(8).fill(0).map((_, i) => <div key={i} className="skeleton" style={{ height: 80, borderRadius: 8, marginBottom: 8 }} />)
        ) : history.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '80px 24px', color: 'var(--text-muted)' }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>📖</div>
            <p>Belum ada riwayat baca. Mulai baca manga!</p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {history.map(item => (
              <div key={item._id} onClick={() => navigate(`/manga/${item.manga?.slug}/chapter/${item.chapterId}`)}
                style={{ display: 'flex', gap: 12, padding: 12, background: 'var(--bg-card)', borderRadius: 8, cursor: 'pointer', transition: 'background 0.2s' }}
              >
                <img src={item.manga?.cover} alt={item.manga?.title} style={{ width: 48, height: 64, objectFit: 'cover', borderRadius: 4 }} />
                <div style={{ flex: 1 }}>
                  <p style={{ fontWeight: 600, marginBottom: 4, fontSize: 14 }}>{item.manga?.title}</p>
                  <p style={{ color: 'var(--accent-primary)', fontSize: 13 }}>Chapter {item.chapterNumber}</p>
                </div>
                <span style={{ fontSize: 12, color: 'var(--text-muted)', alignSelf: 'center' }}>{dayjs(item.readAt).fromNow()}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

const mockHistory = Array(8).fill(0).map((_, i) => ({
  _id: String(i), chapterId: String(i), chapterNumber: 50 - i, readAt: new Date(Date.now() - i * 86400000),
  manga: { title: `Manga Title ${i + 1}`, slug: `manga-title-${i + 1}`, cover: `https://via.placeholder.com/48x64/16161f/e63946?text=M` }
}));
