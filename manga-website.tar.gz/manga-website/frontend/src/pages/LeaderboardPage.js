import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from '../utils/axios';
import { FiAward, FiStar, FiEye } from 'react-icons/fi';
import styles from './LeaderboardPage.module.css';

const PERIODS = [
  { value: 'weekly', label: 'Minggu Ini' },
  { value: 'monthly', label: 'Bulan Ini' },
  { value: 'alltime', label: 'Sepanjang Masa' },
];

export default function LeaderboardPage() {
  const [manga, setManga] = useState([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState('weekly');

  useEffect(() => {
    const fetch = async () => {
      setLoading(true);
      try {
        const res = await axios.get(`/api/manga/leaderboard?period=${period}&limit=50`);
        setManga(res.data.manga || mockData);
      } catch { setManga(mockData); } finally { setLoading(false); }
    };
    fetch();
  }, [period]);

  const rankEmoji = (rank) => {
    if (rank === 1) return '🥇';
    if (rank === 2) return '🥈';
    if (rank === 3) return '🥉';
    return rank;
  };

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div className={styles.headerBg} />
        <div className={styles.headerContent}>
          <FiAward className={styles.headerIcon} />
          <h1>Peringkat Manga</h1>
          <p>Manga paling populer berdasarkan jumlah pembaca</p>
        </div>
      </div>

      <div className={styles.content}>
        <div className={styles.periodTabs}>
          {PERIODS.map(p => (
            <button
              key={p.value}
              className={`${styles.periodTab} ${period === p.value ? styles.active : ''}`}
              onClick={() => setPeriod(p.value)}
            >
              {p.label}
            </button>
          ))}
        </div>

        <div className={styles.list}>
          {loading ? (
            Array(20).fill(0).map((_, i) => <div key={i} className={`skeleton ${styles.itemSkeleton}`} />)
          ) : manga.map((m, i) => (
            <Link key={m._id} to={`/manga/${m.slug}`} className={`${styles.item} ${i < 3 ? styles.topItem : ''}`}>
              <span className={`${styles.rank} ${i === 0 ? styles.gold : i === 1 ? styles.silver : i === 2 ? styles.bronze : ''}`}>
                {rankEmoji(i + 1)}
              </span>
              <img src={m.cover} alt={m.title} className={styles.cover} />
              <div className={styles.info}>
                <h3 className={styles.title}>{m.title}</h3>
                <div className={styles.genres}>
                  {m.genres?.slice(0, 2).map(g => <span key={g} className={styles.genre}>{g}</span>)}
                </div>
                <div className={styles.stats}>
                  <span><FiEye /> {m.views?.toLocaleString('id-ID')} pembaca</span>
                  <span><FiStar /> {m.rating?.toFixed(1)}</span>
                  <span>📖 Ch. {m.totalChapters}</span>
                </div>
              </div>
              <div className={styles.viewsBig}>{(m.views / 1000).toFixed(0)}K</div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}

const mockData = Array(30).fill(0).map((_, i) => ({
  _id: String(i), title: `Manga Populer ${i + 1}`, slug: `manga-populer-${i + 1}`,
  cover: `https://via.placeholder.com/60x80/16161f/e63946?text=${i + 1}`,
  views: Math.floor((30 - i) * 150000 + Math.random() * 50000),
  rating: parseFloat((9.5 - i * 0.1).toFixed(1)),
  totalChapters: Math.floor(Math.random() * 200 + 50),
  genres: ['Action', 'Fantasy'],
}));
