import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from '../utils/axios';
import MangaCard from '../components/manga/MangaCard';
import { FiTrendingUp, FiClock, FiStar, FiAward, FiChevronRight, FiPlay } from 'react-icons/fi';
import styles from './HomePage.module.css';
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import 'dayjs/locale/id';
dayjs.extend(relativeTime);
dayjs.locale('id');

export default function HomePage() {
  const [featured, setFeatured] = useState([]);
  const [latestUpdates, setLatestUpdates] = useState([]);
  const [popular, setPopular] = useState([]);
  const [newManga, setNewManga] = useState([]);
  const [leaderboard, setLeaderboard] = useState([]);
  const [activeGenre, setActiveGenre] = useState('Semua');
  const [loading, setLoading] = useState(true);
  const [heroIndex, setHeroIndex] = useState(0);

  const genres = ['Semua', 'Action', 'Romance', 'Fantasy', 'Comedy', 'Horror', 'Slice of Life', 'Sci-Fi', 'Sports'];

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    if (featured.length === 0) return;
    const interval = setInterval(() => {
      setHeroIndex(prev => (prev + 1) % featured.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [featured]);

  const fetchData = async () => {
    try {
      const [featuredRes, latestRes, popularRes, newRes, leaderRes] = await Promise.all([
        axios.get('/api/manga/featured'),
        axios.get('/api/manga/latest?limit=18'),
        axios.get('/api/manga/popular?limit=12'),
        axios.get('/api/manga/new?limit=12'),
        axios.get('/api/manga/leaderboard?limit=5'),
      ]);
      setFeatured(featuredRes.data.manga || mockFeatured);
      setLatestUpdates(latestRes.data.manga || mockManga);
      setPopular(popularRes.data.manga || mockManga);
      setNewManga(newRes.data.manga || mockManga);
      setLeaderboard(leaderRes.data.manga || mockLeaderboard);
    } catch {
      setFeatured(mockFeatured);
      setLatestUpdates(mockManga);
      setPopular(mockManga);
      setNewManga(mockManga);
      setLeaderboard(mockLeaderboard);
    } finally {
      setLoading(false);
    }
  };

  const hero = featured[heroIndex];

  return (
    <div className={styles.page}>
      {/* Hero Section */}
      {hero && (
        <section className={styles.hero}>
          <div
            className={styles.heroBg}
            style={{ backgroundImage: `url(${hero.cover})` }}
          />
          <div className={styles.heroOverlay} />
          <div className={styles.heroContent}>
            <div className={styles.heroMeta}>
              {hero.genres?.slice(0, 3).map(g => (
                <span key={g} className={styles.heroGenre}>{g}</span>
              ))}
              {hero.isVIPOnly && <span className={`${styles.heroGenre} ${styles.heroVip}`}>VIP</span>}
            </div>
            <h1 className={styles.heroTitle}>{hero.title}</h1>
            <p className={styles.heroDesc}>{hero.description?.slice(0, 180)}...</p>
            <div className={styles.heroStats}>
              <span>⭐ {hero.rating?.toFixed(1)}</span>
              <span>📖 {hero.totalChapters} Chapter</span>
              <span>{hero.status === 'ongoing' ? '🟢 Ongoing' : '🔵 Tamat'}</span>
            </div>
            <div className={styles.heroActions}>
              <Link to={`/manga/${hero.slug}`} className={styles.heroBtnPrimary}>
                <FiPlay /> Baca Sekarang
              </Link>
              <Link to={`/manga/${hero.slug}`} className={styles.heroBtnSecondary}>
                Detail
              </Link>
            </div>
          </div>

          {/* Hero Indicators */}
          <div className={styles.heroIndicators}>
            {featured.map((_, i) => (
              <button
                key={i}
                className={`${styles.indicator} ${i === heroIndex ? styles.indicatorActive : ''}`}
                onClick={() => setHeroIndex(i)}
              />
            ))}
          </div>
        </section>
      )}

      <div className={styles.mainContent}>
        {/* Latest Updates */}
        <section className={styles.section}>
          <div className={styles.sectionHeader}>
            <h2 className="section-title">
              <FiClock /> Update Terbaru
            </h2>
            <Link to="/search?sort=latest" className={styles.seeAll}>
              Lihat Semua <FiChevronRight />
            </Link>
          </div>
          <div className={styles.latestList}>
            {loading ? (
              Array(8).fill(0).map((_, i) => <div key={i} className={`skeleton ${styles.latestSkeleton}`} />)
            ) : latestUpdates.slice(0, 8).map(manga => (
              <LatestItem key={manga._id} manga={manga} />
            ))}
          </div>
        </section>

        {/* Genre Filter + Popular */}
        <section className={styles.section}>
          <div className={styles.sectionHeader}>
            <h2 className="section-title">
              <FiTrendingUp /> Manga Populer
            </h2>
            <Link to="/search?sort=popular" className={styles.seeAll}>
              Lihat Semua <FiChevronRight />
            </Link>
          </div>
          <div className={styles.genreFilter}>
            {genres.map(g => (
              <button
                key={g}
                className={`${styles.genreBtn} ${activeGenre === g ? styles.genreActive : ''}`}
                onClick={() => setActiveGenre(g)}
              >
                {g}
              </button>
            ))}
          </div>
          <div className="grid-manga">
            {loading ? (
              Array(12).fill(0).map((_, i) => <div key={i} className={`skeleton ${styles.cardSkeleton}`} />)
            ) : popular.map(manga => (
              <MangaCard key={manga._id} manga={manga} />
            ))}
          </div>
        </section>

        {/* Two Column: New + Leaderboard */}
        <div className={styles.twoCol}>
          <section className={styles.section}>
            <div className={styles.sectionHeader}>
              <h2 className="section-title">
                <FiStar /> Manga Baru
              </h2>
              <Link to="/search?sort=new" className={styles.seeAll}>
                Lihat Semua <FiChevronRight />
              </Link>
            </div>
            <div className={styles.grid4}>
              {loading ? (
                Array(8).fill(0).map((_, i) => <div key={i} className={`skeleton ${styles.cardSkeleton}`} />)
              ) : newManga.slice(0, 8).map(manga => (
                <MangaCard key={manga._id} manga={manga} />
              ))}
            </div>
          </section>

          <section className={styles.section}>
            <div className={styles.sectionHeader}>
              <h2 className="section-title">
                <FiAward /> Peringkat Teratas
              </h2>
              <Link to="/leaderboard" className={styles.seeAll}>
                Lihat Semua <FiChevronRight />
              </Link>
            </div>
            <div className={styles.leaderboardList}>
              {loading ? (
                Array(5).fill(0).map((_, i) => <div key={i} className={`skeleton ${styles.leaderSkeleton}`} />)
              ) : leaderboard.map((manga, i) => (
                <LeaderboardItem key={manga._id} manga={manga} rank={i + 1} />
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}

function LatestItem({ manga }) {
  return (
    <Link to={`/manga/${manga.slug}`} className={styles.latestItem}>
      <img src={manga.cover} alt={manga.title} className={styles.latestCover} />
      <div className={styles.latestInfo}>
        <h4 className={styles.latestTitle}>{manga.title}</h4>
        {manga.latestChapters?.map(ch => (
          <div key={ch._id} className={styles.chapterRow}>
            <span className={styles.chapterNum}>Chapter {ch.number}</span>
            {ch.isVIPOnly && <span className={styles.chVip}>VIP</span>}
            <span className={styles.chapterTime}>{dayjs(ch.createdAt).fromNow()}</span>
          </div>
        ))}
      </div>
    </Link>
  );
}

function LeaderboardItem({ manga, rank }) {
  const rankColors = ['#ffd700', '#c0c0c0', '#cd7f32'];
  return (
    <Link to={`/manga/${manga.slug}`} className={styles.leaderItem}>
      <span
        className={styles.rank}
        style={{ color: rankColors[rank - 1] || 'var(--text-muted)' }}
      >
        {rank <= 3 ? '🏆' : rank}
      </span>
      <img src={manga.cover} alt={manga.title} className={styles.leaderCover} />
      <div className={styles.leaderInfo}>
        <h4>{manga.title}</h4>
        <div className={styles.leaderStats}>
          <span>⭐ {manga.rating?.toFixed(1)}</span>
          <span>👁 {manga.views?.toLocaleString('id-ID')}</span>
        </div>
      </div>
    </Link>
  );
}

// Mock data for development
const mockFeatured = [
  {
    _id: '1', title: 'Judul Manga Keren', slug: 'judul-manga-keren',
    cover: 'https://via.placeholder.com/1280x720/1a1a2e/e63946?text=Manga+Cover',
    description: 'Ini adalah deskripsi singkat dari manga yang sangat menarik dan penuh aksi serta petualangan yang tidak terduga.',
    rating: 9.2, totalChapters: 152, status: 'ongoing',
    genres: ['Action', 'Fantasy', 'Adventure'], isVIPOnly: false
  }
];

const mockManga = Array(12).fill(0).map((_, i) => ({
  _id: String(i), title: `Manga Title ${i + 1}`, slug: `manga-title-${i + 1}`,
  cover: `https://via.placeholder.com/200x300/16161f/e63946?text=Manga+${i + 1}`,
  rating: (Math.random() * 2 + 7).toFixed(1),
  totalChapters: Math.floor(Math.random() * 200 + 10),
  status: Math.random() > 0.5 ? 'ongoing' : 'completed',
  genres: ['Action', 'Fantasy'],
  latestChapter: { number: Math.floor(Math.random() * 200), createdAt: new Date() }
}));

const mockLeaderboard = mockManga.slice(0, 5).map((m, i) => ({
  ...m, views: Math.floor(Math.random() * 1000000 + 100000)
}));
