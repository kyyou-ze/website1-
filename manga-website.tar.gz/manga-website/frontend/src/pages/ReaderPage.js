import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import axios from '../utils/axios';
import { useAuth } from '../context/AuthContext';
import {
  FiChevronLeft, FiChevronRight, FiSettings, FiX,
  FiList, FiMaximize, FiMinimize, FiHome
} from 'react-icons/fi';
import { toast } from 'react-toastify';
import styles from './ReaderPage.module.css';

const READ_MODES = {
  HORIZONTAL: 'horizontal',
  VERTICAL: 'vertical',
  WEBTOON: 'webtoon',
};

export default function ReaderPage() {
  const { slug, chapterId } = useParams();
  const { isLoggedIn } = useAuth();
  const navigate = useNavigate();

  const [chapter, setChapter] = useState(null);
  const [pages, setPages] = useState([]);
  const [currentPage, setCurrentPage] = useState(0);
  const [readMode, setReadMode] = useState(
    localStorage.getItem('readMode') || READ_MODES.VERTICAL
  );
  const [loading, setLoading] = useState(true);
  const [showControls, setShowControls] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [prevChapter, setPrevChapter] = useState(null);
  const [nextChapter, setNextChapter] = useState(null);
  const [mangaTitle, setMangaTitle] = useState('');
  const [imgQuality, setImgQuality] = useState('high');
  const [bgColor, setBgColor] = useState('#0a0a0f');
  const containerRef = useRef(null);
  const hideControlsTimer = useRef(null);

  useEffect(() => {
    fetchChapter();
  }, [chapterId]);

  useEffect(() => {
    // Save read history
    if (isLoggedIn && chapter) {
      axios.post(`/api/user/history`, {
        mangaId: chapter.mangaId,
        chapterId: chapter._id,
        chapterNumber: chapter.number
      }).catch(() => {});
    }
  }, [chapter, isLoggedIn]);

  useEffect(() => {
    const handleKeyboard = (e) => {
      if (readMode === READ_MODES.HORIZONTAL) {
        if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') prevPage();
        if (e.key === 'ArrowRight' || e.key === 'ArrowDown') nextPage();
      }
    };
    window.addEventListener('keydown', handleKeyboard);
    return () => window.removeEventListener('keydown', handleKeyboard);
  }, [readMode, currentPage, pages]);

  const fetchChapter = async () => {
    try {
      const res = await axios.get(`/api/chapters/${chapterId}`);
      setChapter(res.data.chapter);
      setPages(res.data.chapter.pages || mockPages);
      setPrevChapter(res.data.prevChapter);
      setNextChapter(res.data.nextChapter);
      setMangaTitle(res.data.mangaTitle);
    } catch {
      setChapter(mockChapter);
      setPages(mockPages);
    } finally {
      setLoading(false);
      setCurrentPage(0);
    }
  };

  const handleMouseMove = () => {
    setShowControls(true);
    clearTimeout(hideControlsTimer.current);
    hideControlsTimer.current = setTimeout(() => {
      if (!showSettings) setShowControls(false);
    }, 3000);
  };

  const prevPage = () => {
    if (currentPage > 0) setCurrentPage(p => p - 1);
    else if (prevChapter) navigate(`/manga/${slug}/chapter/${prevChapter._id}`);
  };

  const nextPage = () => {
    if (currentPage < pages.length - 1) setCurrentPage(p => p + 1);
    else if (nextChapter) navigate(`/manga/${slug}/chapter/${nextChapter._id}`);
    else toast.success('Kamu telah menyelesaikan chapter ini! 🎉');
  };

  const changeMode = (mode) => {
    setReadMode(mode);
    localStorage.setItem('readMode', mode);
    setCurrentPage(0);
    setShowSettings(false);
    toast.info(`Mode: ${mode === 'horizontal' ? 'Horizontal' : mode === 'vertical' ? 'Vertikal' : 'Webtoon'}`);
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  if (loading) return (
    <div className={styles.loadingScreen}>
      <div className={styles.loadingSpinner} />
      <p>Memuat chapter...</p>
    </div>
  );

  return (
    <div
      ref={containerRef}
      className={styles.reader}
      style={{ background: bgColor }}
      onMouseMove={handleMouseMove}
    >
      {/* Top Bar */}
      <div className={`${styles.topBar} ${showControls ? styles.visible : ''}`}>
        <div className={styles.topLeft}>
          <Link to={`/manga/${slug}`} className={styles.topBtn}>
            <FiChevronLeft /> Kembali
          </Link>
          <Link to="/" className={styles.topBtn}>
            <FiHome />
          </Link>
        </div>
        <div className={styles.topCenter}>
          <span className={styles.chapterInfo}>
            {mangaTitle || slug} — Chapter {chapter?.number}
          </span>
        </div>
        <div className={styles.topRight}>
          {readMode === READ_MODES.HORIZONTAL && (
            <span className={styles.pageCounter}>
              {currentPage + 1} / {pages.length}
            </span>
          )}
          <button className={styles.topBtn} onClick={toggleFullscreen}>
            {isFullscreen ? <FiMinimize /> : <FiMaximize />}
          </button>
          <button className={styles.topBtn} onClick={() => setShowSettings(!showSettings)}>
            <FiSettings />
          </button>
        </div>
      </div>

      {/* Settings Panel */}
      {showSettings && (
        <div className={styles.settingsPanel}>
          <div className={styles.settingsHeader}>
            <h3>Pengaturan Baca</h3>
            <button onClick={() => setShowSettings(false)}><FiX /></button>
          </div>

          <div className={styles.settingGroup}>
            <label>Mode Baca</label>
            <div className={styles.modeButtons}>
              {Object.entries(READ_MODES).map(([key, val]) => (
                <button
                  key={key}
                  className={`${styles.modeBtn} ${readMode === val ? styles.modeBtnActive : ''}`}
                  onClick={() => changeMode(val)}
                >
                  {val === 'horizontal' ? '↔ Horizontal' : val === 'vertical' ? '↕ Vertikal' : '📜 Webtoon'}
                </button>
              ))}
            </div>
          </div>

          <div className={styles.settingGroup}>
            <label>Kualitas Gambar</label>
            <div className={styles.modeButtons}>
              {['low', 'medium', 'high'].map(q => (
                <button
                  key={q}
                  className={`${styles.modeBtn} ${imgQuality === q ? styles.modeBtnActive : ''}`}
                  onClick={() => setImgQuality(q)}
                >
                  {q === 'low' ? 'Hemat Data' : q === 'medium' ? 'Standar' : 'Tinggi'}
                </button>
              ))}
            </div>
          </div>

          <div className={styles.settingGroup}>
            <label>Warna Latar</label>
            <div className={styles.colorOptions}>
              {['#0a0a0f', '#ffffff', '#1a1a1a', '#f5f5dc'].map(c => (
                <button
                  key={c}
                  className={`${styles.colorBtn} ${bgColor === c ? styles.colorBtnActive : ''}`}
                  style={{ background: c, border: `2px solid ${bgColor === c ? 'var(--accent-primary)' : 'transparent'}` }}
                  onClick={() => setBgColor(c)}
                />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Pages */}
      {readMode === READ_MODES.HORIZONTAL && (
        <HorizontalReader
          pages={pages}
          currentPage={currentPage}
          onPrev={prevPage}
          onNext={nextPage}
        />
      )}

      {readMode === READ_MODES.VERTICAL && (
        <VerticalReader pages={pages} />
      )}

      {readMode === READ_MODES.WEBTOON && (
        <WebtoonReader pages={pages} />
      )}

      {/* Bottom Bar */}
      <div className={`${styles.bottomBar} ${showControls ? styles.visible : ''}`}>
        {/* Prev/Next Chapter */}
        <div className={styles.chapterNav}>
          {prevChapter ? (
            <Link to={`/manga/${slug}/chapter/${prevChapter._id}`} className={styles.chapterNavBtn}>
              <FiChevronLeft /> Chapter {prevChapter.number}
            </Link>
          ) : <div />}

          {/* Page Selector (horizontal only) */}
          {readMode === READ_MODES.HORIZONTAL && (
            <div className={styles.pageSlider}>
              <input
                type="range"
                min={0}
                max={pages.length - 1}
                value={currentPage}
                onChange={e => setCurrentPage(Number(e.target.value))}
              />
            </div>
          )}

          {nextChapter ? (
            <Link to={`/manga/${slug}/chapter/${nextChapter._id}`} className={styles.chapterNavBtn}>
              Chapter {nextChapter.number} <FiChevronRight />
            </Link>
          ) : <div />}
        </div>
      </div>
    </div>
  );
}

function HorizontalReader({ pages, currentPage, onPrev, onNext }) {
  return (
    <div className={styles.horizontalReader}>
      <button className={`${styles.navZone} ${styles.navLeft}`} onClick={onPrev} />
      <div className={styles.pageContainer}>
        <img
          src={pages[currentPage]?.url}
          alt={`Halaman ${currentPage + 1}`}
          className={styles.pageImg}
          onError={e => { e.target.src = `https://via.placeholder.com/800x1200/16161f/ffffff?text=Halaman+${currentPage + 1}`; }}
        />
      </div>
      <button className={`${styles.navZone} ${styles.navRight}`} onClick={onNext} />
    </div>
  );
}

function VerticalReader({ pages }) {
  return (
    <div className={styles.verticalReader}>
      {pages.map((page, i) => (
        <div key={i} className={styles.verticalPage}>
          <img
            src={page.url}
            alt={`Halaman ${i + 1}`}
            className={styles.verticalImg}
            loading="lazy"
            onError={e => { e.target.src = `https://via.placeholder.com/800x1200/16161f/ffffff?text=Halaman+${i + 1}`; }}
          />
        </div>
      ))}
    </div>
  );
}

function WebtoonReader({ pages }) {
  return (
    <div className={styles.webtoonReader}>
      {pages.map((page, i) => (
        <img
          key={i}
          src={page.url}
          alt={`Halaman ${i + 1}`}
          className={styles.webtoonImg}
          loading="lazy"
          onError={e => { e.target.src = `https://via.placeholder.com/800x400/16161f/ffffff?text=Panel+${i + 1}`; }}
        />
      ))}
    </div>
  );
}

const mockChapter = { _id: '1', number: 1, mangaId: '1' };
const mockPages = Array(20).fill(0).map((_, i) => ({
  url: `https://via.placeholder.com/800x1200/16161f/ffffff?text=Halaman+${i + 1}`,
  number: i + 1
}));
