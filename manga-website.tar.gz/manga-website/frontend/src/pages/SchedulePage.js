import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from '../utils/axios';
import { FiCalendar } from 'react-icons/fi';

const DAYS = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];

export default function SchedulePage() {
  const [schedule, setSchedule] = useState({});
  const [loading, setLoading] = useState(true);
  const [activeDay, setActiveDay] = useState(DAYS[new Date().getDay() === 0 ? 6 : new Date().getDay() - 1]);

  useEffect(() => {
    const fetch = async () => {
      try {
        const res = await axios.get('/api/manga/schedule');
        setSchedule(res.data.schedule || mockSchedule);
      } catch { setSchedule(mockSchedule); } finally { setLoading(false); }
    };
    fetch();
  }, []);

  return (
    <div style={{ minHeight: '100vh', paddingTop: '64px' }}>
      <div style={{ background: 'var(--bg-secondary)', borderBottom: '1px solid var(--border-color)', padding: '40px 24px' }}>
        <div style={{ maxWidth: 900, margin: '0 auto', textAlign: 'center' }}>
          <FiCalendar style={{ fontSize: 40, color: 'var(--accent-primary)', marginBottom: 12 }} />
          <h1 style={{ fontSize: 36, marginBottom: 8 }}>Jadwal Update</h1>
          <p style={{ color: 'var(--text-secondary)' }}>Jadwal update chapter manga mingguan</p>
        </div>
      </div>

      <div style={{ maxWidth: 900, margin: '0 auto', padding: '32px 24px 60px' }}>
        <div style={{ display: 'flex', gap: 4, marginBottom: 32, flexWrap: 'wrap' }}>
          {DAYS.map(day => (
            <button key={day} onClick={() => setActiveDay(day)}
              style={{ flex: 1, minWidth: 80, padding: '10px 4px', border: '1px solid', borderColor: activeDay === day ? 'var(--accent-primary)' : 'var(--border-color)', borderRadius: 8, background: activeDay === day ? 'rgba(230,57,70,0.1)' : 'var(--bg-card)', color: activeDay === day ? 'var(--accent-primary)' : 'var(--text-secondary)', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>
              {day}
            </button>
          ))}
        </div>

        <h3 style={{ marginBottom: 16, fontSize: 16, color: 'var(--text-secondary)' }}>
          Manga update hari <strong style={{ color: 'var(--text-primary)' }}>{activeDay}</strong> ({(schedule[activeDay] || []).length} manga)
        </h3>

        {loading ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {Array(6).fill(0).map((_, i) => <div key={i} className="skeleton" style={{ height: 72, borderRadius: 8 }} />)}
          </div>
        ) : (schedule[activeDay] || []).length === 0 ? (
          <div style={{ textAlign: 'center', padding: '60px 24px', color: 'var(--text-muted)' }}>
            <p style={{ fontSize: 32, marginBottom: 12 }}>😴</p>
            <p>Tidak ada update manga di hari ini</p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {(schedule[activeDay] || []).map(manga => (
              <Link key={manga._id} to={`/manga/${manga.slug}`} style={{ display: 'flex', gap: 12, padding: 14, background: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 8, textDecoration: 'none', transition: 'background 0.2s' }}>
                <img src={manga.cover} alt={manga.title} style={{ width: 48, height: 64, objectFit: 'cover', borderRadius: 4 }} />
                <div style={{ flex: 1 }}>
                  <p style={{ fontWeight: 700, marginBottom: 4, fontSize: 14, color: 'var(--text-primary)' }}>{manga.title}</p>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                    {manga.genres?.slice(0, 2).map(g => <span key={g} style={{ fontSize: 11, padding: '1px 7px', background: 'rgba(255,255,255,0.06)', borderRadius: 3, color: 'var(--text-muted)' }}>{g}</span>)}
                  </div>
                </div>
                {manga.isVIPOnly && <span style={{ padding: '2px 8px', background: 'var(--gradient-vip)', color: 'white', borderRadius: 4, fontSize: 10, fontWeight: 700, alignSelf: 'flex-start' }}>VIP</span>}
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

const mockSchedule = {
  Senin: Array(4).fill(0).map((_, i) => ({ _id: `s${i}`, title: `Manga ${i + 1}`, slug: `manga-${i + 1}`, cover: `https://via.placeholder.com/48x64/16161f/e63946?text=M`, genres: ['Action', 'Fantasy'], isVIPOnly: i === 0 })),
  Selasa: Array(3).fill(0).map((_, i) => ({ _id: `sl${i}`, title: `Manga ${i + 5}`, slug: `manga-${i + 5}`, cover: `https://via.placeholder.com/48x64/16161f/e63946?text=M`, genres: ['Romance'], isVIPOnly: false })),
  Rabu: [], Kamis: Array(5).fill(0).map((_, i) => ({ _id: `k${i}`, title: `Manga ${i + 8}`, slug: `manga-${i + 8}`, cover: `https://via.placeholder.com/48x64/16161f/e63946?text=M`, genres: ['Fantasy'], isVIPOnly: false })),
  Jumat: Array(6).fill(0).map((_, i) => ({ _id: `j${i}`, title: `Manga ${i + 13}`, slug: `manga-${i + 13}`, cover: `https://via.placeholder.com/48x64/16161f/e63946?text=M`, genres: ['Action'], isVIPOnly: i < 2 })),
  Sabtu: Array(2).fill(0).map((_, i) => ({ _id: `sa${i}`, title: `Manga ${i + 19}`, slug: `manga-${i + 19}`, cover: `https://via.placeholder.com/48x64/16161f/e63946?text=M`, genres: ['Slice of Life'], isVIPOnly: false })),
  Minggu: Array(3).fill(0).map((_, i) => ({ _id: `mg${i}`, title: `Manga ${i + 21}`, slug: `manga-${i + 21}`, cover: `https://via.placeholder.com/48x64/16161f/e63946?text=M`, genres: ['Comedy'], isVIPOnly: false })),
};
