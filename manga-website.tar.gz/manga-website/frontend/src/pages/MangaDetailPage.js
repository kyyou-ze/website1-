import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import axios from '../utils/axios';
import { useAuth } from '../context/AuthContext';
import CommentSection from '../components/manga/CommentSection';
import StarRating from '../components/manga/StarRating';
import {
  FiBookmark, FiHeart, FiShare2, FiClock, FiUser,
  FiTag, FiList, FiStar, FiEye, FiLock, FiPlay
} from 'react-icons/fi';
import { toast } from 'react-toastify';
import styles from './MangaDetailPage.module.css';
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import 'dayjs/locale/id';
dayjs.extend(relativeTime);
dayjs.locale('id');

export default function MangaDetailPage() {
  const { slug } = useParams();
  const { user, isLoggedIn, isVIP, isVIPPlus } = useAuth();
  const navigate = useNavigate();

  const [manga, setManga] = useState(null);
  const [chapters, setChapters] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [isFavorited, setIsFavorited] = useState(false);
  const [activeTab, setActiveTab] = useState('chapters');
  const [showAllChapters, setShowAllChapters] = useState(false);
  const [userRating, setUserRating] = useState(0);

  useEffect(() => {
    fetchManga();
  }, [slug]);

  const fetchManga = async () => {
    try {
      const [mangaRes, chaptersRes] = await Promise.all([
        axios.get(`/api/manga/${slug}`),
        axios.get(`/api/manga/${slug}/chapters`)
      ]);
      setManga(mangaRes.data.manga);
      setChapters(chaptersRes.data.chapters);
      if (isLoggedIn) {
        setIsBookmarked(mangaRes.data.isBookmarked);
        setIsFavorited(mangaRes.data.isFavorited);
        setUserRating(mangaRes.data.userRating || 0);
      }
    } catch {
      // Use mock
      setManga(mockManga);
      setChapters(mockChapters);
    } finally {
      setLoading(false);
    }
  };

  const toggleBookmark = async () => {
    if (!isLoggedIn) { navigate('/login'); return; }
    try {
      await axios.post(`/api/manga/${manga._id}/bookmark`);
      setIsBookmarked(!isBookmarked);
      toast.success(isBookmarked ? 'Bookmark dihapus' : 'Ditambahkan ke bookmark');
    } catch { toast.error('Gagal mengubah bookmark'); }
  };

  const toggleFavorite = async () => {
    if (!isLoggedIn) { navigate('/login'); return; }
    try {
      await axios.post(`/api/manga/${manga._id}/favorite`);
      setIsFavorited(!isFavorited);
      toast.success(isFavorited ? 'Favorit dihapus' : 'Ditambahkan ke favorit');
    } catch { toast.error('Gagal mengubah favorit'); }
  };

  const handleRating = async (rating) => {
    if (!isLoggedIn) { navigate('/login'); return; }
    try {
      await axios.post(`/api/manga/${manga._id}/rate`, { rating });
      setUserRating(rating);
      toast.success(`Rating ${rating} bintang diberikan!`);
    } catch { toast.error('Gagal memberikan rating'); }
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success('Link disalin!');
  };

  const canReadChapter = (chapter) => {
    if (!chapter.isVIPOnly) return true;
    if (isVIPPlus || isVIP) return true;
    return false;
  };

  const displayedChapters = showAllChapters ? chapters : chapters.slice(0, 20);

  if (loading) return <LoadingSkeleton />;
  if (!manga) return <div className={styles.notFound}>Manga tidak ditemukan</div>;

  return (
    <div className={styles.page}>
      {/* Hero Banner */}
      <div className={styles.banner}>
        <div className={styles.bannerBg} style={{ backgroundImage: `url(${manga.cover})` }} />
        <div className={styles.bannerOverlay} />
      </div>

      <div className={styles.content}>
        {/* Manga Info */}
        <div className={styles.infoSection}>
          <div className={styles.coverWrapper}>
            <img src={manga.cover} alt={manga.title} className={styles.cover} />
            {manga.isVIPOnly && (
              <div className={styles.vipBadge}>
                <FiStar /> Konten VIP
              </div>
            )}
          </div>

          <div className={styles.info}>
            <div className={styles.infoMeta}>
              <span className={`badge ${manga.status === 'ongoing' ? 'badge-new' : ''}`}>
                {manga.status === 'ongoing' ? 'Ongoing' : 'Tamat'}
              </span>
              {manga.isVIPOnly && <span className="badge badge-vip">VIP</span>}
            </div>

            <h1 className={styles.title}>{manga.title}</h1>
            {manga.altTitle && <p className={styles.altTitle}>{manga.altTitle}</p>}

            <div className={styles.metaGrid}>
              <div className={styles.metaItem}>
                <FiUser /> <span>Author</span>
                <strong>{manga.author}</strong>
              </div>
              <div className={styles.metaItem}>
                <FiUser /> <span>Artist</span>
                <strong>{manga.artist || manga.author}</strong>
              </div>
              <div className={styles.metaItem}>
                <FiList /> <span>Total Chapter</span>
                <strong>{manga.totalChapters}</strong>
              </div>
              <div className={styles.metaItem}>
                <FiEye /> <span>Dilihat</span>
                <strong>{manga.views?.toLocaleString('id-ID')}</strong>
              </div>
              <div className={styles.metaItem}>
                <FiClock /> <span>Update</span>
                <strong>{dayjs(manga.updatedAt).fromNow()}</strong>
              </div>
              <div className={styles.metaItem}>
                <FiStar /> <span>Rating</span>
                <strong className={styles.ratingVal}>{manga.rating?.toFixed(1)} / 10</strong>
              </div>
            </div>

            <div className={styles.genres}>
              {manga.genres?.map(g => (
                <Link key={g} to={`/search?genre=${g}`} className={styles.genreTag}>
                  <FiTag /> {g}
                </Link>
              ))}
            </div>

            {/* Rating */}
            <div className={styles.ratingSection}>
              <span>Beri Rating:</span>
              <StarRating value={userRating} onChange={handleRating} />
              {!isLoggedIn && <span className={styles.loginHint}>Login untuk memberi rating</span>}
            </div>

            {/* Actions */}
            <div className={styles.actions}>
              <Link
                to={`/manga/${manga.slug}/chapter/${chapters[chapters.length - 1]?._id}`}
                className={styles.btnRead}
              >
                <FiPlay /> Mulai Baca
              </Link>
              <Link
                to={`/manga/${manga.slug}/chapter/${chapters[0]?._id}`}
                className={styles.btnLatest}
              >
                Terbaru
              </Link>
              <button
                className={`${styles.iconAction} ${isBookmarked ? styles.active : ''}`}
                onClick={toggleBookmark}
                title="Bookmark"
              >
                <FiBookmark />
              </button>
              <button
                className={`${styles.iconAction} ${isFavorited ? styles.activeFav : ''}`}
                onClick={toggleFavorite}
                title="Favorit"
              >
                <FiHeart />
              </button>
              <button className={styles.iconAction} onClick={handleShare} title="Bagikan">
                <FiShare2 />
              </button>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className={styles.tabs}>
          <button
            className={`${styles.tab} ${activeTab === 'chapters' ? styles.tabActive : ''}`}
            onClick={() => setActiveTab('chapters')}
          >
            <FiList /> Daftar Chapter ({chapters.length})
          </button>
          <button
            className={`${styles.tab} ${activeTab === 'about' ? styles.tabActive : ''}`}
            onClick={() => setActiveTab('about')}
          >
            Info & Sinopsis
          </button>
          <button
            className={`${styles.tab} ${activeTab === 'comments' ? styles.tabActive : ''}`}
            onClick={() => setActiveTab('comments')}
          >
            Komentar
          </button>
        </div>

        {/* Tab Content */}
        {activeTab === 'chapters' && (
          <div className={styles.chapterList}>
            {displayedChapters.map(ch => (
              <ChapterItem
                key={ch._id}
                chapter={ch}
                slug={manga.slug}
                canRead={canReadChapter(ch)}
              />
            ))}
            {chapters.length > 20 && (
              <button
                className={styles.showMoreBtn}
                onClick={() => setShowAllChapters(!showAllChapters)}
              >
                {showAllChapters ? 'Tampilkan lebih sedikit' : `Tampilkan semua ${chapters.length} chapter`}
              </button>
            )}
          </div>
        )}

        {activeTab === 'about' && (
          <div className={styles.aboutSection}>
            <h3>Sinopsis</h3>
            <p className={styles.synopsis}>{manga.description}</p>
          </div>
        )}

        {activeTab === 'comments' && (
          <CommentSection mangaId={manga._id} />
        )}
      </div>
    </div>
  );
}

function ChapterItem({ chapter, slug, canRead }) {
  const navigate = useNavigate();
  const handleClick = () => {
    if (canRead) navigate(`/manga/${slug}/chapter/${chapter._id}`);
    else navigate('/vip');
  };

  return (
    <div
      className={`${styles.chapterItem} ${!canRead ? styles.locked : ''}`}
      onClick={handleClick}
    >
      <div className={styles.chapterLeft}>
        {!canRead && <FiLock className={styles.lockIcon} />}
        <div>
          <span className={styles.chapterNum}>Chapter {chapter.number}</span>
          {chapter.title && <span className={styles.chapterTitle}>: {chapter.title}</span>}
          {chapter.isVIPOnly && <span className="badge badge-vip" style={{marginLeft: 8, fontSize: 10}}>VIP</span>}
        </div>
      </div>
      <span className={styles.chapterDate}>{dayjs(chapter.createdAt).fromNow()}</span>
    </div>
  );
}

function StarRating({ value, onChange }) {
  const [hovered, setHovered] = useState(0);
  return (
    <div className={styles.stars}>
      {Array(10).fill(0).map((_, i) => (
        <button
          key={i}
          className={`${styles.star} ${(hovered || value) > i ? styles.starFilled : ''}`}
          onMouseEnter={() => setHovered(i + 1)}
          onMouseLeave={() => setHovered(0)}
          onClick={() => onChange(i + 1)}
        >
          ★
        </button>
      ))}
      {(hovered || value) > 0 && (
        <span className={styles.ratingNum}>{hovered || value}/10</span>
      )}
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div className={styles.page}>
      <div className={`skeleton ${styles.bannerSkeleton}`} />
      <div className={styles.content}>
        <div className={styles.infoSection}>
          <div className={`skeleton ${styles.coverSkeleton}`} />
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 12}}>
            <div className={`skeleton`} style={{height: 32, width: '60%'}} />
            <div className={`skeleton`} style={{height: 20, width: '40%'}} />
            <div className={`skeleton`} style={{height: 80, width: '100%'}} />
          </div>
        </div>
      </div>
    </div>
  );
}

const mockManga = {
  _id: '1', title: 'Manga Keren Sekali', slug: 'manga-keren',
  cover: 'https://via.placeholder.com/300x420/16161f/e63946?text=Cover',
  altTitle: 'Korean Manga Title', author: 'John Author', artist: 'Jane Artist',
  description: 'Ini adalah sinopsis panjang dari manga yang sangat menarik. Berisi kisah petualangan seorang hero yang berjuang melawan kejahatan dan menemukan jati dirinya di dunia yang penuh misteri.',
  rating: 8.5, totalChapters: 150, views: 1250000,
  status: 'ongoing', isVIPOnly: false,
  genres: ['Action', 'Fantasy', 'Adventure', 'Romance'],
  updatedAt: new Date()
};

const mockChapters = Array(30).fill(0).map((_, i) => ({
  _id: String(i), number: 30 - i,
  title: i % 5 === 0 ? `Special Chapter` : '',
  isVIPOnly: i < 3,
  createdAt: new Date(Date.now() - i * 86400000 * 3)
}));
