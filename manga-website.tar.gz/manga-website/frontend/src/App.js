import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './index.css';

// Context
import { AuthProvider } from './context/AuthContext';
import { NotificationProvider } from './context/NotificationContext';

// Layout
import Navbar from './components/common/Navbar';
import Footer from './components/common/Footer';

// Pages
import HomePage from './pages/HomePage';
import MangaDetailPage from './pages/MangaDetailPage';
import ReaderPage from './pages/ReaderPage';
import SearchPage from './pages/SearchPage';
import ProfilePage from './pages/ProfilePage';
import BookmarkPage from './pages/BookmarkPage';
import HistoryPage from './pages/HistoryPage';
import FavoritePage from './pages/FavoritePage';
import ForumPage from './pages/ForumPage';
import ForumDetailPage from './pages/ForumDetailPage';
import SchedulePage from './pages/SchedulePage';
import VIPPage from './pages/VIPPage';
import LeaderboardPage from './pages/LeaderboardPage';
import LoginPage from './pages/LoginPage';
import NotFoundPage from './pages/NotFoundPage';

// Admin Pages
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminManga from './pages/admin/AdminManga';
import AdminUsers from './pages/admin/AdminUsers';
import AdminPayments from './pages/admin/AdminPayments';
import AdminComments from './pages/admin/AdminComments';
import AdminPromo from './pages/admin/AdminPromo';

// Guards
import PrivateRoute from './components/common/PrivateRoute';
import AdminRoute from './components/common/AdminRoute';

function App() {
  return (
    <AuthProvider>
      <NotificationProvider>
        <Router>
          <div className="app">
            <Navbar />
            <main className="main-content">
              <Routes>
                {/* Public Routes */}
                <Route path="/" element={<HomePage />} />
                <Route path="/manga/:slug" element={<MangaDetailPage />} />
                <Route path="/manga/:slug/chapter/:chapterId" element={<ReaderPage />} />
                <Route path="/search" element={<SearchPage />} />
                <Route path="/jadwal" element={<SchedulePage />} />
                <Route path="/leaderboard" element={<LeaderboardPage />} />
                <Route path="/vip" element={<VIPPage />} />
                <Route path="/forum" element={<ForumPage />} />
                <Route path="/forum/:threadId" element={<ForumDetailPage />} />
                <Route path="/login" element={<LoginPage />} />

                {/* Protected Routes */}
                <Route path="/profil/:username" element={<PrivateRoute><ProfilePage /></PrivateRoute>} />
                <Route path="/bookmark" element={<PrivateRoute><BookmarkPage /></PrivateRoute>} />
                <Route path="/favorit" element={<PrivateRoute><FavoritePage /></PrivateRoute>} />
                <Route path="/riwayat" element={<PrivateRoute><HistoryPage /></PrivateRoute>} />

                {/* Admin Routes */}
                <Route path="/admin" element={<AdminRoute><AdminDashboard /></AdminRoute>} />
                <Route path="/admin/manga" element={<AdminRoute><AdminManga /></AdminRoute>} />
                <Route path="/admin/pengguna" element={<AdminRoute><AdminUsers /></AdminRoute>} />
                <Route path="/admin/pembayaran" element={<AdminRoute><AdminPayments /></AdminRoute>} />
                <Route path="/admin/komentar" element={<AdminRoute><AdminComments /></AdminRoute>} />
                <Route path="/admin/promo" element={<AdminRoute><AdminPromo /></AdminRoute>} />

                {/* 404 */}
                <Route path="*" element={<NotFoundPage />} />
              </Routes>
            </main>
            <Footer />
          </div>
          <ToastContainer
            position="bottom-right"
            theme="dark"
            toastStyle={{ background: '#16161f', border: '1px solid #252535' }}
          />
        </Router>
      </NotificationProvider>
    </AuthProvider>
  );
}

export default App;
