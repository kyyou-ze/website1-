import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiChevronRight } from 'react-icons/fi';
import MangaCard from '../common/MangaCard';
import './MangaSection.css';

const MangaSection = ({ 
  title, 
  subtitle, 
  manga = [], 
  viewAllLink,
  variant = 'grid', // 'grid' or 'list'
  columns = 6 // number of columns for grid
}) => {
  return (
    <section className="manga-section">
      <div className="section-header">
        <div className="header-text">
          <motion.h2
            className="section-title"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            {title}
          </motion.h2>
          {subtitle && (
            <motion.p
              className="section-subtitle"
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              {subtitle}
            </motion.p>
          )}
        </div>
        
        {viewAllLink && (
          <Link to={viewAllLink} className="view-all-link">
            <span>Lihat Semua</span>
            <FiChevronRight />
          </Link>
        )}
      </div>

      <div className={`manga-${variant} columns-${columns}`}>
        {manga.length > 0 ? (
          manga.map((item, index) => (
            <MangaCard 
              key={item.id} 
              manga={item} 
              index={index}
              variant={variant}
            />
          ))
        ) : (
          <div className="empty-state">
            <p>Belum ada manga tersedia</p>
          </div>
        )}
      </div>
    </section>
  );
};

export default MangaSection;
