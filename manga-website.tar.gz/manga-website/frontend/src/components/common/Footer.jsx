import React from 'react';
import { Link } from 'react-router-dom';
import { FiGithub, FiTwitter, FiInstagram, FiMail, FiHeart } from 'react-icons/fi';
import './Footer.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    'Manga': [
      { label: 'Terbaru', path: '/latest' },
      { label: 'Populer', path: '/popular' },
      { label: 'Genre', path: '/genres' },
      { label: 'Schedule', path: '/schedule' }
    ],
    'Komunitas': [
      { label: 'Forum', path: '/forum' },
      { label: 'Leaderboard', path: '/leaderboard' },
      { label: 'VIP', path: '/vip' }
    ],
    'Dukungan': [
      { label: 'Bantuan', path: '/help' },
      { label: 'FAQ', path: '/faq' },
      { label: 'Kontak', path: '/contact' },
      { label: 'Lapor Masalah', path: '/report' }
    ],
    'Lainnya': [
      { label: 'Tentang Kami', path: '/about' },
      { label: 'Kebijakan Privasi', path: '/privacy' },
      { label: 'Syarat & Ketentuan', path: '/terms' }
    ]
  };

  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="container">
          {/* Top Section */}
          <div className="footer-top">
            {/* Logo & Description */}
            <div className="footer-brand">
              <div className="footer-logo">
                <div className="logo-icon">
                  <span className="logo-text">M</span>
                </div>
                <span className="logo-name">MANGA<span className="text-gradient">HUB</span></span>
              </div>
              <p className="footer-description">
                Platform baca manga online terbaik di Indonesia dengan koleksi terlengkap dan update tercepat.
              </p>
              <div className="footer-social">
                <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" aria-label="Twitter">
                  <FiTwitter />
                </a>
                <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
                  <FiInstagram />
                </a>
                <a href="https://github.com" target="_blank" rel="noopener noreferrer" aria-label="GitHub">
                  <FiGithub />
                </a>
                <a href="mailto:contact@mangahub.com" aria-label="Email">
                  <FiMail />
                </a>
              </div>
            </div>

            {/* Links Columns */}
            {Object.entries(footerLinks).map(([category, links]) => (
              <div key={category} className="footer-column">
                <h4 className="column-title">{category}</h4>
                <ul className="column-links">
                  {links.map((link) => (
                    <li key={link.path}>
                      <Link to={link.path}>{link.label}</Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Bottom Section */}
          <div className="footer-bottom">
            <p className="copyright">
              © {currentYear} MangaHub. All rights reserved.
            </p>
            <p className="made-with">
              Made with <FiHeart className="heart-icon" /> by MangaHub Team
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
