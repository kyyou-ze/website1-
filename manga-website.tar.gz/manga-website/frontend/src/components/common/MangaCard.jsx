import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiStar, FiBookmark, FiHeart, FiEye, FiClock } from 'react-icons/fi';
import { BiCrown } from 'react-icons/bi';
import './MangaCard.css';

const MangaCard = ({ manga, index = 0, variant = 'default' }) => {
  const [isBookmarked, setIsBookmarked] = useState(manga.isBookmarked || false);
  const [isFavorited, setIsFavorited] = useState(manga.isFavorited || false);

  const handleBookmark = (e) => {
    e.preventDefault();
    setIsBookmarked(!isBookmarked);
    // TODO: Call API to update bookmark
  };

  const handleFavorite = (e) => {
    e.preventDefault();
    setIsFavorited(!isFavorited);
    // TODO: Call API to update favorite
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        delay: index * 0.1,
        duration: 0.4
      }
    }
  };

  return (
    <motion.div
      className={`manga-card manga-card-${variant}`}
      variants={cardVariants}
      initial="hidden"
      animate="visible"
      whileHover={{ y: -8 }}
    >
      <Link to={`/manga/${manga.id}`} className="manga-card-link">
        {/* Cover Image */}
        <div className="manga-cover">
          <img src={manga.coverImage} alt={manga.title} loading="lazy" />
          
          {/* Overlay Gradient */}
          <div className="cover-overlay"></div>

          {/* VIP Badge */}
          {manga.isVIPOnly && (
            <div className="vip-badge-overlay">
              <BiCrown />
              <span>VIP</span>
            </div>
          )}

          {/* New Badge */}
          {manga.isNew && (
            <div className="new-badge">BARU</div>
          )}

          {/* Rating */}
          <div className="rating-badge">
            <FiStar />
            <span>{manga.rating || 'N/A'}</span>
          </div>

          {/* Quick Actions */}
          <div className="quick-actions">
            <motion.button
              className={`action-icon ${isBookmarked ? 'active' : ''}`}
              onClick={handleBookmark}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <FiBookmark />
            </motion.button>
            <motion.button
              className={`action-icon ${isFavorited ? 'active' : ''}`}
              onClick={handleFavorite}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <FiHeart />
            </motion.button>
          </div>

          {/* Latest Chapter Overlay */}
          {manga.latestChapter && (
            <div className="latest-chapter-overlay">
              <span>Ch. {manga.latestChapter}</span>
            </div>
          )}
        </div>

        {/* Info */}
        <div className="manga-info">
          <h3 className="manga-title">{manga.title}</h3>
          
          {/* Meta */}
          <div className="manga-meta">
            {manga.status && (
              <span className={`status-tag ${manga.status.toLowerCase()}`}>
                {manga.status}
              </span>
            )}
            {manga.chapters && (
              <span className="meta-text">
                <FiClock size={12} /> {manga.chapters} Ch
              </span>
            )}
            {manga.views && (
              <span className="meta-text">
                <FiEye size={12} /> {formatViews(manga.views)}
              </span>
            )}
          </div>

          {/* Genres */}
          {manga.genres && manga.genres.length > 0 && (
            <div className="manga-genres">
              {manga.genres.slice(0, 3).map((genre, idx) => (
                <span key={idx} className="genre-chip">{genre}</span>
              ))}
            </div>
          )}

          {/* Description Preview (for list variant) */}
          {variant === 'list' && manga.description && (
            <p className="manga-description">
              {manga.description.slice(0, 120)}...
            </p>
          )}

          {/* Latest Update Time */}
          {manga.lastUpdated && (
            <div className="last-updated">
              <FiClock size={12} />
              <span>{formatTimeAgo(manga.lastUpdated)}</span>
            </div>
          )}
        </div>
      </Link>
    </motion.div>
  );
};

// Helper function to format views
const formatViews = (views) => {
  if (views >= 1000000) {
    return `${(views / 1000000).toFixed(1)}M`;
  }
  if (views >= 1000) {
    return `${(views / 1000).toFixed(1)}K`;
  }
  return views.toString();
};

// Helper function to format time ago
const formatTimeAgo = (date) => {
  const now = new Date();
  const updated = new Date(date);
  const diffInSeconds = Math.floor((now - updated) / 1000);

  if (diffInSeconds < 60) return 'Baru saja';
  if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} menit lalu`;
  if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} jam lalu`;
  if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)} hari lalu`;
  if (diffInSeconds < 2592000) return `${Math.floor(diffInSeconds / 604800)} minggu lalu`;
  return `${Math.floor(diffInSeconds / 2592000)} bulan lalu`;
};

export default MangaCard;
