import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FiSearch, 
  FiUser, 
  FiBell, 
  FiMenu, 
  FiX,
  FiBookmark,
  FiHeart,
  FiClock,
  FiLogOut,
  FiSettings
} from 'react-icons/fi';
import { BiCrown } from 'react-icons/bi';
import './Navbar.css';

const Navbar = ({ user, onLogout }) => {
  const [scrolled, setScrolled] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
      setShowSearch(false);
      setSearchQuery('');
    }
  };

  const navLinks = [
    { label: 'Beranda', path: '/' },
    { label: 'Terbaru', path: '/latest' },
    { label: 'Populer', path: '/popular' },
    { label: 'Genre', path: '/genres' },
    { label: 'Schedule', path: '/schedule' },
    { label: 'Forum', path: '/forum' },
  ];

  return (
    <>
      <motion.nav 
        className={`navbar ${scrolled ? 'scrolled' : ''}`}
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ type: 'spring', stiffness: 100, damping: 20 }}
      >
        <div className="navbar-container">
          {/* Logo */}
          <Link to="/" className="navbar-logo">
            <div className="logo-icon">
              <span className="logo-text">M</span>
            </div>
            <span className="logo-name">MANGA<span className="text-gradient">HUB</span></span>
          </Link>

          {/* Desktop Navigation */}
          <div className="navbar-links">
            {navLinks.map((link, index) => (
              <motion.div
                key={link.path}
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Link to={link.path} className="nav-link">
                  {link.label}
                </Link>
              </motion.div>
            ))}
          </div>

          {/* Right Actions */}
          <div className="navbar-actions">
            {/* Search Button */}
            <motion.button
              className="action-btn"
              onClick={() => setShowSearch(true)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <FiSearch />
            </motion.button>

            {user ? (
              <>
                {/* Notifications */}
                <motion.button
                  className="action-btn notification-btn"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <FiBell />
                  <span className="notification-badge">3</span>
                </motion.button>

                {/* User Menu */}
                <div className="user-menu-wrapper">
                  <motion.button
                    className="user-avatar"
                    onClick={() => setShowUserMenu(!showUserMenu)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    {user.avatar ? (
                      <img src={user.avatar} alt={user.name} />
                    ) : (
                      <FiUser />
                    )}
                    {user.isVIP && (
                      <BiCrown className="vip-crown" />
                    )}
                  </motion.button>

                  <AnimatePresence>
                    {showUserMenu && (
                      <motion.div
                        className="user-dropdown"
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                        transition={{ duration: 0.2 }}
                      >
                        <div className="dropdown-header">
                          <div className="user-info">
                            <p className="user-name">{user.name}</p>
                            {user.isVIP && (
                              <span className="vip-badge">
                                <BiCrown /> {user.vipTier}
                              </span>
                            )}
                          </div>
                        </div>
                        
                        <div className="dropdown-menu">
                          <Link to="/profile" className="dropdown-item">
                            <FiUser /> Profil
                          </Link>
                          <Link to="/bookmarks" className="dropdown-item">
                            <FiBookmark /> Bookmark
                          </Link>
                          <Link to="/favorites" className="dropdown-item">
                            <FiHeart /> Favorit
                          </Link>
                          <Link to="/history" className="dropdown-item">
                            <FiClock /> History
                          </Link>
                          {!user.isVIP && (
                            <Link to="/vip" className="dropdown-item vip-upgrade">
                              <BiCrown /> Upgrade ke VIP
                            </Link>
                          )}
                          <Link to="/settings" className="dropdown-item">
                            <FiSettings /> Pengaturan
                          </Link>
                          <div className="dropdown-divider"></div>
                          <button onClick={onLogout} className="dropdown-item logout">
                            <FiLogOut /> Keluar
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </>
            ) : (
              <Link to="/login">
                <motion.button
                  className="btn-primary"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Masuk
                </motion.button>
              </Link>
            )}

            {/* Mobile Menu Toggle */}
            <motion.button
              className="mobile-menu-btn"
              onClick={() => setShowMobileMenu(!showMobileMenu)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {showMobileMenu ? <FiX /> : <FiMenu />}
            </motion.button>
          </div>
        </div>
      </motion.nav>

      {/* Search Modal */}
      <AnimatePresence>
        {showSearch && (
          <motion.div
            className="search-modal"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowSearch(false)}
          >
            <motion.div
              className="search-content"
              initial={{ y: -50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -50, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
            >
              <form onSubmit={handleSearch} className="search-form">
                <FiSearch className="search-icon" />
                <input
                  type="text"
                  placeholder="Cari manga..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  autoFocus
                />
                <button type="button" onClick={() => setShowSearch(false)}>
                  <FiX />
                </button>
              </form>
              <div className="search-suggestions">
                <p className="suggestions-title">Pencarian Populer</p>
                <div className="suggestion-tags">
                  {['One Piece', 'Naruto', 'Attack on Titan', 'Demon Slayer'].map(tag => (
                    <button key={tag} className="suggestion-tag" onClick={() => {
                      setSearchQuery(tag);
                      handleSearch({ preventDefault: () => {} });
                    }}>
                      {tag}
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mobile Menu */}
      <AnimatePresence>
        {showMobileMenu && (
          <motion.div
            className="mobile-menu"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'tween', duration: 0.3 }}
          >
            <div className="mobile-menu-content">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className="mobile-nav-link"
                  onClick={() => setShowMobileMenu(false)}
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Navbar;
