import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

export default function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={styles.inner}>
        <div className={styles.brand}>
          <div className={styles.logo}>
            <span>⛩</span>
            <span className={styles.logoText}>MANGA<span>KU</span></span>
          </div>
          <p className={styles.tagline}>Baca manga favoritmu kapan saja, di mana saja. Gratis dan lengkap.</p>
        </div>

        <div className={styles.links}>
          <div className={styles.linkGroup}>
            <h4>Jelajahi</h4>
            <Link to="/search">Semua Manga</Link>
            <Link to="/search?sort=popular">Populer</Link>
            <Link to="/search?sort=latest">Terbaru</Link>
            <Link to="/jadwal">Jadwal Update</Link>
            <Link to="/leaderboard">Peringkat</Link>
          </div>
          <div className={styles.linkGroup}>
            <h4>Genre</h4>
            <Link to="/search?genre=Action">Action</Link>
            <Link to="/search?genre=Romance">Romance</Link>
            <Link to="/search?genre=Fantasy">Fantasy</Link>
            <Link to="/search?genre=Comedy">Comedy</Link>
            <Link to="/search?genre=Horror">Horror</Link>
          </div>
          <div className={styles.linkGroup}>
            <h4>Komunitas</h4>
            <Link to="/forum">Forum Diskusi</Link>
            <Link to="/vip">Langganan VIP</Link>
          </div>
        </div>
      </div>

      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} MangaKu. Semua hak cipta dilindungi.</p>
        <div className={styles.bottomLinks}>
          <a href="/terms">Syarat & Ketentuan</a>
          <a href="/privacy">Privasi</a>
          <a href="/contact">Kontak</a>
        </div>
      </div>
    </footer>
  );
}
