import React from 'react';
import { Link } from 'react-router-dom';
import { FiStar, FiBookmark, FiClock } from 'react-icons/fi';
import { useAuth } from '../../context/AuthContext';
import styles from './MangaCard.module.css';
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import 'dayjs/locale/id';
dayjs.extend(relativeTime);
dayjs.locale('id');

export default function MangaCard({ manga }) {
  const { isLoggedIn } = useAuth();

  if (!manga) return null;

  const {
    _id, title, slug, cover, rating, totalChapters,
    latestChapter, genres = [], status, isVIPOnly
  } = manga;

  return (
    <Link to={`/manga/${slug}`} className={styles.card}>
      <div className={styles.coverWrapper}>
        <img
          src={cover}
          alt={title}
          className={styles.cover}
          loading="lazy"
          onError={e => { e.target.src = '/placeholder-cover.jpg'; }}
        />
        <div className={styles.overlay} />

        {/* Badges */}
        <div className={styles.badges}>
          {isVIPOnly && (
            <span className={styles.badgeVip}>VIP</span>
          )}
          {status === 'ongoing' && (
            <span className={styles.badgeOngoing}>Ongoing</span>
          )}
          {status === 'completed' && (
            <span className={styles.badgeDone}>Tamat</span>
          )}
        </div>

        {/* Rating */}
        <div className={styles.rating}>
          <FiStar />
          <span>{rating?.toFixed(1) || '0.0'}</span>
        </div>

        {/* Latest Chapter */}
        {latestChapter && (
          <div className={styles.latestChapter}>
            <FiClock />
            <span>Ch. {latestChapter.number}</span>
            <span className={styles.chapterTime}>
              {dayjs(latestChapter.createdAt).fromNow()}
            </span>
          </div>
        )}
      </div>

      <div className={styles.info}>
        <h3 className={styles.title} title={title}>{title}</h3>
        <div className={styles.genres}>
          {genres.slice(0, 2).map(g => (
            <span key={g} className={styles.genre}>{g}</span>
          ))}
        </div>
      </div>
    </Link>
  );
}
