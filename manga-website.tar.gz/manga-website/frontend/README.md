# MangaHub Frontend

Platform baca manga online terbaik di Indonesia dengan koleksi terlengkap dan update tercepat.

## 🚀 Tech Stack

- **React 18** - UI Library
- **React Router v6** - Routing
- **Framer Motion** - Animations
- **Axios** - HTTP Client
- **Google OAuth** - Authentication
- **React Toastify** - Notifications
- **React Icons** - Icons
- **Date-fns** - Date formatting

## 🎨 Design Features

- **Dark Mode** - Elegant dark theme dengan aksen warm red/orange
- **Distinctive Typography** - Rajdhani (headings) + DM Sans (body)
- **Smooth Animations** - Powered by Framer Motion
- **Responsive Design** - Mobile-first approach
- **Modern UI/UX** - Bold, memorable, dan user-friendly

## 📁 Project Structure

```
frontend/
├── public/
│   └── index.html
├── src/
│   ├── components/
│   │   ├── common/          # Reusable components
│   │   │   ├── Navbar.jsx
│   │   │   ├── Footer.jsx
│   │   │   └── MangaCard.jsx
│   │   ├── home/            # Home page components
│   │   │   ├── Hero.jsx
│   │   │   └── MangaSection.jsx
│   │   ├── reader/          # Reader components
│   │   ├── manga/           # Manga detail components
│   │   ├── user/            # User profile components
│   │   ├── admin/           # Admin panel components
│   │   ├── forum/           # Forum components
│   │   └── vip/             # VIP components
│   ├── pages/               # Page components
│   │   ├── HomePage.jsx
│   │   ├── MangaDetailPage.jsx
│   │   ├── ReaderPage.jsx
│   │   ├── LoginPage.jsx
│   │   └── ...
│   ├── context/             # React Context
│   │   └── AuthContext.jsx
│   ├── hooks/               # Custom hooks
│   ├── utils/               # Utility functions
│   ├── styles/              # Global styles
│   │   └── global.css
│   ├── App.jsx
│   └── index.js
├── package.json
└── .env.example
```

## 🛠️ Installation

1. **Clone repository**
```bash
cd manga-website/frontend
```

2. **Install dependencies**
```bash
npm install
```

3. **Setup environment variables**
```bash
cp .env.example .env
```

Edit `.env` dan isi:
- `REACT_APP_API_URL` - Backend API URL
- `REACT_APP_GOOGLE_CLIENT_ID` - Google OAuth Client ID

4. **Run development server**
```bash
npm start
```

Aplikasi akan berjalan di `http://localhost:3000`

## 🔧 Available Scripts

- `npm start` - Run development server
- `npm build` - Build for production
- `npm test` - Run tests
- `npm eject` - Eject from Create React App (irreversible)

## 🌟 Key Features

### Homepage
- Hero section dengan auto-sliding featured manga
- Latest updates section
- Trending manga section
- Popular manga section
- Responsive grid layout

### Navbar
- Search functionality dengan modal
- User dropdown menu
- VIP badge display
- Notification indicator
- Mobile responsive menu

### MangaCard
- Multiple variants (grid, list)
- Quick actions (bookmark, favorite)
- VIP badge indicator
- Rating display
- Status tags
- Genre chips
- Hover animations

### Authentication
- Google OAuth integration
- Protected routes
- Persistent login state
- User profile management

## 📱 Pages

- **/** - Homepage
- **/manga/:id** - Manga detail page
- **/read/:mangaId/:chapterId** - Reader page
- **/search** - Search & filter page
- **/genres** - Browse by genre
- **/latest** - Latest updates
- **/popular** - Popular manga
- **/schedule** - Release schedule
- **/forum** - Community forum
- **/profile** - User profile
- **/bookmarks** - Bookmarked manga
- **/favorites** - Favorite manga
- **/history** - Reading history
- **/vip** - VIP subscription page
- **/admin** - Admin panel (protected)

## 🎯 Next Steps (TAHAP 2 - Backend)

1. Setup Node.js + Express server
2. MongoDB database configuration
3. API endpoints untuk:
   - Authentication (Google OAuth)
   - Manga CRUD
   - Chapter CRUD
   - Comments & Ratings
   - Bookmarks & Favorites
   - VIP system
   - Admin panel
4. Cloudinary integration untuk image storage
5. Email verification system

## 📝 Notes

- Frontend ini sudah siap untuk development
- Semua pages sudah memiliki routing
- Components sudah reusable dan scalable
- Design system sudah konsisten
- Ready untuk integrasi dengan backend

## 🤝 Contributing

Contributions are welcome! Please read CONTRIBUTING.md for details.

## 📄 License

This project is licensed under the MIT License.
