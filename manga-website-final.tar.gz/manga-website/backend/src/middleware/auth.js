const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Protect routes - require authentication
exports.protect = async (req, res, next) => {
  let token;

  // Get token from header
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  }

  // Check if token exists
  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Akses ditolak. Silakan login terlebih dahulu.'
    });
  }

  try {
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Get user from token
    const user = await User.findById(decoded.id).select('-password');

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'User tidak ditemukan'
      });
    }

    // Check if user is active
    if (!user.isActive) {
      return res.status(401).json({
        success: false,
        message: 'Akun tidak aktif'
      });
    }

    // Check if user is banned
    if (user.isBanned) {
      const message = user.banExpires && user.banExpires > new Date()
        ? `Akun dibanned sampai ${user.banExpires.toLocaleDateString()}`
        : 'Akun dibanned secara permanen';
      
      return res.status(403).json({
        success: false,
        message: message,
        reason: user.banReason
      });
    }

    // Attach user to request
    req.user = user;
    next();
  } catch (error) {
    console.error('Auth middleware error:', error);
    return res.status(401).json({
      success: false,
      message: 'Token tidak valid atau expired'
    });
  }
};

// Require admin role
exports.requireAdmin = (req, res, next) => {
  if (req.user && req.user.role === 'admin') {
    next();
  } else {
    return res.status(403).json({
      success: false,
      message: 'Akses ditolak. Admin only.'
    });
  }
};

// Require VIP access
exports.requireVIP = (req, res, next) => {
  if (req.user && req.user.hasVIPAccess()) {
    next();
  } else {
    return res.status(403).json({
      success: false,
      message: 'Fitur ini hanya untuk member VIP',
      upgradeUrl: '/vip'
    });
  }
};

// Optional auth - doesn't fail if no token
exports.optionalAuth = async (req, res, next) => {
  let token;

  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (token) {
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const user = await User.findById(decoded.id).select('-password');
      
      if (user && user.isActive && !user.isBanned) {
        req.user = user;
      }
    } catch (error) {
      // Silent fail for optional auth
      console.log('Optional auth failed:', error.message);
    }
  }

  next();
};

// Generate JWT token
exports.generateToken = (userId) => {
  return jwt.sign(
    { id: userId },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRE || '30d' }
  );
};
