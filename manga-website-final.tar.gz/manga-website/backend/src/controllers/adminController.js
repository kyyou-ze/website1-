const User = require('../models/User');
const Manga = require('../models/Manga');
const Chapter = require('../models/Chapter');
const Comment = require('../models/Comment');
const VIPPayment = require('../models/VIPPayment');

// @desc    Get dashboard statistics
// @route   GET /api/admin/stats
// @access  Private/Admin
exports.getDashboardStats = async (req, res) => {
  try {
    const [
      totalUsers,
      totalVIP,
      totalManga,
      totalChapters,
      totalComments,
      pendingPayments,
      recentUsers
    ] = await Promise.all([
      User.countDocuments(),
      User.countDocuments({ 'vipStatus.isVIP': true }),
      Manga.countDocuments({ isActive: true }),
      Chapter.countDocuments({ isActive: true }),
      Comment.countDocuments({ isDeleted: false }),
      VIPPayment.countDocuments({ status: 'pending' }),
      User.find().sort({ createdAt: -1 }).limit(10).select('name email createdAt')
    ]);

    // Calculate revenue (rough estimate)
    const payments = await VIPPayment.find({ status: 'verified' });
    const totalRevenue = payments.reduce((sum, p) => sum + p.amount, 0);

    res.status(200).json({
      success: true,
      data: {
        users: {
          total: totalUsers,
          vip: totalVIP,
          regular: totalUsers - totalVIP
        },
        content: {
          manga: totalManga,
          chapters: totalChapters,
          comments: totalComments
        },
        payments: {
          pending: pendingPayments,
          verified: payments.length,
          totalRevenue
        },
        recentUsers
      }
    });
  } catch (error) {
    console.error('Get stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal mendapatkan statistik'
    });
  }
};

// @desc    Get all users
// @route   GET /api/admin/users
// @access  Private/Admin
exports.getAllUsers = async (req, res) => {
  try {
    const { page = 1, limit = 50, search, role, isVIP } = req.query;

    const filter = {};
    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } }
      ];
    }
    if (role) filter.role = role;
    if (isVIP !== undefined) filter['vipStatus.isVIP'] = isVIP === 'true';

    const skip = (page - 1) * limit;
    const total = await User.countDocuments(filter);

    const users = await User.find(filter)
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .skip(skip)
      .select('-password');

    res.status(200).json({
      success: true,
      count: users.length,
      total,
      pages: Math.ceil(total / limit),
      currentPage: parseInt(page),
      data: users
    });
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal mendapatkan users'
    });
  }
};

// @desc    Ban user
// @route   POST /api/admin/users/:id/ban
// @access  Private/Admin
exports.banUser = async (req, res) => {
  try {
    const { reason, duration } = req.body; // duration in days

    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User tidak ditemukan'
      });
    }

    if (user.role === 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Tidak bisa ban admin'
      });
    }

    user.isBanned = true;
    user.banReason = reason;
    
    if (duration) {
      user.banExpires = new Date(Date.now() + duration * 24 * 60 * 60 * 1000);
    }

    await user.save();

    res.status(200).json({
      success: true,
      message: 'User berhasil dibanned',
      data: user
    });
  } catch (error) {
    console.error('Ban user error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal ban user'
    });
  }
};

// @desc    Unban user
// @route   POST /api/admin/users/:id/unban
// @access  Private/Admin
exports.unbanUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User tidak ditemukan'
      });
    }

    user.isBanned = false;
    user.banReason = undefined;
    user.banExpires = undefined;

    await user.save();

    res.status(200).json({
      success: true,
      message: 'User berhasil di-unban',
      data: user
    });
  } catch (error) {
    console.error('Unban user error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal unban user'
    });
  }
};

// @desc    Get reported comments
// @route   GET /api/admin/comments/reported
// @access  Private/Admin
exports.getReportedComments = async (req, res) => {
  try {
    const comments = await Comment.find({ isReported: true })
      .populate('user', 'name email')
      .populate('manga', 'title')
      .populate('reports.user', 'name')
      .sort({ updatedAt: -1 });

    res.status(200).json({
      success: true,
      count: comments.length,
      data: comments
    });
  } catch (error) {
    console.error('Get reported comments error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal mendapatkan reported comments'
    });
  }
};

// @desc    Delete reported comment
// @route   DELETE /api/admin/comments/:id
// @access  Private/Admin
exports.deleteReportedComment = async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);

    if (!comment) {
      return res.status(404).json({
        success: false,
        message: 'Komentar tidak ditemukan'
      });
    }

    await comment.softDelete();

    res.status(200).json({
      success: true,
      message: 'Komentar berhasil dihapus'
    });
  } catch (error) {
    console.error('Delete comment error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal menghapus komentar'
    });
  }
};

module.exports = exports;
