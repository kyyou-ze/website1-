const Chapter = require('../models/Chapter');
const Manga = require('../models/Manga');
const Bookmark = require('../models/Bookmark');
const { deleteMultipleFiles } = require('../config/cloudinary');
const { sendNewChapterEmail } = require('../services/emailService');

// @desc    Get all chapters for a manga
// @route   GET /api/manga/:mangaId/chapters
// @access  Public
exports.getChaptersByManga = async (req, res) => {
  try {
    const chapters = await Chapter.getByManga(req.params.mangaId);

    res.status(200).json({
      success: true,
      count: chapters.length,
      data: chapters
    });
  } catch (error) {
    console.error('Get chapters error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal mendapatkan chapters'
    });
  }
};

// @desc    Get single chapter with pages
// @route   GET /api/manga/:mangaId/chapters/:chapterNumber
// @access  Public (with VIP check)
exports.getChapter = async (req, res) => {
  try {
    const { mangaId, chapterNumber } = req.params;

    const chapter = await Chapter.getChapterWithPages(mangaId, chapterNumber);

    if (!chapter) {
      return res.status(404).json({
        success: false,
        message: 'Chapter tidak ditemukan'
      });
    }

    // Check VIP access
    if (!chapter.isAccessibleBy(req.user)) {
      return res.status(403).json({
        success: false,
        message: 'Chapter ini khusus VIP',
        requiresVIP: true,
        vipUntil: chapter.vipUntil
      });
    }

    // Increment views
    await chapter.incrementViews();

    // Update bookmark if user is logged in
    if (req.user) {
      const bookmark = await Bookmark.findOne({
        user: req.user.id,
        manga: mangaId
      });

      if (bookmark) {
        bookmark.lastReadChapter = chapter._id;
        await bookmark.save();
      }
    }

    res.status(200).json({
      success: true,
      data: chapter
    });
  } catch (error) {
    console.error('Get chapter error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal mendapatkan chapter'
    });
  }
};

// @desc    Create new chapter (Admin only)
// @route   POST /api/manga/:mangaId/chapters
// @access  Private/Admin
exports.createChapter = async (req, res) => {
  try {
    const { mangaId } = req.params;
    const { chapterNumber, title, volume, isVIPOnly, vipUntil } = req.body;

    // Check if manga exists
    const manga = await Manga.findById(mangaId);
    if (!manga) {
      return res.status(404).json({
        success: false,
        message: 'Manga tidak ditemukan'
      });
    }

    // Check if chapter number already exists
    const existingChapter = await Chapter.findOne({ manga: mangaId, chapterNumber });
    if (existingChapter) {
      return res.status(400).json({
        success: false,
        message: `Chapter ${chapterNumber} sudah ada`
      });
    }

    // Process uploaded pages
    const pages = req.files ? req.files.map((file, index) => ({
      url: file.path,
      publicId: file.filename,
      pageNumber: index + 1
    })) : [];

    if (pages.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Minimal harus upload 1 halaman'
      });
    }

    // Create chapter
    const chapter = await Chapter.create({
      manga: mangaId,
      chapterNumber,
      title,
      volume,
      pages,
      isVIPOnly: isVIPOnly || false,
      vipUntil: vipUntil || null,
      uploadedBy: req.user.id
    });

    // Update manga stats
    manga.stats.totalChapters += 1;
    manga.lastChapterUpdate = new Date();
    await manga.save();

    // Send notifications to users who bookmarked this manga (async, don't wait)
    sendChapterNotifications(manga, chapter).catch(err => 
      console.error('Notification error:', err)
    );

    res.status(201).json({
      success: true,
      message: 'Chapter berhasil dibuat',
      data: chapter
    });
  } catch (error) {
    console.error('Create chapter error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal membuat chapter',
      error: error.message
    });
  }
};

// @desc    Update chapter (Admin only)
// @route   PUT /api/manga/:mangaId/chapters/:id
// @access  Private/Admin
exports.updateChapter = async (req, res) => {
  try {
    const chapter = await Chapter.findById(req.params.id);

    if (!chapter) {
      return res.status(404).json({
        success: false,
        message: 'Chapter tidak ditemukan'
      });
    }

    const { title, volume, isVIPOnly, vipUntil } = req.body;

    if (title) chapter.title = title;
    if (volume) chapter.volume = volume;
    if (isVIPOnly !== undefined) chapter.isVIPOnly = isVIPOnly;
    if (vipUntil !== undefined) chapter.vipUntil = vipUntil;

    await chapter.save();

    res.status(200).json({
      success: true,
      message: 'Chapter berhasil diupdate',
      data: chapter
    });
  } catch (error) {
    console.error('Update chapter error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal update chapter'
    });
  }
};

// @desc    Delete chapter (Admin only)
// @route   DELETE /api/manga/:mangaId/chapters/:id
// @access  Private/Admin
exports.deleteChapter = async (req, res) => {
  try {
    const chapter = await Chapter.findById(req.params.id);

    if (!chapter) {
      return res.status(404).json({
        success: false,
        message: 'Chapter tidak ditemukan'
      });
    }

    // Delete images from Cloudinary
    const publicIds = chapter.pages.map(page => page.publicId);
    if (publicIds.length > 0) {
      await deleteMultipleFiles(publicIds);
    }

    // Soft delete
    chapter.isActive = false;
    await chapter.save();

    // Update manga stats
    const manga = await Manga.findById(chapter.manga);
    if (manga) {
      manga.stats.totalChapters = Math.max(0, manga.stats.totalChapters - 1);
      await manga.save();
    }

    res.status(200).json({
      success: true,
      message: 'Chapter berhasil dihapus'
    });
  } catch (error) {
    console.error('Delete chapter error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal menghapus chapter'
    });
  }
};

// Helper function to send notifications
async function sendChapterNotifications(manga, chapter) {
  try {
    // Get users who bookmarked this manga and have notifications enabled
    const bookmarks = await Bookmark.find({ manga: manga._id })
      .populate({
        path: 'user',
        match: { 
          'settings.notifications.newChapter': true,
          'settings.notifications.email': true
        }
      });

    const notifications = bookmarks
      .filter(b => b.user) // Only users with notifications enabled
      .map(b => sendNewChapterEmail(b.user, manga, chapter));

    await Promise.allSettled(notifications);
    console.log(`Sent ${notifications.length} chapter notifications`);
  } catch (error) {
    console.error('Send notifications error:', error);
  }
}

module.exports = exports;
