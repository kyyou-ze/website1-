const Comment = require('../models/Comment');
const { sendReplyNotification } = require('../services/emailService');

// @desc    Get comments by manga
// @route   GET /api/manga/:mangaId/comments
// @access  Public
exports.getCommentsByManga = async (req, res) => {
  try {
    const { page = 1, limit = 50 } = req.query;
    const comments = await Comment.getByManga(req.params.mangaId, {
      page: parseInt(page),
      limit: parseInt(limit)
    });

    res.status(200).json({
      success: true,
      count: comments.length,
      data: comments
    });
  } catch (error) {
    console.error('Get comments error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal mendapatkan komentar'
    });
  }
};

// @desc    Get comments by chapter
// @route   GET /api/manga/:mangaId/chapters/:chapterId/comments
// @access  Public
exports.getCommentsByChapter = async (req, res) => {
  try {
    const { page = 1, limit = 50 } = req.query;
    const comments = await Comment.getByChapter(req.params.chapterId, {
      page: parseInt(page),
      limit: parseInt(limit)
    });

    res.status(200).json({
      success: true,
      count: comments.length,
      data: comments
    });
  } catch (error) {
    console.error('Get comments error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal mendapatkan komentar'
    });
  }
};

// @desc    Get replies to a comment
// @route   GET /api/comments/:id/replies
// @access  Public
exports.getReplies = async (req, res) => {
  try {
    const replies = await Comment.getReplies(req.params.id);

    res.status(200).json({
      success: true,
      count: replies.length,
      data: replies
    });
  } catch (error) {
    console.error('Get replies error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal mendapatkan replies'
    });
  }
};

// @desc    Create comment
// @route   POST /api/manga/:mangaId/comments
// @access  Private
exports.createComment = async (req, res) => {
  try {
    const { content, chapterId, parentCommentId } = req.body;

    const comment = await Comment.create({
      manga: req.params.mangaId,
      chapter: chapterId || null,
      user: req.user.id,
      content,
      parentComment: parentCommentId || null
    });

    await comment.populate('user', 'name avatar vipStatus.tier');

    // Send notification if it's a reply
    if (parentCommentId) {
      const parentComment = await Comment.findById(parentCommentId).populate('user');
      if (parentComment && parentComment.user._id.toString() !== req.user.id) {
        const manga = await require('../models/Manga').findById(req.params.mangaId);
        sendReplyNotification(
          parentComment.user,
          manga,
          req.user.name,
          content
        ).catch(err => console.error('Reply notification error:', err));
      }
    }

    res.status(201).json({
      success: true,
      message: 'Komentar berhasil dibuat',
      data: comment
    });
  } catch (error) {
    console.error('Create comment error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal membuat komentar'
    });
  }
};

// @desc    Update comment
// @route   PUT /api/comments/:id
// @access  Private
exports.updateComment = async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);

    if (!comment) {
      return res.status(404).json({
        success: false,
        message: 'Komentar tidak ditemukan'
      });
    }

    // Check ownership
    if (comment.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Tidak punya akses'
      });
    }

    await comment.edit(req.body.content);

    res.status(200).json({
      success: true,
      message: 'Komentar berhasil diupdate',
      data: comment
    });
  } catch (error) {
    console.error('Update comment error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal update komentar'
    });
  }
};

// @desc    Delete comment
// @route   DELETE /api/comments/:id
// @access  Private
exports.deleteComment = async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);

    if (!comment) {
      return res.status(404).json({
        success: false,
        message: 'Komentar tidak ditemukan'
      });
    }

    // Check ownership or admin
    if (comment.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Tidak punya akses'
      });
    }

    await comment.softDelete();

    res.status(200).json({
      success: true,
      message: 'Komentar berhasil dihapus'
    });
  } catch (error) {
    console.error('Delete comment error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal menghapus komentar'
    });
  }
};

// @desc    Like/unlike comment
// @route   POST /api/comments/:id/like
// @access  Private
exports.toggleLike = async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);

    if (!comment) {
      return res.status(404).json({
        success: false,
        message: 'Komentar tidak ditemukan'
      });
    }

    await comment.toggleLike(req.user.id);

    res.status(200).json({
      success: true,
      message: 'Success',
      likesCount: comment.likesCount
    });
  } catch (error) {
    console.error('Toggle like error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal toggle like'
    });
  }
};

// @desc    Report comment
// @route   POST /api/comments/:id/report
// @access  Private
exports.reportComment = async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);

    if (!comment) {
      return res.status(404).json({
        success: false,
        message: 'Komentar tidak ditemukan'
      });
    }

    await comment.report(req.user.id, req.body.reason);

    res.status(200).json({
      success: true,
      message: 'Laporan berhasil dikirim'
    });
  } catch (error) {
    console.error('Report comment error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal melaporkan komentar'
    });
  }
};

module.exports = exports;
