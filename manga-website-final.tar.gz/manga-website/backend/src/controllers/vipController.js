const VIPPayment = require('../models/VIPPayment');
const User = require('../models/User');
const { sendVIPUpgradeEmail } = require('../services/emailService');

// VIP Pricing (in IDR)
const VIP_PRICING = {
  VIP: {
    monthly: 50000,
    yearly: 500000
  },
  'VIP+': {
    monthly: 100000,
    yearly: 1000000
  }
};

// @desc    Get VIP pricing
// @route   GET /api/vip/pricing
// @access  Public
exports.getPricing = (req, res) => {
  res.status(200).json({
    success: true,
    data: {
      pricing: VIP_PRICING,
      benefits: {
        VIP: [
          'Bebas iklan',
          'Badge VIP di profil & komentar',
          'Support developer'
        ],
        'VIP+': [
          'Semua benefit VIP',
          'Early access chapter baru',
          'Akses konten VIP eksklusif',
          'Badge VIP+ premium'
        ]
      }
    }
  });
};

// @desc    Submit VIP payment
// @route   POST /api/vip/payment
// @access  Private
exports.submitPayment = async (req, res) => {
  try {
    const { tier, period, paymentMethod, notes } = req.body;

    // Validate tier and period
    if (!['VIP', 'VIP+'].includes(tier)) {
      return res.status(400).json({
        success: false,
        message: 'Tier tidak valid'
      });
    }

    if (!['monthly', 'yearly'].includes(period)) {
      return res.status(400).json({
        success: false,
        message: 'Period tidak valid'
      });
    }

    if (!['DANA', 'GoPay', 'OVO'].includes(paymentMethod)) {
      return res.status(400).json({
        success: false,
        message: 'Metode pembayaran tidak valid'
      });
    }

    // Check if payment proof uploaded
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'Bukti pembayaran harus diupload'
      });
    }

    const amount = VIP_PRICING[tier][period];

    const payment = await VIPPayment.create({
      user: req.user.id,
      tier,
      period,
      amount,
      paymentMethod,
      paymentProof: {
        url: req.file.path,
        publicId: req.file.filename
      },
      notes,
      status: 'pending'
    });

    res.status(201).json({
      success: true,
      message: 'Pembayaran berhasil disubmit. Mohon tunggu verifikasi admin.',
      data: payment
    });
  } catch (error) {
    console.error('Submit payment error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal submit pembayaran'
    });
  }
};

// @desc    Get user's payment history
// @route   GET /api/vip/payments
// @access  Private
exports.getPaymentHistory = async (req, res) => {
  try {
    const payments = await VIPPayment.find({ user: req.user.id })
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: payments.length,
      data: payments
    });
  } catch (error) {
    console.error('Get payment history error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal mendapatkan history pembayaran'
    });
  }
};

// @desc    Get pending payments (Admin)
// @route   GET /api/vip/admin/payments
// @access  Private/Admin
exports.getPendingPayments = async (req, res) => {
  try {
    const { status = 'pending' } = req.query;

    const payments = await VIPPayment.find({ status })
      .populate('user', 'name email avatar')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: payments.length,
      data: payments
    });
  } catch (error) {
    console.error('Get pending payments error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal mendapatkan pending payments'
    });
  }
};

// @desc    Verify payment (Admin)
// @route   POST /api/vip/admin/payments/:id/verify
// @access  Private/Admin
exports.verifyPayment = async (req, res) => {
  try {
    const payment = await VIPPayment.findById(req.params.id).populate('user');

    if (!payment) {
      return res.status(404).json({
        success: false,
        message: 'Payment tidak ditemukan'
      });
    }

    if (payment.status !== 'pending') {
      return res.status(400).json({
        success: false,
        message: 'Payment sudah diproses'
      });
    }

    // Update payment status
    payment.status = 'verified';
    payment.verifiedBy = req.user.id;
    payment.verifiedAt = new Date();
    await payment.save();

    // Upgrade user to VIP
    const durationInDays = payment.period === 'yearly' ? 365 : 30;
    await payment.user.upgradeToVIP(payment.tier, durationInDays);

    // Send confirmation email
    sendVIPUpgradeEmail(
      payment.user,
      payment.tier,
      payment.user.vipStatus.endDate
    ).catch(err => console.error('Email error:', err));

    res.status(200).json({
      success: true,
      message: 'Payment berhasil diverifikasi',
      data: payment
    });
  } catch (error) {
    console.error('Verify payment error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal verifikasi payment'
    });
  }
};

// @desc    Reject payment (Admin)
// @route   POST /api/vip/admin/payments/:id/reject
// @access  Private/Admin
exports.rejectPayment = async (req, res) => {
  try {
    const { reason } = req.body;

    const payment = await VIPPayment.findById(req.params.id);

    if (!payment) {
      return res.status(404).json({
        success: false,
        message: 'Payment tidak ditemukan'
      });
    }

    if (payment.status !== 'pending') {
      return res.status(400).json({
        success: false,
        message: 'Payment sudah diproses'
      });
    }

    payment.status = 'rejected';
    payment.rejectionReason = reason;
    payment.verifiedBy = req.user.id;
    payment.verifiedAt = new Date();
    await payment.save();

    res.status(200).json({
      success: true,
      message: 'Payment berhasil direject',
      data: payment
    });
  } catch (error) {
    console.error('Reject payment error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal reject payment'
    });
  }
};

module.exports = exports;
