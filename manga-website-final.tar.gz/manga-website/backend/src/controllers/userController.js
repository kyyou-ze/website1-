const Bookmark = require('../models/Bookmark');
const Favorite = require('../models/Favorite');
const ReadingHistory = require('../models/ReadingHistory');
const Rating = require('../models/Rating');
const Manga = require('../models/Manga');

// ===== BOOKMARKS =====

// @desc    Get user's bookmarks
// @route   GET /api/user/bookmarks
// @access  Private
exports.getBookmarks = async (req, res) => {
  try {
    const bookmarks = await Bookmark.find({ user: req.user.id })
      .populate('manga')
      .populate('lastReadChapter')
      .sort({ updatedAt: -1 });

    res.status(200).json({
      success: true,
      count: bookmarks.length,
      data: bookmarks
    });
  } catch (error) {
    console.error('Get bookmarks error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal mendapatkan bookmark'
    });
  }
};

// @desc    Add bookmark
// @route   POST /api/user/bookmarks/:mangaId
// @access  Private
exports.addBookmark = async (req, res) => {
  try {
    // Check if already bookmarked
    const existing = await Bookmark.findOne({
      user: req.user.id,
      manga: req.params.mangaId
    });

    if (existing) {
      return res.status(400).json({
        success: false,
        message: 'Sudah dibookmark'
      });
    }

    const bookmark = await Bookmark.create({
      user: req.user.id,
      manga: req.params.mangaId
    });

    res.status(201).json({
      success: true,
      message: 'Bookmark berhasil ditambahkan',
      data: bookmark
    });
  } catch (error) {
    console.error('Add bookmark error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal menambahkan bookmark'
    });
  }
};

// @desc    Remove bookmark
// @route   DELETE /api/user/bookmarks/:mangaId
// @access  Private
exports.removeBookmark = async (req, res) => {
  try {
    const bookmark = await Bookmark.findOne({
      user: req.user.id,
      manga: req.params.mangaId
    });

    if (!bookmark) {
      return res.status(404).json({
        success: false,
        message: 'Bookmark tidak ditemukan'
      });
    }

    await bookmark.remove();

    res.status(200).json({
      success: true,
      message: 'Bookmark berhasil dihapus'
    });
  } catch (error) {
    console.error('Remove bookmark error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal menghapus bookmark'
    });
  }
};

// ===== FAVORITES =====

// @desc    Get user's favorites
// @route   GET /api/user/favorites
// @access  Private
exports.getFavorites = async (req, res) => {
  try {
    const favorites = await Favorite.find({ user: req.user.id })
      .populate('manga')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: favorites.length,
      data: favorites
    });
  } catch (error) {
    console.error('Get favorites error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal mendapatkan favorit'
    });
  }
};

// @desc    Add favorite
// @route   POST /api/user/favorites/:mangaId
// @access  Private
exports.addFavorite = async (req, res) => {
  try {
    const existing = await Favorite.findOne({
      user: req.user.id,
      manga: req.params.mangaId
    });

    if (existing) {
      return res.status(400).json({
        success: false,
        message: 'Sudah ada di favorit'
      });
    }

    const favorite = await Favorite.create({
      user: req.user.id,
      manga: req.params.mangaId
    });

    res.status(201).json({
      success: true,
      message: 'Favorit berhasil ditambahkan',
      data: favorite
    });
  } catch (error) {
    console.error('Add favorite error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal menambahkan favorit'
    });
  }
};

// @desc    Remove favorite
// @route   DELETE /api/user/favorites/:mangaId
// @access  Private
exports.removeFavorite = async (req, res) => {
  try {
    const favorite = await Favorite.findOne({
      user: req.user.id,
      manga: req.params.mangaId
    });

    if (!favorite) {
      return res.status(404).json({
        success: false,
        message: 'Favorit tidak ditemukan'
      });
    }

    await favorite.remove();

    res.status(200).json({
      success: true,
      message: 'Favorit berhasil dihapus'
    });
  } catch (error) {
    console.error('Remove favorite error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal menghapus favorit'
    });
  }
};

// ===== READING HISTORY =====

// @desc    Get reading history
// @route   GET /api/user/history
// @access  Private
exports.getHistory = async (req, res) => {
  try {
    const { page = 1, limit = 50 } = req.query;
    const skip = (page - 1) * limit;

    const history = await ReadingHistory.find({ user: req.user.id })
      .populate('manga')
      .populate('chapter')
      .sort({ updatedAt: -1 })
      .limit(parseInt(limit))
      .skip(skip);

    const total = await ReadingHistory.countDocuments({ user: req.user.id });

    res.status(200).json({
      success: true,
      count: history.length,
      total,
      pages: Math.ceil(total / limit),
      currentPage: parseInt(page),
      data: history
    });
  } catch (error) {
    console.error('Get history error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal mendapatkan history'
    });
  }
};

// @desc    Update reading progress
// @route   POST /api/user/history
// @access  Private
exports.updateHistory = async (req, res) => {
  try {
    const { mangaId, chapterId, lastReadPage, progress } = req.body;

    let history = await ReadingHistory.findOne({
      user: req.user.id,
      manga: mangaId,
      chapter: chapterId
    });

    if (history) {
      history.lastReadPage = lastReadPage;
      history.progress = progress;
      await history.save();
    } else {
      history = await ReadingHistory.create({
        user: req.user.id,
        manga: mangaId,
        chapter: chapterId,
        lastReadPage,
        progress
      });
    }

    res.status(200).json({
      success: true,
      message: 'History berhasil diupdate',
      data: history
    });
  } catch (error) {
    console.error('Update history error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal update history'
    });
  }
};

// ===== RATINGS =====

// @desc    Rate manga
// @route   POST /api/manga/:mangaId/rate
// @access  Private
exports.rateManga = async (req, res) => {
  try {
    const { rating, review } = req.body;

    if (rating < 1 || rating > 5) {
      return res.status(400).json({
        success: false,
        message: 'Rating harus antara 1-5'
      });
    }

    let userRating = await Rating.findOne({
      user: req.user.id,
      manga: req.params.mangaId
    });

    if (userRating) {
      // Update existing rating
      userRating.rating = rating;
      if (review) userRating.review = review;
      await userRating.save();
    } else {
      // Create new rating
      userRating = await Rating.create({
        user: req.user.id,
        manga: req.params.mangaId,
        rating,
        review
      });
    }

    res.status(200).json({
      success: true,
      message: 'Rating berhasil disimpan',
      data: userRating
    });
  } catch (error) {
    console.error('Rate manga error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal menyimpan rating'
    });
  }
};

// @desc    Get user's rating for manga
// @route   GET /api/manga/:mangaId/rate
// @access  Private
exports.getUserRating = async (req, res) => {
  try {
    const rating = await Rating.findOne({
      user: req.user.id,
      manga: req.params.mangaId
    });

    res.status(200).json({
      success: true,
      data: rating
    });
  } catch (error) {
    console.error('Get rating error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal mendapatkan rating'
    });
  }
};

module.exports = exports;
