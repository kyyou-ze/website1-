const Manga = require('../models/Manga');
const Chapter = require('../models/Chapter');
const Bookmark = require('../models/Bookmark');
const Favorite = require('../models/Favorite');
const Rating = require('../models/Rating');

// @desc    Get all manga with filters
// @route   GET /api/manga
// @access  Public
exports.getAllManga = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 20,
      sort = '-createdAt',
      search,
      genres,
      status,
      type,
      isVIPOnly
    } = req.query;

    // Build filter query
    const filter = { isActive: true };

    if (search) {
      filter.$text = { $search: search };
    }

    if (genres) {
      const genreArray = genres.split(',');
      filter.genres = { $in: genreArray };
    }

    if (status) {
      filter.status = status;
    }

    if (type) {
      filter.type = type;
    }

    if (isVIPOnly !== undefined) {
      filter.isVIPOnly = isVIPOnly === 'true';
    }

    // Execute query with pagination
    const skip = (page - 1) * limit;
    const total = await Manga.countDocuments(filter);
    
    const manga = await Manga.find(filter)
      .sort(sort)
      .limit(parseInt(limit))
      .skip(skip)
      .populate('uploadedBy', 'name')
      .populate('latestChapter');

    res.status(200).json({
      success: true,
      count: manga.length,
      total,
      pages: Math.ceil(total / limit),
      currentPage: parseInt(page),
      data: manga
    });
  } catch (error) {
    console.error('Get all manga error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal mendapatkan data manga'
    });
  }
};

// @desc    Get single manga by ID
// @route   GET /api/manga/:id
// @access  Public
exports.getMangaById = async (req, res) => {
  try {
    const manga = await Manga.findById(req.params.id)
      .populate('uploadedBy', 'name avatar')
      .populate('latestChapter');

    if (!manga || !manga.isActive) {
      return res.status(404).json({
        success: false,
        message: 'Manga tidak ditemukan'
      });
    }

    // Increment views
    await manga.incrementViews();

    // Get chapters
    const chapters = await Chapter.find({ manga: manga._id, isActive: true })
      .sort({ chapterNumber: 1 })
      .select('-pages');

    // Get user's bookmark and favorite status if authenticated
    let userInteractions = null;
    if (req.user) {
      const [bookmark, favorite, rating] = await Promise.all([
        Bookmark.findOne({ user: req.user.id, manga: manga._id }),
        Favorite.findOne({ user: req.user.id, manga: manga._id }),
        Rating.findOne({ user: req.user.id, manga: manga._id })
      ]);

      userInteractions = {
        isBookmarked: !!bookmark,
        isFavorited: !!favorite,
        userRating: rating ? rating.rating : null,
        lastReadChapter: bookmark ? bookmark.lastReadChapter : null
      };
    }

    res.status(200).json({
      success: true,
      data: {
        ...manga.toObject(),
        chapters,
        userInteractions
      }
    });
  } catch (error) {
    console.error('Get manga error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal mendapatkan data manga'
    });
  }
};

// @desc    Get trending manga
// @route   GET /api/manga/trending
// @access  Public
exports.getTrending = async (req, res) => {
  try {
    const { limit = 10 } = req.query;
    const manga = await Manga.getTrending(parseInt(limit));

    res.status(200).json({
      success: true,
      count: manga.length,
      data: manga
    });
  } catch (error) {
    console.error('Get trending error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal mendapatkan trending manga'
    });
  }
};

// @desc    Get popular manga
// @route   GET /api/manga/popular
// @access  Public
exports.getPopular = async (req, res) => {
  try {
    const { limit = 10 } = req.query;
    const manga = await Manga.getPopular(parseInt(limit));

    res.status(200).json({
      success: true,
      count: manga.length,
      data: manga
    });
  } catch (error) {
    console.error('Get popular error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal mendapatkan popular manga'
    });
  }
};

// @desc    Get latest updates
// @route   GET /api/manga/latest
// @access  Public
exports.getLatestUpdates = async (req, res) => {
  try {
    const { limit = 10 } = req.query;
    const manga = await Manga.getLatestUpdates(parseInt(limit));

    res.status(200).json({
      success: true,
      count: manga.length,
      data: manga
    });
  } catch (error) {
    console.error('Get latest updates error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal mendapatkan latest updates'
    });
  }
};

// @desc    Create new manga (Admin only)
// @route   POST /api/manga
// @access  Private/Admin
exports.createManga = async (req, res) => {
  try {
    const mangaData = {
      ...req.body,
      uploadedBy: req.user.id
    };

    const manga = await Manga.create(mangaData);

    res.status(201).json({
      success: true,
      message: 'Manga berhasil dibuat',
      data: manga
    });
  } catch (error) {
    console.error('Create manga error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal membuat manga',
      error: error.message
    });
  }
};

// @desc    Update manga (Admin only)
// @route   PUT /api/manga/:id
// @access  Private/Admin
exports.updateManga = async (req, res) => {
  try {
    const manga = await Manga.findById(req.params.id);

    if (!manga) {
      return res.status(404).json({
        success: false,
        message: 'Manga tidak ditemukan'
      });
    }

    const updatedManga = await Manga.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    res.status(200).json({
      success: true,
      message: 'Manga berhasil diupdate',
      data: updatedManga
    });
  } catch (error) {
    console.error('Update manga error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal update manga'
    });
  }
};

// @desc    Delete manga (Admin only)
// @route   DELETE /api/manga/:id
// @access  Private/Admin
exports.deleteManga = async (req, res) => {
  try {
    const manga = await Manga.findById(req.params.id);

    if (!manga) {
      return res.status(404).json({
        success: false,
        message: 'Manga tidak ditemukan'
      });
    }

    // Soft delete
    manga.isActive = false;
    await manga.save();

    res.status(200).json({
      success: true,
      message: 'Manga berhasil dihapus'
    });
  } catch (error) {
    console.error('Delete manga error:', error);
    res.status(500).json({
      success: false,
      message: 'Gagal menghapus manga'
    });
  }
};

module.exports = exports;
