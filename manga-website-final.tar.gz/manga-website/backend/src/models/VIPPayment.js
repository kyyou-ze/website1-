const mongoose = require('mongoose');

const vipPaymentSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  tier: {
    type: String,
    enum: ['VIP', 'VIP+'],
    required: true
  },
  period: {
    type: String,
    enum: ['monthly', 'yearly'],
    required: true
  },
  amount: {
    type: Number,
    required: true
  },
  paymentMethod: {
    type: String,
    enum: ['DANA', 'GoPay', 'OVO'],
    required: true
  },
  paymentProof: {
    url: String,
    publicId: String
  },
  status: {
    type: String,
    enum: ['pending', 'verified', 'rejected'],
    default: 'pending'
  },
  verifiedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  verifiedAt: Date,
  rejectionReason: String,
  notes: String
}, {
  timestamps: true
});

vipPaymentSchema.index({ user: 1, createdAt: -1 });
vipPaymentSchema.index({ status: 1 });

const VIPPayment = mongoose.model('VIPPayment', vipPaymentSchema);

module.exports = VIPPayment;
