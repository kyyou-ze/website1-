const mongoose = require('mongoose');

const bookmarkSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  manga: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Manga',
    required: true,
    index: true
  },
  lastReadChapter: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Chapter'
  },
  lastReadPage: {
    type: Number,
    default: 0
  }
}, {
  timestamps: true
});

// One user can bookmark one manga only once
bookmarkSchema.index({ user: 1, manga: 1 }, { unique: true });

// Update manga bookmarks count
bookmarkSchema.post('save', async function() {
  const Manga = mongoose.model('Manga');
  const manga = await Manga.findById(this.manga);
  if (manga) {
    await manga.incrementBookmarks();
  }
});

bookmarkSchema.post('remove', async function() {
  const Manga = mongoose.model('Manga');
  const manga = await Manga.findById(this.manga);
  if (manga) {
    await manga.decrementBookmarks();
  }
});

const Bookmark = mongoose.model('Bookmark', bookmarkSchema);

module.exports = Bookmark;
