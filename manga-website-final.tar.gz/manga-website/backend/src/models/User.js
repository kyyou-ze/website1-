const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  // Basic Info
  name: {
    type: String,
    required: [true, 'Nama wajib diisi'],
    trim: true,
    maxlength: [100, 'Nama maksimal 100 karakter']
  },
  email: {
    type: String,
    required: [true, 'Email wajib diisi'],
    unique: true,
    lowercase: true,
    trim: true,
    match: [/^\S+@\S+\.\S+$/, 'Format email tidak valid']
  },
  password: {
    type: String,
    minlength: [6, 'Password minimal 6 karakter'],
    select: false // Don't include password in queries by default
  },
  avatar: {
    type: String,
    default: null
  },
  
  // Authentication
  googleId: {
    type: String,
    unique: true,
    sparse: true
  },
  emailVerified: {
    type: Boolean,
    default: false
  },
  verificationToken: String,
  verificationTokenExpires: Date,
  
  // VIP Status
  vipStatus: {
    isVIP: {
      type: Boolean,
      default: false
    },
    tier: {
      type: String,
      enum: ['none', 'VIP', 'VIP+'],
      default: 'none'
    },
    startDate: Date,
    endDate: Date,
    autoRenew: {
      type: Boolean,
      default: false
    }
  },
  
  // User Role
  role: {
    type: String,
    enum: ['user', 'admin'],
    default: 'user'
  },
  
  // Settings & Preferences
  settings: {
    readingMode: {
      type: String,
      enum: ['horizontal', 'vertical', 'webtoon'],
      default: 'vertical'
    },
    notifications: {
      email: {
        type: Boolean,
        default: true
      },
      newChapter: {
        type: Boolean,
        default: true
      },
      replies: {
        type: Boolean,
        default: true
      }
    }
  },
  
  // Status
  isActive: {
    type: Boolean,
    default: true
  },
  isBanned: {
    type: Boolean,
    default: false
  },
  banReason: String,
  banExpires: Date,
  
  // Metadata
  lastLogin: Date,
  loginAttempts: {
    type: Number,
    default: 0
  },
  lockUntil: Date

}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Indexes for performance
userSchema.index({ email: 1 });
userSchema.index({ googleId: 1 });
userSchema.index({ 'vipStatus.isVIP': 1 });
userSchema.index({ role: 1 });

// Virtual for checking if VIP is active
userSchema.virtual('isVIPActive').get(function() {
  if (!this.vipStatus.isVIP) return false;
  if (!this.vipStatus.endDate) return false;
  return new Date() < this.vipStatus.endDate;
});

// Virtual for checking if account is locked
userSchema.virtual('isLocked').get(function() {
  return !!(this.lockUntil && this.lockUntil > Date.now());
});

// Hash password before saving
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  
  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Method to compare password
userSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

// Method to check VIP access
userSchema.methods.hasVIPAccess = function() {
  if (!this.vipStatus.isVIP) return false;
  if (!this.vipStatus.endDate) return false;
  return new Date() < this.vipStatus.endDate;
};

// Method to upgrade to VIP
userSchema.methods.upgradeToVIP = function(tier, durationInDays) {
  this.vipStatus.isVIP = true;
  this.vipStatus.tier = tier;
  this.vipStatus.startDate = new Date();
  this.vipStatus.endDate = new Date(Date.now() + durationInDays * 24 * 60 * 60 * 1000);
  return this.save();
};

// Method to handle failed login
userSchema.methods.incLoginAttempts = function() {
  // Reset attempts if lock has expired
  if (this.lockUntil && this.lockUntil < Date.now()) {
    return this.updateOne({
      $set: { loginAttempts: 1 },
      $unset: { lockUntil: 1 }
    });
  }
  
  const updates = { $inc: { loginAttempts: 1 } };
  const maxAttempts = 5;
  const lockTime = 2 * 60 * 60 * 1000; // 2 hours
  
  if (this.loginAttempts + 1 >= maxAttempts && !this.isLocked) {
    updates.$set = { lockUntil: Date.now() + lockTime };
  }
  
  return this.updateOne(updates);
};

// Method to reset login attempts
userSchema.methods.resetLoginAttempts = function() {
  return this.updateOne({
    $set: { loginAttempts: 0 },
    $unset: { lockUntil: 1 }
  });
};

// Static method to find by email
userSchema.statics.findByEmail = function(email) {
  return this.findOne({ email: email.toLowerCase() });
};

// Static method to find VIP users
userSchema.statics.findVIPUsers = function() {
  return this.find({
    'vipStatus.isVIP': true,
    'vipStatus.endDate': { $gt: new Date() }
  });
};

const User = mongoose.model('User', userSchema);

module.exports = User;
