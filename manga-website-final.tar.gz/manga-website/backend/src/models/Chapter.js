const mongoose = require('mongoose');

const chapterSchema = new mongoose.Schema({
  // Relations
  manga: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Manga',
    required: true,
    index: true
  },
  
  // Chapter Info
  chapterNumber: {
    type: Number,
    required: [true, 'Nomor chapter wajib diisi'],
    min: 0
  },
  title: {
    type: String,
    trim: true,
    maxlength: [200, 'Judul chapter maksimal 200 karakter']
  },
  volume: {
    type: Number,
    min: 0
  },
  
  // Pages - Array of image URLs
  pages: [{
    url: {
      type: String,
      required: true
    },
    publicId: String, // Cloudinary public ID
    pageNumber: {
      type: Number,
      required: true
    }
  }],
  
  // VIP Settings
  isVIPOnly: {
    type: Boolean,
    default: false
  },
  vipUntil: {
    type: Date // Date when chapter becomes free
  },
  
  // Statistics
  views: {
    type: Number,
    default: 0
  },
  
  // Upload Info
  uploadedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  
  // Status
  isActive: {
    type: Boolean,
    default: true
  },
  
  // Metadata
  publishedAt: {
    type: Date,
    default: Date.now
  }

}, {
  timestamps: true
});

// Compound index for manga + chapter number (must be unique)
chapterSchema.index({ manga: 1, chapterNumber: 1 }, { unique: true });
chapterSchema.index({ publishedAt: -1 });
chapterSchema.index({ isVIPOnly: 1 });
chapterSchema.index({ views: -1 });

// Ensure pages are sorted by pageNumber
chapterSchema.pre('save', function(next) {
  if (this.pages && this.pages.length > 0) {
    this.pages.sort((a, b) => a.pageNumber - b.pageNumber);
  }
  next();
});

// Method to increment views
chapterSchema.methods.incrementViews = function() {
  this.views += 1;
  return this.save();
};

// Method to check if accessible by user
chapterSchema.methods.isAccessibleBy = function(user) {
  // If not VIP only, accessible to everyone
  if (!this.isVIPOnly) return true;
  
  // If VIP period expired, accessible to everyone
  if (this.vipUntil && new Date() > this.vipUntil) return true;
  
  // Check if user has VIP access
  if (user && user.hasVIPAccess && user.hasVIPAccess()) return true;
  
  return false;
};

// Static method to get latest chapters
chapterSchema.statics.getLatestChapters = function(limit = 20) {
  return this.find({ isActive: true })
    .sort({ publishedAt: -1 })
    .limit(limit)
    .populate('manga', 'title coverImage')
    .populate('uploadedBy', 'name');
};

// Static method to get chapters by manga
chapterSchema.statics.getByManga = function(mangaId) {
  return this.find({ manga: mangaId, isActive: true })
    .sort({ chapterNumber: 1 })
    .select('-pages'); // Don't include pages in list view
};

// Static method to get chapter with pages
chapterSchema.statics.getChapterWithPages = function(mangaId, chapterNumber) {
  return this.findOne({ 
    manga: mangaId, 
    chapterNumber: chapterNumber,
    isActive: true 
  })
    .populate('manga', 'title isVIPOnly')
    .populate('uploadedBy', 'name');
};

const Chapter = mongoose.model('Chapter', chapterSchema);

module.exports = Chapter;
