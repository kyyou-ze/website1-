const mongoose = require('mongoose');

const commentSchema = new mongoose.Schema({
  // Relations
  manga: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Manga',
    required: true,
    index: true
  },
  chapter: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Chapter',
    index: true
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  
  // Comment Content
  content: {
    type: String,
    required: [true, 'Komentar tidak boleh kosong'],
    maxlength: [2000, 'Komentar maksimal 2000 karakter']
  },
  
  // Nested Replies
  parentComment: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Comment',
    default: null
  },
  
  // Moderation
  isEdited: {
    type: Boolean,
    default: false
  },
  editedAt: Date,
  isDeleted: {
    type: Boolean,
    default: false
  },
  deletedAt: Date,
  
  // Reactions
  likes: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  
  // Status
  isReported: {
    type: Boolean,
    default: false
  },
  reports: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    reason: String,
    createdAt: {
      type: Date,
      default: Date.now
    }
  }]

}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Indexes
commentSchema.index({ manga: 1, createdAt: -1 });
commentSchema.index({ chapter: 1, createdAt: -1 });
commentSchema.index({ user: 1 });
commentSchema.index({ parentComment: 1 });

// Virtual for replies count
commentSchema.virtual('repliesCount', {
  ref: 'Comment',
  localField: '_id',
  foreignField: 'parentComment',
  count: true
});

// Virtual for likes count
commentSchema.virtual('likesCount').get(function() {
  return this.likes ? this.likes.length : 0;
});

// Method to like/unlike
commentSchema.methods.toggleLike = function(userId) {
  const index = this.likes.indexOf(userId);
  if (index === -1) {
    this.likes.push(userId);
  } else {
    this.likes.splice(index, 1);
  }
  return this.save();
};

// Method to edit comment
commentSchema.methods.edit = function(newContent) {
  this.content = newContent;
  this.isEdited = true;
  this.editedAt = new Date();
  return this.save();
};

// Method to soft delete
commentSchema.methods.softDelete = function() {
  this.isDeleted = true;
  this.deletedAt = new Date();
  this.content = '[Komentar telah dihapus]';
  return this.save();
};

// Method to report
commentSchema.methods.report = function(userId, reason) {
  this.reports.push({
    user: userId,
    reason: reason
  });
  this.isReported = true;
  return this.save();
};

// Static method to get comments by manga
commentSchema.statics.getByManga = function(mangaId, options = {}) {
  const { limit = 50, skip = 0 } = options;
  
  return this.find({
    manga: mangaId,
    parentComment: null, // Only top-level comments
    isDeleted: false
  })
  .sort({ createdAt: -1 })
  .limit(limit)
  .skip(skip)
  .populate('user', 'name avatar vipStatus.tier')
  .populate({
    path: 'repliesCount'
  });
};

// Static method to get comments by chapter
commentSchema.statics.getByChapter = function(chapterId, options = {}) {
  const { limit = 50, skip = 0 } = options;
  
  return this.find({
    chapter: chapterId,
    parentComment: null,
    isDeleted: false
  })
  .sort({ createdAt: -1 })
  .limit(limit)
  .skip(skip)
  .populate('user', 'name avatar vipStatus.tier')
  .populate({
    path: 'repliesCount'
  });
};

// Static method to get replies
commentSchema.statics.getReplies = function(commentId) {
  return this.find({
    parentComment: commentId,
    isDeleted: false
  })
  .sort({ createdAt: 1 })
  .populate('user', 'name avatar vipStatus.tier');
};

const Comment = mongoose.model('Comment', commentSchema);

module.exports = Comment;
