const mongoose = require('mongoose');

const mangaSchema = new mongoose.Schema({
  // Basic Info
  title: {
    type: String,
    required: [true, 'Judul manga wajib diisi'],
    trim: true,
    maxlength: [200, 'Judul maksimal 200 karakter']
  },
  alternativeTitles: [{
    type: String,
    trim: true
  }],
  description: {
    type: String,
    required: [true, 'Deskripsi wajib diisi'],
    maxlength: [5000, 'Deskripsi maksimal 5000 karakter']
  },
  
  // Images
  coverImage: {
    url: {
      type: String,
      required: [true, 'Cover image wajib diisi']
    },
    publicId: String // Cloudinary public ID
  },
  bannerImage: {
    url: String,
    publicId: String
  },
  
  // Classification
  genres: [{
    type: String,
    required: true
  }],
  tags: [{
    type: String
  }],
  type: {
    type: String,
    enum: ['Manga', 'Manhwa', 'Manhua', 'Doujinshi', 'Novel'],
    default: 'Manga'
  },
  
  // Status
  status: {
    type: String,
    enum: ['Ongoing', 'Completed', 'Hiatus', 'Dropped'],
    default: 'Ongoing'
  },
  
  // Author & Artist
  author: {
    type: String,
    trim: true
  },
  artist: {
    type: String,
    trim: true
  },
  
  // Publication
  releaseYear: {
    type: Number,
    min: 1900,
    max: new Date().getFullYear() + 1
  },
  serialization: {
    type: String,
    trim: true
  },
  
  // VIP Settings
  isVIPOnly: {
    type: Boolean,
    default: false
  },
  vipChaptersDelay: {
    type: Number, // Days delay for non-VIP users
    default: 0
  },
  
  // Statistics
  stats: {
    totalChapters: {
      type: Number,
      default: 0
    },
    views: {
      type: Number,
      default: 0
    },
    favorites: {
      type: Number,
      default: 0
    },
    bookmarks: {
      type: Number,
      default: 0
    },
    averageRating: {
      type: Number,
      default: 0,
      min: 0,
      max: 5
    },
    totalRatings: {
      type: Number,
      default: 0
    }
  },
  
  // Upload info
  uploadedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  
  // Metadata
  isActive: {
    type: Boolean,
    default: true
  },
  isFeatured: {
    type: Boolean,
    default: false
  },
  lastChapterUpdate: Date

}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Indexes for search and filter
mangaSchema.index({ title: 'text', description: 'text', alternativeTitles: 'text' });
mangaSchema.index({ genres: 1 });
mangaSchema.index({ status: 1 });
mangaSchema.index({ isVIPOnly: 1 });
mangaSchema.index({ 'stats.averageRating': -1 });
mangaSchema.index({ 'stats.views': -1 });
mangaSchema.index({ 'stats.favorites': -1 });
mangaSchema.index({ createdAt: -1 });
mangaSchema.index({ lastChapterUpdate: -1 });

// Virtual populate chapters
mangaSchema.virtual('chapters', {
  ref: 'Chapter',
  localField: '_id',
  foreignField: 'manga'
});

// Virtual for latest chapter
mangaSchema.virtual('latestChapter', {
  ref: 'Chapter',
  localField: '_id',
  foreignField: 'manga',
  options: { sort: { chapterNumber: -1 }, limit: 1 }
});

// Method to increment views
mangaSchema.methods.incrementViews = function() {
  this.stats.views += 1;
  return this.save();
};

// Method to update rating
mangaSchema.methods.updateRating = function(newRating, oldRating = null) {
  if (oldRating !== null) {
    // Update existing rating
    const totalScore = this.stats.averageRating * this.stats.totalRatings;
    const newTotalScore = totalScore - oldRating + newRating;
    this.stats.averageRating = newTotalScore / this.stats.totalRatings;
  } else {
    // New rating
    const totalScore = this.stats.averageRating * this.stats.totalRatings;
    this.stats.totalRatings += 1;
    this.stats.averageRating = (totalScore + newRating) / this.stats.totalRatings;
  }
  
  // Round to 1 decimal place
  this.stats.averageRating = Math.round(this.stats.averageRating * 10) / 10;
  return this.save();
};

// Method to increment favorites
mangaSchema.methods.incrementFavorites = function() {
  this.stats.favorites += 1;
  return this.save();
};

// Method to decrement favorites
mangaSchema.methods.decrementFavorites = function() {
  this.stats.favorites = Math.max(0, this.stats.favorites - 1);
  return this.save();
};

// Method to increment bookmarks
mangaSchema.methods.incrementBookmarks = function() {
  this.stats.bookmarks += 1;
  return this.save();
};

// Method to decrement bookmarks
mangaSchema.methods.decrementBookmarks = function() {
  this.stats.bookmarks = Math.max(0, this.stats.bookmarks - 1);
  return this.save();
};

// Static method to get trending manga (high views in last 7 days)
mangaSchema.statics.getTrending = function(limit = 10) {
  const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  return this.find({
    isActive: true,
    lastChapterUpdate: { $gte: oneWeekAgo }
  })
  .sort({ 'stats.views': -1 })
  .limit(limit)
  .populate('uploadedBy', 'name')
  .populate('latestChapter');
};

// Static method to get popular manga
mangaSchema.statics.getPopular = function(limit = 10) {
  return this.find({ isActive: true })
    .sort({ 'stats.averageRating': -1, 'stats.favorites': -1 })
    .limit(limit)
    .populate('uploadedBy', 'name')
    .populate('latestChapter');
};

// Static method to get latest updates
mangaSchema.statics.getLatestUpdates = function(limit = 10) {
  return this.find({ isActive: true })
    .sort({ lastChapterUpdate: -1 })
    .limit(limit)
    .populate('uploadedBy', 'name')
    .populate('latestChapter');
};

const Manga = mongoose.model('Manga', mangaSchema);

module.exports = Manga;
