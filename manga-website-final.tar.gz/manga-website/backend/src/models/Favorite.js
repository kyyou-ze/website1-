const mongoose = require('mongoose');

const favoriteSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  manga: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Manga',
    required: true,
    index: true
  }
}, {
  timestamps: true
});

// One user can favorite one manga only once
favoriteSchema.index({ user: 1, manga: 1 }, { unique: true });

// Update manga favorites count
favoriteSchema.post('save', async function() {
  const Manga = mongoose.model('Manga');
  const manga = await Manga.findById(this.manga);
  if (manga) {
    await manga.incrementFavorites();
  }
});

favoriteSchema.post('remove', async function() {
  const Manga = mongoose.model('Manga');
  const manga = await Manga.findById(this.manga);
  if (manga) {
    await manga.decrementFavorites();
  }
});

const Favorite = mongoose.model('Favorite', favoriteSchema);

module.exports = Favorite;
