const mongoose = require('mongoose');

const readingHistorySchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  manga: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Manga',
    required: true,
    index: true
  },
  chapter: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Chapter',
    required: true
  },
  lastReadPage: {
    type: Number,
    default: 0
  },
  progress: {
    type: Number, // Percentage 0-100
    default: 0
  }
}, {
  timestamps: true
});

// Compound index
readingHistorySchema.index({ user: 1, manga: 1, chapter: 1 }, { unique: true });
readingHistorySchema.index({ user: 1, updatedAt: -1 });

const ReadingHistory = mongoose.model('ReadingHistory', readingHistorySchema);

module.exports = ReadingHistory;
