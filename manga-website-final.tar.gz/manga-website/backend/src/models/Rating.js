const mongoose = require('mongoose');

const ratingSchema = new mongoose.Schema({
  // Relations
  manga: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Manga',
    required: true,
    index: true
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  
  // Rating (1-5 stars)
  rating: {
    type: Number,
    required: true,
    min: 1,
    max: 5
  },
  
  // Optional review text
  review: {
    type: String,
    maxlength: [1000, 'Review maksimal 1000 karakter']
  }

}, {
  timestamps: true
});

// One user can only rate one manga once
ratingSchema.index({ manga: 1, user: 1 }, { unique: true });

// Update manga rating when rating changes
ratingSchema.post('save', async function() {
  const Manga = mongoose.model('Manga');
  const manga = await Manga.findById(this.manga);
  
  // Recalculate average rating
  const ratings = await mongoose.model('Rating').find({ manga: this.manga });
  const totalRating = ratings.reduce((sum, r) => sum + r.rating, 0);
  const averageRating = ratings.length > 0 ? totalRating / ratings.length : 0;
  
  manga.stats.averageRating = Math.round(averageRating * 10) / 10;
  manga.stats.totalRatings = ratings.length;
  await manga.save();
});

// Update manga rating when rating is deleted
ratingSchema.post('remove', async function() {
  const Manga = mongoose.model('Manga');
  const manga = await Manga.findById(this.manga);
  
  const ratings = await mongoose.model('Rating').find({ manga: this.manga });
  const totalRating = ratings.reduce((sum, r) => sum + r.rating, 0);
  const averageRating = ratings.length > 0 ? totalRating / ratings.length : 0;
  
  manga.stats.averageRating = Math.round(averageRating * 10) / 10;
  manga.stats.totalRatings = ratings.length;
  await manga.save();
});

const Rating = mongoose.model('Rating', ratingSchema);

module.exports = Rating;
