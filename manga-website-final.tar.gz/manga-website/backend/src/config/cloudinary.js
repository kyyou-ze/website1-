const cloudinary = require('cloudinary').v2;
const { CloudinaryStorage } = require('multer-storage-cloudinary');
const multer = require('multer');

// Configure Cloudinary
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});

// Storage for manga covers
const mangaCoverStorage = new CloudinaryStorage({
  cloudinary: cloudinary,
  params: {
    folder: 'manga-website/covers',
    allowed_formats: ['jpg', 'jpeg', 'png', 'webp'],
    transformation: [
      { width: 800, height: 1200, crop: 'fill', quality: 'auto' }
    ]
  }
});

// Storage for manga banners
const mangaBannerStorage = new CloudinaryStorage({
  cloudinary: cloudinary,
  params: {
    folder: 'manga-website/banners',
    allowed_formats: ['jpg', 'jpeg', 'png', 'webp'],
    transformation: [
      { width: 1920, height: 600, crop: 'fill', quality: 'auto' }
    ]
  }
});

// Storage for chapter pages
const chapterPageStorage = new CloudinaryStorage({
  cloudinary: cloudinary,
  params: {
    folder: 'manga-website/chapters',
    allowed_formats: ['jpg', 'jpeg', 'png', 'webp'],
    transformation: [
      { width: 1200, quality: 'auto' }
    ]
  }
});

// Storage for payment proofs
const paymentProofStorage = new CloudinaryStorage({
  cloudinary: cloudinary,
  params: {
    folder: 'manga-website/payments',
    allowed_formats: ['jpg', 'jpeg', 'png']
  }
});

// Upload middleware
const uploadMangaCover = multer({ 
  storage: mangaCoverStorage,
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB
});

const uploadMangaBanner = multer({ 
  storage: mangaBannerStorage,
  limits: { fileSize: 5 * 1024 * 1024 }
});

const uploadChapterPages = multer({ 
  storage: chapterPageStorage,
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB per page
});

const uploadPaymentProof = multer({ 
  storage: paymentProofStorage,
  limits: { fileSize: 5 * 1024 * 1024 }
});

// Delete file from Cloudinary
const deleteFile = async (publicId) => {
  try {
    const result = await cloudinary.uploader.destroy(publicId);
    return result;
  } catch (error) {
    console.error('Cloudinary delete error:', error);
    throw error;
  }
};

// Delete multiple files
const deleteMultipleFiles = async (publicIds) => {
  try {
    const result = await cloudinary.api.delete_resources(publicIds);
    return result;
  } catch (error) {
    console.error('Cloudinary bulk delete error:', error);
    throw error;
  }
};

module.exports = {
  cloudinary,
  uploadMangaCover,
  uploadMangaBanner,
  uploadChapterPages,
  uploadPaymentProof,
  deleteFile,
  deleteMultipleFiles
};
