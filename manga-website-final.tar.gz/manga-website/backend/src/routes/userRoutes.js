const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const {
  getBookmarks,
  addBookmark,
  removeBookmark,
  getFavorites,
  addFavorite,
  removeFavorite,
  getHistory,
  updateHistory,
  rateManga,
  getUserRating
} = require('../controllers/userController');

// All routes require authentication
router.use(protect);

// Bookmarks
router.get('/bookmarks', getBookmarks);
router.post('/bookmarks/:mangaId', addBookmark);
router.delete('/bookmarks/:mangaId', removeBookmark);

// Favorites
router.get('/favorites', getFavorites);
router.post('/favorites/:mangaId', addFavorite);
router.delete('/favorites/:mangaId', removeFavorite);

// Reading History
router.get('/history', getHistory);
router.post('/history', updateHistory);

// Rating (also accessible via /api/manga/:mangaId/rate)
router.post('/rate/:mangaId', rateManga);
router.get('/rate/:mangaId', getUserRating);

module.exports = router;
