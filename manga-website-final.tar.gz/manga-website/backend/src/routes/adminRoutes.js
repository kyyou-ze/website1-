const express = require('express');
const router = express.Router();
const { protect, requireAdmin } = require('../middleware/auth');
const {
  getDashboardStats,
  getAllUsers,
  banUser,
  unbanUser,
  getReportedComments,
  deleteReportedComment
} = require('../controllers/adminController');

// All routes require admin
router.use(protect, requireAdmin);

// Dashboard
router.get('/stats', getDashboardStats);

// User management
router.get('/users', getAllUsers);
router.post('/users/:id/ban', banUser);
router.post('/users/:id/unban', unbanUser);

// Content moderation
router.get('/comments/reported', getReportedComments);
router.delete('/comments/:id', deleteReportedComment);

module.exports = router;
