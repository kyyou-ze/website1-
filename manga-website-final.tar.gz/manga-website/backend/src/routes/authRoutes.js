const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const {
  googleLogin,
  getMe,
  updateProfile,
  logout
} = require('../controllers/authController');

// Public routes
router.post('/google', googleLogin);

// Protected routes
router.use(protect); // All routes below require authentication
router.get('/me', getMe);
router.put('/profile', updateProfile);
router.post('/logout', logout);

module.exports = router;
