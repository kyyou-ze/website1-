const express = require('express');
const router = express.Router();
const { protect, requireAdmin } = require('../middleware/auth');
const { uploadPaymentProof } = require('../config/cloudinary');
const {
  getPricing,
  submitPayment,
  getPaymentHistory,
  getPendingPayments,
  verifyPayment,
  rejectPayment
} = require('../controllers/vipController');

// Public routes
router.get('/pricing', getPricing);

// User routes (protected)
router.post('/payment', protect, uploadPaymentProof.single('proof'), submitPayment);
router.get('/payments', protect, getPaymentHistory);

// Admin routes
router.get('/admin/payments', protect, requireAdmin, getPendingPayments);
router.post('/admin/payments/:id/verify', protect, requireAdmin, verifyPayment);
router.post('/admin/payments/:id/reject', protect, requireAdmin, rejectPayment);

module.exports = router;
