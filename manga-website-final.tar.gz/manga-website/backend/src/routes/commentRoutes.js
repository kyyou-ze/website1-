const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const {
  getCommentsByManga,
  getCommentsByChapter,
  getReplies,
  createComment,
  updateComment,
  deleteComment,
  toggleLike,
  reportComment
} = require('../controllers/commentController');

// Get comments
router.get('/manga/:mangaId', getCommentsByManga);
router.get('/chapter/:chapterId', getCommentsByChapter);
router.get('/:id/replies', getReplies);

// Create comment (protected)
router.post('/manga/:mangaId', protect, createComment);

// Update/delete comment (protected)
router.put('/:id', protect, updateComment);
router.delete('/:id', protect, deleteComment);

// Like comment (protected)
router.post('/:id/like', protect, toggleLike);

// Report comment (protected)
router.post('/:id/report', protect, reportComment);

module.exports = router;
