const express = require('express');
const router = express.Router();
const { protect, requireAdmin, optionalAuth } = require('../middleware/auth');
const {
  getAllManga,
  getMangaById,
  getTrending,
  getPopular,
  getLatestUpdates,
  createManga,
  updateManga,
  deleteManga
} = require('../controllers/mangaController');

// Public routes (with optional auth for user-specific data)
router.get('/trending', getTrending);
router.get('/popular', getPopular);
router.get('/latest', getLatestUpdates);
router.get('/', getAllManga);
router.get('/:id', optionalAuth, getMangaById);

// Admin routes
router.post('/', protect, requireAdmin, createManga);
router.put('/:id', protect, requireAdmin, updateManga);
router.delete('/:id', protect, requireAdmin, deleteManga);

module.exports = router;
