const express = require('express');
const router = express.Router({ mergeParams: true });
const { protect, requireAdmin, optionalAuth } = require('../middleware/auth');
const { uploadChapterPages } = require('../config/cloudinary');
const {
  getChaptersByManga,
  getChapter,
  createChapter,
  updateChapter,
  deleteChapter
} = require('../controllers/chapterController');

// Public routes
router.get('/', getChaptersByManga);
router.get('/:chapterNumber', optionalAuth, getChapter);

// Admin routes
router.post('/', protect, requireAdmin, uploadChapterPages.array('pages', 50), createChapter);
router.put('/:id', protect, requireAdmin, updateChapter);
router.delete('/:id', protect, requireAdmin, deleteChapter);

module.exports = router;
