const nodemailer = require('nodemailer');

// Create transporter
const transporter = nodemailer.createTransport({
  service: process.env.EMAIL_SERVICE || 'gmail',
  host: process.env.EMAIL_HOST,
  port: process.env.EMAIL_PORT || 587,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASSWORD
  }
});

// Verify connection
transporter.verify((error, success) => {
  if (error) {
    console.error('❌ Email service error:', error);
  } else {
    console.log('✅ Email service ready');
  }
});

// Send email function
const sendEmail = async (options) => {
  const mailOptions = {
    from: `MangaHub <${process.env.EMAIL_FROM || process.env.EMAIL_USER}>`,
    to: options.to,
    subject: options.subject,
    html: options.html,
    text: options.text
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log('Email sent:', info.messageId);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error('Email send error:', error);
    throw error;
  }
};

// Welcome email template
const sendWelcomeEmail = async (user) => {
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h1 style="color: #ff4545;">Selamat Datang di MangaHub! 🎌</h1>
      <p>Halo <strong>${user.name}</strong>,</p>
      <p>Terima kasih sudah bergabung dengan MangaHub - platform baca manga online terbaik di Indonesia!</p>
      <p>Dengan akun kamu, sekarang kamu bisa:</p>
      <ul>
        <li>📖 Bookmark manga favorit</li>
        <li>💬 Komentar dan diskusi</li>
        <li>⭐ Beri rating manga</li>
        <li>📜 Lihat history bacaan</li>
        <li>🔔 Dapat notifikasi chapter baru</li>
      </ul>
      <p>Mulai eksplorasi sekarang:</p>
      <a href="${process.env.FRONTEND_URL}" style="display: inline-block; padding: 12px 24px; background: linear-gradient(135deg, #ff4545, #ff6b35); color: white; text-decoration: none; border-radius: 8px; margin-top: 10px;">
        Mulai Baca Manga
      </a>
      <p style="margin-top: 30px; color: #666;">
        Happy reading! 📚<br>
        Tim MangaHub
      </p>
    </div>
  `;

  return await sendEmail({
    to: user.email,
    subject: 'Selamat Datang di MangaHub! 🎌',
    html
  });
};

// Email verification template
const sendVerificationEmail = async (user, verificationUrl) => {
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h1 style="color: #ff4545;">Verifikasi Email Kamu</h1>
      <p>Halo <strong>${user.name}</strong>,</p>
      <p>Klik tombol di bawah untuk verifikasi email kamu:</p>
      <a href="${verificationUrl}" style="display: inline-block; padding: 12px 24px; background: linear-gradient(135deg, #ff4545, #ff6b35); color: white; text-decoration: none; border-radius: 8px; margin-top: 10px;">
        Verifikasi Email
      </a>
      <p style="margin-top: 20px; color: #666; font-size: 14px;">
        Link ini akan expired dalam 24 jam.<br>
        Jika kamu tidak request ini, abaikan email ini.
      </p>
    </div>
  `;

  return await sendEmail({
    to: user.email,
    subject: 'Verifikasi Email - MangaHub',
    html
  });
};

// VIP upgrade confirmation
const sendVIPUpgradeEmail = async (user, tier, endDate) => {
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h1 style="color: #ffd700;">Selamat! Upgrade ke ${tier} Berhasil! 👑</h1>
      <p>Halo <strong>${user.name}</strong>,</p>
      <p>Pembayaran kamu telah diverifikasi dan upgrade ke <strong>${tier}</strong> berhasil!</p>
      <div style="background: linear-gradient(135deg, #ffd700, #ffed4e); padding: 20px; border-radius: 12px; margin: 20px 0;">
        <h3 style="margin-top: 0; color: #000;">Benefit ${tier}:</h3>
        <ul style="color: #000;">
          ${tier === 'VIP+' ? '<li>✨ Baca chapter lebih awal (early access)</li>' : ''}
          <li>🚫 Bebas iklan</li>
          <li>👑 Badge ${tier} di profil & komentar</li>
          <li>🎯 Akses konten VIP eksklusif</li>
        </ul>
      </div>
      <p>Status VIP kamu aktif sampai: <strong>${new Date(endDate).toLocaleDateString('id-ID')}</strong></p>
      <a href="${process.env.FRONTEND_URL}" style="display: inline-block; padding: 12px 24px; background: linear-gradient(135deg, #ff4545, #ff6b35); color: white; text-decoration: none; border-radius: 8px; margin-top: 10px;">
        Mulai Baca
      </a>
      <p style="margin-top: 30px; color: #666;">
        Terima kasih atas dukungannya! 💖<br>
        Tim MangaHub
      </p>
    </div>
  `;

  return await sendEmail({
    to: user.email,
    subject: `Upgrade ${tier} Berhasil! 👑 - MangaHub`,
    html
  });
};

// New chapter notification
const sendNewChapterEmail = async (user, manga, chapter) => {
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h1 style="color: #ff4545;">Chapter Baru Tersedia! 🔔</h1>
      <p>Halo <strong>${user.name}</strong>,</p>
      <p>Manga yang kamu bookmark ada chapter baru:</p>
      <div style="border: 1px solid #ddd; border-radius: 12px; padding: 15px; margin: 20px 0;">
        <h3 style="margin-top: 0;">${manga.title}</h3>
        <p style="color: #ff4545; font-weight: bold;">Chapter ${chapter.chapterNumber}${chapter.title ? ': ' + chapter.title : ''}</p>
      </div>
      <a href="${process.env.FRONTEND_URL}/read/${manga._id}/${chapter._id}" style="display: inline-block; padding: 12px 24px; background: linear-gradient(135deg, #ff4545, #ff6b35); color: white; text-decoration: none; border-radius: 8px;">
        Baca Sekarang
      </a>
      <p style="margin-top: 20px; color: #666; font-size: 14px;">
        Tidak ingin notifikasi lagi? <a href="${process.env.FRONTEND_URL}/settings">Ubah pengaturan</a>
      </p>
    </div>
  `;

  return await sendEmail({
    to: user.email,
    subject: `${manga.title} - Chapter ${chapter.chapterNumber} Tersedia!`,
    html
  });
};

// Comment reply notification
const sendReplyNotification = async (user, manga, commenter, replyText) => {
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h1 style="color: #ff4545;">Ada yang Reply Komentar Kamu! 💬</h1>
      <p>Halo <strong>${user.name}</strong>,</p>
      <p><strong>${commenter}</strong> reply komentar kamu di <strong>${manga.title}</strong>:</p>
      <div style="background: #f5f5f5; border-left: 4px solid #ff4545; padding: 15px; margin: 20px 0; border-radius: 4px;">
        <p style="margin: 0;">${replyText}</p>
      </div>
      <a href="${process.env.FRONTEND_URL}/manga/${manga._id}#comments" style="display: inline-block; padding: 12px 24px; background: linear-gradient(135deg, #ff4545, #ff6b35); color: white; text-decoration: none; border-radius: 8px;">
        Lihat Reply
      </a>
    </div>
  `;

  return await sendEmail({
    to: user.email,
    subject: `${commenter} reply komentar kamu - MangaHub`,
    html
  });
};

module.exports = {
  sendEmail,
  sendWelcomeEmail,
  sendVerificationEmail,
  sendVIPUpgradeEmail,
  sendNewChapterEmail,
  sendReplyNotification
};
