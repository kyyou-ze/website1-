# MangaHub Backend API

Backend API untuk MangaHub - Platform baca manga online terbaik di Indonesia.

## 🚀 Tech Stack

- **Node.js & Express** - Server framework
- **MongoDB & Mongoose** - Database
- **JWT** - Authentication
- **Google OAuth** - Social login
- **Cloudinary** - Image storage
- **Nodemailer** - Email service
- **Express Validator** - Input validation
- **Helmet** - Security headers
- **Rate Limiting** - API protection

## 📁 Project Structure

```
backend/
├── src/
│   ├── models/              # Mongoose models
│   │   ├── User.js          # User model dengan VIP
│   │   ├── Manga.js         # Manga model
│   │   ├── Chapter.js       # Chapter model
│   │   ├── Comment.js       # Comment dengan nested replies
│   │   ├── Rating.js        # Rating system
│   │   ├── Bookmark.js      # User bookmarks
│   │   ├── Favorite.js      # User favorites
│   │   ├── ReadingHistory.js # Reading history
│   │   └── VIPPayment.js    # VIP payment tracking
│   ├── controllers/         # Route controllers
│   │   ├── authController.js
│   │   └── mangaController.js
│   ├── routes/              # API routes
│   │   ├── authRoutes.js
│   │   └── mangaRoutes.js
│   ├── middleware/          # Custom middleware
│   │   ├── auth.js          # JWT & role-based auth
│   │   ├── errorHandler.js  # Global error handler
│   │   └── validator.js     # Validation middleware
│   ├── config/              # Configuration
│   │   └── database.js      # MongoDB connection
│   ├── utils/               # Utility functions
│   ├── services/            # External services
│   └── server.js            # Entry point
├── package.json
└── .env.example
```

## 🛠️ Installation & Setup

### 1. Install Dependencies

```bash
cd manga-website/backend
npm install
```

### 2. Environment Variables

Copy `.env.example` ke `.env`:
```bash
cp .env.example .env
```

Edit `.env` dan isi semua variables:

```env
# Required
MONGODB_URI=mongodb://localhost:27017/manga-website
JWT_SECRET=your-secret-key
GOOGLE_CLIENT_ID=your-google-client-id

# Cloudinary (untuk upload images)
CLOUDINARY_CLOUD_NAME=your-cloud-name
CLOUDINARY_API_KEY=your-api-key
CLOUDINARY_API_SECRET=your-api-secret

# Email (untuk notifikasi)
EMAIL_USER=your-email@gmail.com
EMAIL_PASSWORD=your-app-password
```

### 3. Start MongoDB

Pastikan MongoDB sudah running:
```bash
# macOS dengan Homebrew
brew services start mongodb-community

# Linux dengan systemctl
sudo systemctl start mongod

# Windows
# Start MongoDB service dari Services
```

### 4. Run Development Server

```bash
npm run dev
```

Server akan berjalan di: `http://localhost:5000`

## 📝 Available Scripts

- `npm start` - Run production server
- `npm run dev` - Run development server dengan nodemon
- `npm run seed` - Seed database dengan dummy data (coming soon)

## 🔑 API Endpoints

### Authentication

| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| POST | `/api/auth/google` | Login dengan Google OAuth | Public |
| GET | `/api/auth/me` | Get current user | Private |
| PUT | `/api/auth/profile` | Update profile | Private |
| POST | `/api/auth/logout` | Logout | Private |

### Manga

| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| GET | `/api/manga` | Get all manga (dengan filters) | Public |
| GET | `/api/manga/trending` | Get trending manga | Public |
| GET | `/api/manga/popular` | Get popular manga | Public |
| GET | `/api/manga/latest` | Get latest updates | Public |
| GET | `/api/manga/:id` | Get manga by ID | Public |
| POST | `/api/manga` | Create new manga | Admin |
| PUT | `/api/manga/:id` | Update manga | Admin |
| DELETE | `/api/manga/:id` | Delete manga | Admin |

### Query Parameters (untuk GET /api/manga)

```
?page=1              # Pagination
&limit=20            # Items per page
&search=naruto       # Text search
&genres=Action,Adventure  # Filter by genres
&status=Ongoing      # Filter by status
&type=Manga          # Filter by type
&sort=-createdAt     # Sort (use - for descending)
```

## 🗃️ Database Models

### User Model
```javascript
{
  name: String,
  email: String,
  googleId: String,
  avatar: String,
  vipStatus: {
    isVIP: Boolean,
    tier: String,      // 'none', 'VIP', 'VIP+'
    startDate: Date,
    endDate: Date
  },
  role: String,        // 'user', 'admin'
  settings: Object,
  // ... more fields
}
```

### Manga Model
```javascript
{
  title: String,
  description: String,
  coverImage: { url, publicId },
  genres: [String],
  status: String,      // 'Ongoing', 'Completed', 'Hiatus'
  isVIPOnly: Boolean,
  stats: {
    totalChapters: Number,
    views: Number,
    favorites: Number,
    bookmarks: Number,
    averageRating: Number,
    totalRatings: Number
  },
  // ... more fields
}
```

### Chapter Model
```javascript
{
  manga: ObjectId,
  chapterNumber: Number,
  title: String,
  pages: [{
    url: String,
    publicId: String,
    pageNumber: Number
  }],
  isVIPOnly: Boolean,
  vipUntil: Date,
  // ... more fields
}
```

## 🔒 Authentication Flow

1. User clicks "Login dengan Google" di frontend
2. Frontend mendapat credential dari Google
3. Frontend POST credential ke `/api/auth/google`
4. Backend verify token dengan Google
5. Backend create/update user di database
6. Backend return JWT token + user data
7. Frontend store token dan redirect

## 🎯 Features

### ✅ Sudah Dibuat (TAHAP 2)
- Basic server setup dengan Express
- MongoDB connection
- User model dengan VIP system
- Manga & Chapter models
- Comment model dengan nested replies
- Rating, Bookmark, Favorite models
- Google OAuth authentication
- JWT-based auth middleware
- Error handling middleware
- Auth & Manga routes
- Basic CRUD controllers

### 🚧 Next Steps (TAHAP 3)
- Chapter routes & controller
- Comment routes & controller
- Rating routes & controller
- Bookmark & Favorite routes
- Reading history tracking
- VIP payment routes
- Admin panel routes
- File upload dengan Cloudinary
- Email notification service
- Search functionality
- Leaderboard system

## 🔐 Security Features

- **Helmet** - Security headers
- **Rate Limiting** - Prevent DDoS
- **JWT** - Secure authentication
- **Password Hashing** - bcrypt
- **Input Validation** - express-validator
- **CORS** - Cross-origin protection
- **MongoDB Injection** - Mongoose sanitization

## 📊 Performance

- **Compression** - Gzip response
- **Database Indexing** - Optimized queries
- **Pagination** - Efficient data loading
- **Caching** - (Coming soon)

## 🐛 Error Handling

Semua errors return format yang konsisten:

```json
{
  "success": false,
  "message": "Error message",
  "errors": [] // optional, untuk validation errors
}
```

## 📧 Email Templates

Email notifications akan dikirim untuk:
- Welcome email (user baru)
- Email verification
- VIP upgrade confirmation
- Chapter update notifications
- Reply notifications

## 💳 VIP System

### Tier Levels
- **VIP** - Akses tanpa iklan
- **VIP+** - Tanpa iklan + Early access

### Payment Flow
1. User pilih tier & period (monthly/yearly)
2. User upload bukti pembayaran
3. Admin verify payment
4. System upgrade user ke VIP
5. Email confirmation sent

## 🧪 Testing

```bash
# Coming soon
npm test
```

## 🚀 Deployment

### VPS Deployment Guide

1. **Setup VPS**
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Install MongoDB
# Follow MongoDB installation guide for your OS
```

2. **Clone & Setup**
```bash
git clone your-repo
cd manga-website/backend
npm install --production
```

3. **Environment Variables**
```bash
cp .env.example .env
nano .env
# Fill in production values
```

4. **Process Manager (PM2)**
```bash
npm install -g pm2
pm2 start src/server.js --name manga-api
pm2 save
pm2 startup
```

5. **Nginx Reverse Proxy**
```nginx
server {
    listen 80;
    server_name api.yourdomain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## 📝 License

MIT License

## 🤝 Contributing

Contributions welcome! Please read CONTRIBUTING.md first.

---

**Backend TAHAP 2 Complete!** Ready untuk TAHAP 3 - Integration & Advanced Features! 🚀
