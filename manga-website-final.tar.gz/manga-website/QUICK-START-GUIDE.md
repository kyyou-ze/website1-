# 🚀 QUICK START GUIDE - Manga Website

Panduan lengkap untuk menjalankan website manga dari awal sampai jalan di localhost.

## 📋 Prerequisites

Pastikan sudah terinstall:
- **Node.js** (v16 atau lebih baru) - [Download](https://nodejs.org/)
- **MongoDB** (v5 atau lebih baru) - [Download](https://www.mongodb.com/try/download/community)
- **Git** (optional, untuk clone repo)

---

## 🔧 STEP 1: Setup MongoDB

### Windows:
```bash
# Download MongoDB dari https://www.mongodb.com/try/download/community
# Install dan jalankan sebagai service
# Atau jalankan manual:
"C:\Program Files\MongoDB\Server\6.0\bin\mongod.exe" --dbpath="C:\data\db"
```

### macOS (dengan Homebrew):
```bash
brew tap mongodb/brew
brew install mongodb-community
brew services start mongodb-community
```

### Linux (Ubuntu/Debian):
```bash
sudo apt install mongodb
sudo systemctl start mongod
sudo systemctl enable mongod
```

### Verify MongoDB Running:
```bash
mongosh
# Jika connect berhasil, ketik:
> show dbs
> exit
```

---

## 📦 STEP 2: Extract & Install Dependencies

### Extract Project:
```bash
tar -xzf manga-website-complete.tar.gz
cd manga-website
```

### Install Backend Dependencies:
```bash
cd backend
npm install
```

**⏱️ Tunggu 2-5 menit** sampai semua packages terinstall.

### Install Frontend Dependencies:
```bash
cd ../frontend
npm install
```

**⏱️ Tunggu 2-5 menit** sampai semua packages terinstall.

---

## ⚙️ STEP 3: Configuration

### Backend Configuration:

```bash
cd backend
cp .env.example .env
```

Edit `.env` file (pakai text editor):

```env
# REQUIRED - Harus diisi
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/manga-website
JWT_SECRET=manga-secret-key-change-this-in-production-12345
FRONTEND_URL=http://localhost:3000

# Google OAuth - Dapatkan dari Google Cloud Console
GOOGLE_CLIENT_ID=your-google-client-id-here

# Cloudinary - Optional untuk development (bisa skip dulu)
# Daftar gratis di https://cloudinary.com
CLOUDINARY_CLOUD_NAME=your-cloud-name
CLOUDINARY_API_KEY=your-api-key
CLOUDINARY_API_SECRET=your-api-secret

# Email - Optional untuk development (bisa skip dulu)
EMAIL_SERVICE=gmail
EMAIL_USER=your-email@gmail.com
EMAIL_PASSWORD=your-app-password
EMAIL_FROM=noreply@mangahub.com
```

**📝 Cara dapat Google Client ID:**

1. Buka [Google Cloud Console](https://console.cloud.google.com/)
2. Buat project baru atau pilih existing project
3. Enable Google+ API
4. Credentials → Create Credentials → OAuth 2.0 Client ID
5. Application type: Web application
6. Authorized redirect URIs: `http://localhost:3000`
7. Copy Client ID ke `.env`

### Frontend Configuration:

```bash
cd ../frontend
cp .env.example .env
```

Edit `.env` file:

```env
REACT_APP_API_URL=http://localhost:5000/api
REACT_APP_GOOGLE_CLIENT_ID=your-google-client-id-here
```

**⚠️ Pastikan GOOGLE_CLIENT_ID sama dengan yang di backend!**

---

## 🚀 STEP 4: Run the Application

Buka **2 terminal windows** atau tabs:

### Terminal 1 - Backend:
```bash
cd manga-website/backend
npm run dev
```

**✅ Expected output:**
```
╔═══════════════════════════════════════════╗
║   🚀 MANGA WEBSITE BACKEND RUNNING        ║
║   Environment: development                ║
║   Port: 5000                              ║
╚═══════════════════════════════════════════╝
✅ MongoDB Connected: localhost
✅ Email service ready (atau error jika belum setup - OK)
```

### Terminal 2 - Frontend:
```bash
cd manga-website/frontend
npm start
```

**✅ Expected output:**
```
Compiled successfully!

You can now view manga-website-frontend in the browser.

  Local:            http://localhost:3000
  On Your Network:  http://192.168.x.x:3000
```

---

## 🌐 STEP 5: Access the Application

Buka browser dan akses:

**Frontend:** `http://localhost:3000`
**Backend API:** `http://localhost:5000/health`

### Test Backend API:
```bash
curl http://localhost:5000/health
```

**Expected response:**
```json
{
  "success": true,
  "message": "Server is running",
  "timestamp": "2024-02-18T..."
}
```

---

## 👤 STEP 6: Create Admin Account

Karena belum ada seeder, kamu perlu create admin manual via MongoDB:

```bash
mongosh
```

```javascript
use manga-website

// Create admin user
db.users.insertOne({
  name: "Admin",
  email: "admin@mangahub.com",
  googleId: "admin-google-id",
  role: "admin",
  emailVerified: true,
  isActive: true,
  vipStatus: {
    isVIP: false,
    tier: "none"
  },
  settings: {
    readingMode: "vertical",
    notifications: {
      email: true,
      newChapter: true,
      replies: true
    }
  },
  createdAt: new Date(),
  updatedAt: new Date()
})

// Verify
db.users.find({ role: "admin" })
```

---

## 📚 STEP 7: Add Test Data (Optional)

Buat test manga via MongoDB:

```javascript
use manga-website

// Insert test manga
db.mangas.insertOne({
  title: "One Piece",
  description: "Monkey D. Luffy mencari harta karun One Piece untuk menjadi Raja Bajak Laut.",
  coverImage: {
    url: "https://picsum.photos/seed/onepiece/800/1200"
  },
  genres: ["Adventure", "Action", "Comedy"],
  status: "Ongoing",
  author: "Eiichiro Oda",
  releaseYear: 1997,
  stats: {
    totalChapters: 0,
    views: 0,
    favorites: 0,
    bookmarks: 0,
    averageRating: 0,
    totalRatings: 0
  },
  isActive: true,
  isFeatured: true,
  uploadedBy: db.users.findOne({ role: "admin" })._id,
  createdAt: new Date(),
  updatedAt: new Date()
})

// Verify
db.mangas.find()
```

---

## ✅ VERIFICATION CHECKLIST

- [ ] MongoDB running (check dengan `mongosh`)
- [ ] Backend running di `http://localhost:5000`
- [ ] Frontend running di `http://localhost:3000`
- [ ] Health check API response OK
- [ ] Homepage loaded tanpa error
- [ ] Google OAuth button muncul di login page

---

## 🐛 Troubleshooting

### MongoDB Connection Error:
```
Error: connect ECONNREFUSED 127.0.0.1:27017
```
**Fix:** Start MongoDB service
```bash
# Windows
net start MongoDB

# macOS
brew services start mongodb-community

# Linux
sudo systemctl start mongod
```

### Port Already in Use:
```
Error: listen EADDRINUSE: address already in use :::5000
```
**Fix:** Kill process atau ganti port
```bash
# Find and kill process
lsof -ti:5000 | xargs kill -9

# Or change port in backend/.env
PORT=5001
```

### Google OAuth Error:
```
Error: invalid_client
```
**Fix:** 
1. Pastikan GOOGLE_CLIENT_ID benar di frontend & backend
2. Pastikan authorized redirect URI sudah setup di Google Console
3. Clear browser cache & cookies

### Module Not Found:
```
Error: Cannot find module 'express'
```
**Fix:** Re-install dependencies
```bash
rm -rf node_modules package-lock.json
npm install
```

### CORS Error:
```
Access to XMLHttpRequest has been blocked by CORS policy
```
**Fix:** Pastikan FRONTEND_URL di backend `.env` correct
```env
FRONTEND_URL=http://localhost:3000
```

---

## 📖 Next Steps

### 1. Test Login
- Klik "Masuk" di homepage
- Login dengan Google account
- Verify redirect ke homepage setelah login

### 2. Upload Manga (Admin)
Belum ada UI, pakai MongoDB atau Postman:
```bash
POST http://localhost:5000/api/manga
Authorization: Bearer YOUR_JWT_TOKEN
Content-Type: application/json

{
  "title": "Naruto",
  "description": "...",
  "coverImage": { "url": "..." },
  "genres": ["Action", "Adventure"],
  "status": "Completed"
}
```

### 3. Test Features
- ✅ Browse manga
- ✅ View manga details
- ✅ Add bookmark/favorite
- ✅ Add comment
- ✅ Rate manga

---

## 🆘 Need Help?

### Check Logs:
- **Backend:** Lihat terminal backend untuk error messages
- **Frontend:** Buka browser DevTools (F12) → Console tab
- **MongoDB:** `mongosh` → `show dbs` → `use manga-website` → `show collections`

### Common Issues:
1. **White screen:** Check browser console for errors
2. **API errors:** Check backend terminal logs
3. **Database errors:** Verify MongoDB is running

---

## 🎉 Success!

Jika semua berjalan lancar, kamu sekarang punya:
- ✅ Backend API running
- ✅ Frontend React app running
- ✅ MongoDB database connected
- ✅ Google OAuth working
- ✅ Full-stack manga website ready!

**Happy coding! 🚀**
