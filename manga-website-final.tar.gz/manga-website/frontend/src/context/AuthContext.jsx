import React, { createContext, useState, useContext, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Check if user is logged in on mount
  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const token = localStorage.getItem('token');
      if (token) {
        // Set default axios header
        axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
        
        // Verify token and get user data
        const response = await axios.get(`${process.env.REACT_APP_API_URL}/auth/me`);
        setUser(response.data.user);
        setIsAuthenticated(true);
      }
    } catch (error) {
      console.error('Auth check failed:', error);
      localStorage.removeItem('token');
      delete axios.defaults.headers.common['Authorization'];
    } finally {
      setLoading(false);
    }
  };

  const loginWithGoogle = async (credential) => {
    try {
      const response = await axios.post(`${process.env.REACT_APP_API_URL}/auth/google`, {
        credential
      });

      const { token, user } = response.data;
      
      // Store token
      localStorage.setItem('token', token);
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      
      // Set user state
      setUser(user);
      setIsAuthenticated(true);
      
      toast.success(`Selamat datang, ${user.name}!`);
      return true;
    } catch (error) {
      console.error('Login failed:', error);
      toast.error('Login gagal. Silakan coba lagi.');
      return false;
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    delete axios.defaults.headers.common['Authorization'];
    setUser(null);
    setIsAuthenticated(false);
    toast.info('Anda telah logout');
  };

  const updateUser = async (updates) => {
    try {
      const response = await axios.put(`${process.env.REACT_APP_API_URL}/auth/profile`, updates);
      setUser(response.data.user);
      toast.success('Profil berhasil diupdate');
      return true;
    } catch (error) {
      console.error('Update failed:', error);
      toast.error('Update profil gagal');
      return false;
    }
  };

  const upgradeToVIP = async (tier, period) => {
    try {
      const response = await axios.post(`${process.env.REACT_APP_API_URL}/vip/upgrade`, {
        tier,
        period
      });
      setUser(response.data.user);
      toast.success(`Selamat! Anda sekarang ${tier}`);
      return true;
    } catch (error) {
      console.error('VIP upgrade failed:', error);
      toast.error('Upgrade VIP gagal');
      return false;
    }
  };

  const value = {
    user,
    isAuthenticated,
    loading,
    loginWithGoogle,
    logout,
    updateUser,
    upgradeToVIP,
    checkAuth
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
