import React, { useState, useRef, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useNotification } from '../../context/NotificationContext';
import {
  FiSearch, FiBell, FiUser, FiBookmark, FiHeart,
  FiClock, FiLogOut, FiSettings, FiMenu, FiX, FiStar,
  FiShield, FiChevronDown, FiHome, FiCalendar,
  FiMessageSquare, FiAward
} from 'react-icons/fi';
import styles from './Navbar.module.css';

export default function Navbar() {
  const { user, isLoggedIn, isAdmin, isVIP, isVIPPlus, logout } = useAuth();
  const { unreadCount, notifications, markAllRead, markRead } = useNotification();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [notifOpen, setNotifOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const notifRef = useRef(null);
  const userRef = useRef(null);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const handleClick = (e) => {
      if (notifRef.current && !notifRef.current.contains(e.target)) setNotifOpen(false);
      if (userRef.current && !userRef.current.contains(e.target)) setUserMenuOpen(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
    setSearchOpen(false);
  }, [location]);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
      setSearchOpen(false);
      setSearchQuery('');
    }
  };

  const navLinks = [
    { to: '/', label: 'Beranda', icon: <FiHome /> },
    { to: '/search', label: 'Manga', icon: <FiSearch /> },
    { to: '/jadwal', label: 'Jadwal', icon: <FiCalendar /> },
    { to: '/leaderboard', label: 'Peringkat', icon: <FiAward /> },
    { to: '/forum', label: 'Forum', icon: <FiMessageSquare /> },
  ];

  return (
    <nav className={`${styles.navbar} ${scrolled ? styles.scrolled : ''}`}>
      <div className={styles.inner}>
        {/* Logo */}
        <Link to="/" className={styles.logo}>
          <span className={styles.logoIcon}>⛩</span>
          <span className={styles.logoText}>MANGA<span className={styles.logoAccent}>KU</span></span>
        </Link>

        {/* Desktop Nav Links */}
        <div className={styles.navLinks}>
          {navLinks.map(link => (
            <Link
              key={link.to}
              to={link.to}
              className={`${styles.navLink} ${location.pathname === link.to ? styles.active : ''}`}
            >
              {link.label}
            </Link>
          ))}
        </div>

        {/* Right Actions */}
        <div className={styles.actions}>
          {/* Search */}
          <button className={styles.iconBtn} onClick={() => setSearchOpen(!searchOpen)}>
            <FiSearch />
          </button>

          {/* Notification */}
          {isLoggedIn && (
            <div className={styles.notifWrapper} ref={notifRef}>
              <button className={styles.iconBtn} onClick={() => {
                setNotifOpen(!notifOpen);
                if (!notifOpen && unreadCount > 0) markAllRead();
              }}>
                <FiBell />
                {unreadCount > 0 && <span className={styles.badge}>{unreadCount > 9 ? '9+' : unreadCount}</span>}
              </button>
              {notifOpen && (
                <div className={styles.dropdown}>
                  <div className={styles.dropdownHeader}>
                    <span>Notifikasi</span>
                  </div>
                  <div className={styles.notifList}>
                    {notifications.length === 0 ? (
                      <div className={styles.emptyNotif}>Tidak ada notifikasi baru</div>
                    ) : notifications.slice(0, 8).map(n => (
                      <div
                        key={n._id}
                        className={`${styles.notifItem} ${!n.read ? styles.unread : ''}`}
                        onClick={() => { markRead(n._id); navigate(n.link || '/'); setNotifOpen(false); }}
                      >
                        <div className={styles.notifIcon}>📢</div>
                        <div className={styles.notifContent}>
                          <p>{n.message}</p>
                          <span>{n.time}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* VIP Badge */}
          {!isLoggedIn && (
            <Link to="/vip" className={`${styles.vipBtn}`}>
              <FiStar /> VIP
            </Link>
          )}

          {/* User Menu */}
          {isLoggedIn ? (
            <div className={styles.userWrapper} ref={userRef}>
              <button className={styles.userBtn} onClick={() => setUserMenuOpen(!userMenuOpen)}>
                <img
                  src={user?.avatar || `https://ui-avatars.com/api/?name=${user?.name}&background=e63946&color=fff`}
                  alt={user?.name}
                  className={styles.avatar}
                />
                {(isVIP || isVIPPlus) && (
                  <span className={`${styles.vipIndicator} ${isVIPPlus ? styles.vipPlus : ''}`}>
                    {isVIPPlus ? '★' : '◆'}
                  </span>
                )}
                <FiChevronDown className={`${styles.chevron} ${userMenuOpen ? styles.chevronUp : ''}`} />
              </button>
              {userMenuOpen && (
                <div className={styles.userDropdown}>
                  <div className={styles.userInfo}>
                    <img
                      src={user?.avatar || `https://ui-avatars.com/api/?name=${user?.name}&background=e63946&color=fff`}
                      alt={user?.name}
                    />
                    <div>
                      <strong>{user?.name}</strong>
                      <span>{isVIPPlus ? 'VIP+' : isVIP ? 'VIP' : 'Member'}</span>
                    </div>
                  </div>
                  <div className={styles.userMenuLinks}>
                    <Link to={`/profil/${user?.username}`}><FiUser /> Profil Saya</Link>
                    <Link to="/bookmark"><FiBookmark /> Bookmark</Link>
                    <Link to="/favorit"><FiHeart /> Favorit</Link>
                    <Link to="/riwayat"><FiClock /> Riwayat Baca</Link>
                    {!isVIP && <Link to="/vip" className={styles.vipLink}><FiStar /> Langganan VIP</Link>}
                    {isAdmin && <Link to="/admin" className={styles.adminLink}><FiShield /> Admin Panel</Link>}
                  </div>
                  <button className={styles.logoutBtn} onClick={logout}>
                    <FiLogOut /> Keluar
                  </button>
                </div>
              )}
            </div>
          ) : (
            <Link to="/login" className={styles.loginBtn}>Masuk</Link>
          )}

          {/* Mobile Menu Toggle */}
          <button className={`${styles.iconBtn} ${styles.mobileToggle}`} onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <FiX /> : <FiMenu />}
          </button>
        </div>
      </div>

      {/* Search Bar */}
      {searchOpen && (
        <div className={styles.searchBar}>
          <form onSubmit={handleSearch} className={styles.searchForm}>
            <FiSearch />
            <input
              type="text"
              placeholder="Cari manga, genre, author..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              autoFocus
            />
            <button type="submit">Cari</button>
          </form>
        </div>
      )}

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className={styles.mobileMenu}>
          {navLinks.map(link => (
            <Link key={link.to} to={link.to} className={styles.mobileLink}>
              {link.icon} {link.label}
            </Link>
          ))}
          {!isLoggedIn && (
            <>
              <Link to="/login" className={styles.mobileLink}><FiUser /> Masuk</Link>
              <Link to="/vip" className={styles.mobileLinkVip}><FiStar /> Langganan VIP</Link>
            </>
          )}
          {isLoggedIn && (
            <>
              <Link to="/bookmark" className={styles.mobileLink}><FiBookmark /> Bookmark</Link>
              <Link to="/favorit" className={styles.mobileLink}><FiHeart /> Favorit</Link>
              <Link to="/riwayat" className={styles.mobileLink}><FiClock /> Riwayat</Link>
              <button className={styles.mobileLogout} onClick={logout}><FiLogOut /> Keluar</button>
            </>
          )}
        </div>
      )}
    </nav>
  );
}
