import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { FiPlay, FiBookmark, FiStar, FiChevronLeft, FiChevronRight } from 'react-icons/fi';
import './Hero.css';

const Hero = ({ featuredManga = [] }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlay, setIsAutoPlay] = useState(true);

  // Sample data - akan diganti dengan data dari API
  const defaultFeatured = [
    {
      id: 1,
      title: 'Jujutsu Kaisen',
      description: 'Yuji Itadori, seorang siswa SMA dengan kemampuan fisik luar biasa, bergabung dengan sekolah sihir untuk melawan kutukan yang mengancam umat manusia.',
      coverImage: 'https://images.unsplash.com/photo-1618336753974-aae8e04506aa?w=1200&h=600&fit=crop',
      rating: 4.8,
      genres: ['Action', 'Supernatural', 'School'],
      chapters: 245,
      status: 'Ongoing'
    },
    {
      id: 2,
      title: 'One Piece',
      description: 'Monkey D. Luffy dan kru bajak lautnya menjelajahi Grand Line untuk menemukan harta karun legendaris One Piece dan menjadi Raja Bajak Laut.',
      coverImage: 'https://images.unsplash.com/photo-1612036782180-6f0b6cd846fe?w=1200&h=600&fit=crop',
      rating: 4.9,
      genres: ['Adventure', 'Fantasy', 'Comedy'],
      chapters: 1098,
      status: 'Ongoing'
    },
    {
      id: 3,
      title: 'Attack on Titan',
      description: 'Dalam dunia yang dikuasai Titan pemakan manusia, Eren Yeager bersumpah untuk membasmi mereka semua setelah kehilangan segalanya.',
      coverImage: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=1200&h=600&fit=crop',
      rating: 4.7,
      genres: ['Action', 'Dark Fantasy', 'Military'],
      chapters: 139,
      status: 'Completed'
    }
  ];

  const featured = featuredManga.length > 0 ? featuredManga : defaultFeatured;
  const current = featured[currentIndex];

  useEffect(() => {
    if (!isAutoPlay) return;
    
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % featured.length);
    }, 6000);

    return () => clearInterval(timer);
  }, [isAutoPlay, featured.length]);

  const handlePrev = () => {
    setIsAutoPlay(false);
    setCurrentIndex((prev) => (prev - 1 + featured.length) % featured.length);
  };

  const handleNext = () => {
    setIsAutoPlay(false);
    setCurrentIndex((prev) => (prev + 1) % featured.length);
  };

  return (
    <div className="hero">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          className="hero-slide"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Background Image with Overlay */}
          <div className="hero-background">
            <motion.img
              src={current.coverImage}
              alt={current.title}
              initial={{ scale: 1.1 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.8 }}
            />
            <div className="hero-overlay"></div>
            <div className="hero-gradient"></div>
          </div>

          {/* Content */}
          <div className="hero-content">
            <motion.div
              className="hero-text"
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.6 }}
            >
              {/* Badge */}
              <motion.div
                className="hero-badge"
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
              >
                <span className="badge-icon">🔥</span>
                <span>Sedang Trending</span>
              </motion.div>

              {/* Title */}
              <motion.h1
                className="hero-title"
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.4 }}
              >
                {current.title}
              </motion.h1>

              {/* Meta Info */}
              <motion.div
                className="hero-meta"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                <div className="meta-item">
                  <FiStar className="star-icon" />
                  <span>{current.rating}</span>
                </div>
                <div className="meta-divider">•</div>
                <div className="meta-item">{current.chapters} Chapter</div>
                <div className="meta-divider">•</div>
                <div className="meta-item">
                  <span className={`status-badge ${current.status.toLowerCase()}`}>
                    {current.status}
                  </span>
                </div>
              </motion.div>

              {/* Genres */}
              <motion.div
                className="hero-genres"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.6 }}
              >
                {current.genres.map((genre, index) => (
                  <span key={index} className="genre-tag">{genre}</span>
                ))}
              </motion.div>

              {/* Description */}
              <motion.p
                className="hero-description"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.7 }}
              >
                {current.description}
              </motion.p>

              {/* Actions */}
              <motion.div
                className="hero-actions"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.8 }}
              >
                <Link to={`/manga/${current.id}`} className="btn-hero-primary">
                  <FiPlay />
                  <span>Mulai Baca</span>
                </Link>
                <button className="btn-hero-secondary">
                  <FiBookmark />
                  <span>Bookmark</span>
                </button>
              </motion.div>
            </motion.div>
          </div>

          {/* Navigation Controls */}
          <div className="hero-controls">
            <button className="control-btn" onClick={handlePrev}>
              <FiChevronLeft />
            </button>
            <button className="control-btn" onClick={handleNext}>
              <FiChevronRight />
            </button>
          </div>

          {/* Indicators */}
          <div className="hero-indicators">
            {featured.map((_, index) => (
              <button
                key={index}
                className={`indicator ${index === currentIndex ? 'active' : ''}`}
                onClick={() => {
                  setIsAutoPlay(false);
                  setCurrentIndex(index);
                }}
              >
                <div className="indicator-progress"></div>
              </button>
            ))}
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default Hero;
