import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import axios from '../../utils/axios';
import { useNavigate } from 'react-router-dom';
import { FiSend, FiCornerDownRight, FiThumbsUp, FiTrash2, FiFlag } from 'react-icons/fi';
import { toast } from 'react-toastify';
import styles from './CommentSection.module.css';
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import 'dayjs/locale/id';
dayjs.extend(relativeTime);
dayjs.locale('id');

export default function CommentSection({ mangaId, chapterId }) {
  const { user, isLoggedIn, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [replyTo, setReplyTo] = useState(null);
  const [replyText, setReplyText] = useState('');

  useEffect(() => {
    fetchComments();
  }, [mangaId, chapterId]);

  const fetchComments = async () => {
    try {
      const params = chapterId ? { chapterId } : { mangaId };
      const res = await axios.get('/api/comments', { params });
      setComments(res.data.comments || mockComments);
    } catch {
      setComments(mockComments);
    } finally {
      setLoading(false);
    }
  };

  const submitComment = async (e) => {
    e.preventDefault();
    if (!isLoggedIn) { navigate('/login'); return; }
    if (!text.trim()) return;
    setSubmitting(true);
    try {
      const res = await axios.post('/api/comments', {
        text, mangaId, chapterId
      });
      setComments(prev => [res.data.comment, ...prev]);
      setText('');
      toast.success('Komentar dikirim!');
    } catch {
      // mock add
      const newComment = {
        _id: Date.now().toString(),
        text,
        user: { name: user.name, avatar: user.avatar, subscription: user.subscription },
        likes: 0,
        createdAt: new Date(),
        replies: []
      };
      setComments(prev => [newComment, ...prev]);
      setText('');
    } finally {
      setSubmitting(false);
    }
  };

  const submitReply = async (commentId) => {
    if (!isLoggedIn) { navigate('/login'); return; }
    if (!replyText.trim()) return;
    try {
      const res = await axios.post(`/api/comments/${commentId}/reply`, { text: replyText });
      setComments(prev => prev.map(c =>
        c._id === commentId
          ? { ...c, replies: [...(c.replies || []), res.data.reply] }
          : c
      ));
      setReplyTo(null);
      setReplyText('');
      toast.success('Balasan dikirim!');
    } catch {
      const newReply = {
        _id: Date.now().toString(),
        text: replyText,
        user: { name: user.name, avatar: user.avatar },
        likes: 0,
        createdAt: new Date()
      };
      setComments(prev => prev.map(c =>
        c._id === commentId
          ? { ...c, replies: [...(c.replies || []), newReply] }
          : c
      ));
      setReplyTo(null);
      setReplyText('');
    }
  };

  const likeComment = async (commentId) => {
    if (!isLoggedIn) { navigate('/login'); return; }
    try {
      await axios.post(`/api/comments/${commentId}/like`);
      setComments(prev => prev.map(c =>
        c._id === commentId ? { ...c, likes: c.likes + 1 } : c
      ));
    } catch {}
  };

  const deleteComment = async (commentId) => {
    if (!window.confirm('Hapus komentar ini?')) return;
    try {
      await axios.delete(`/api/comments/${commentId}`);
      setComments(prev => prev.filter(c => c._id !== commentId));
      toast.success('Komentar dihapus');
    } catch { toast.error('Gagal menghapus'); }
  };

  const reportComment = async (commentId) => {
    try {
      await axios.post(`/api/comments/${commentId}/report`);
      toast.info('Komentar dilaporkan, terima kasih!');
    } catch {}
  };

  const getUserBadge = (subscription) => {
    if (!subscription) return null;
    if (subscription.tier === 'vip_plus') return <span className={styles.badgeVipPlus}>VIP+</span>;
    if (subscription.tier === 'vip') return <span className={styles.badgeVip}>VIP</span>;
    return null;
  };

  return (
    <div className={styles.container}>
      <h3 className={styles.title}>Komentar ({comments.length})</h3>

      {/* Comment Input */}
      <form className={styles.inputForm} onSubmit={submitComment}>
        {isLoggedIn ? (
          <>
            <img
              src={user?.avatar || `https://ui-avatars.com/api/?name=${user?.name}&background=e63946&color=fff`}
              alt={user?.name}
              className={styles.avatar}
            />
            <div className={styles.inputWrapper}>
              <textarea
                value={text}
                onChange={e => setText(e.target.value)}
                placeholder="Tulis komentar kamu..."
                className={styles.input}
                rows={3}
                maxLength={500}
              />
              <div className={styles.inputActions}>
                <span className={styles.charCount}>{text.length}/500</span>
                <button type="submit" className={styles.submitBtn} disabled={submitting || !text.trim()}>
                  <FiSend /> {submitting ? 'Mengirim...' : 'Kirim'}
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className={styles.loginPrompt}>
            <p>Kamu harus <button type="button" onClick={() => navigate('/login')} className={styles.loginLink}>login</button> untuk berkomentar</p>
          </div>
        )}
      </form>

      {/* Comments List */}
      <div className={styles.commentList}>
        {loading ? (
          Array(3).fill(0).map((_, i) => <div key={i} className={`skeleton ${styles.commentSkeleton}`} />)
        ) : comments.length === 0 ? (
          <div className={styles.empty}>Belum ada komentar. Jadilah yang pertama! 💬</div>
        ) : (
          comments.map(comment => (
            <div key={comment._id} className={styles.commentItem}>
              <img
                src={comment.user?.avatar || `https://ui-avatars.com/api/?name=${comment.user?.name}&background=333&color=fff`}
                alt={comment.user?.name}
                className={styles.commentAvatar}
              />
              <div className={styles.commentContent}>
                <div className={styles.commentHeader}>
                  <span className={styles.commentName}>{comment.user?.name}</span>
                  {getUserBadge(comment.user?.subscription)}
                  <span className={styles.commentTime}>{dayjs(comment.createdAt).fromNow()}</span>
                </div>
                <p className={styles.commentText}>{comment.text}</p>
                <div className={styles.commentActions}>
                  <button className={styles.actionBtn} onClick={() => likeComment(comment._id)}>
                    <FiThumbsUp /> {comment.likes || 0}
                  </button>
                  <button className={styles.actionBtn} onClick={() => setReplyTo(replyTo === comment._id ? null : comment._id)}>
                    <FiCornerDownRight /> Balas
                  </button>
                  <button className={styles.actionBtn} onClick={() => reportComment(comment._id)}>
                    <FiFlag />
                  </button>
                  {(isAdmin || comment.user?._id === user?._id) && (
                    <button className={`${styles.actionBtn} ${styles.deleteBtn}`} onClick={() => deleteComment(comment._id)}>
                      <FiTrash2 />
                    </button>
                  )}
                </div>

                {/* Reply Input */}
                {replyTo === comment._id && (
                  <div className={styles.replyInput}>
                    <textarea
                      value={replyText}
                      onChange={e => setReplyText(e.target.value)}
                      placeholder={`Balas ke ${comment.user?.name}...`}
                      className={styles.input}
                      rows={2}
                    />
                    <div className={styles.replyActions}>
                      <button className={styles.cancelBtn} onClick={() => setReplyTo(null)}>Batal</button>
                      <button className={styles.submitBtn} onClick={() => submitReply(comment._id)} disabled={!replyText.trim()}>
                        <FiSend /> Balas
                      </button>
                    </div>
                  </div>
                )}

                {/* Replies */}
                {comment.replies?.length > 0 && (
                  <div className={styles.replies}>
                    {comment.replies.map(reply => (
                      <div key={reply._id} className={styles.replyItem}>
                        <img
                          src={reply.user?.avatar || `https://ui-avatars.com/api/?name=${reply.user?.name}&background=333&color=fff`}
                          alt={reply.user?.name}
                          className={styles.replyAvatar}
                        />
                        <div className={styles.replyContent}>
                          <div className={styles.commentHeader}>
                            <span className={styles.commentName}>{reply.user?.name}</span>
                            {getUserBadge(reply.user?.subscription)}
                            <span className={styles.commentTime}>{dayjs(reply.createdAt).fromNow()}</span>
                          </div>
                          <p className={styles.commentText}>{reply.text}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

const mockComments = [
  {
    _id: '1', text: 'Manga ini keren banget! Plot twist di akhir chapter tidak terduga sama sekali.',
    user: { name: 'Budi Santoso', subscription: { tier: 'vip_plus' } },
    likes: 42, createdAt: new Date(Date.now() - 3600000),
    replies: [
      {
        _id: 'r1', text: 'Setuju! Aku juga kaget sama akhirnya hahaha',
        user: { name: 'Siti Rahayu', subscription: null },
        likes: 8, createdAt: new Date(Date.now() - 1800000)
      }
    ]
  },
  {
    _id: '2', text: 'Update terus ya kak, kami selalu nunggu chapter barunya!',
    user: { name: 'Ahmad Rizki', subscription: { tier: 'vip' } },
    likes: 15, createdAt: new Date(Date.now() - 7200000),
    replies: []
  }
];
