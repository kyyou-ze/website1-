import axios from 'axios';

// Create axios instance with default config
const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:5000/api',
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Request interceptor - add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor - handle errors
api.interceptors.response.use(
  (response) => {
    return response.data; // Return only data
  },
  (error) => {
    // Handle specific error cases
    if (error.response) {
      // Server responded with error
      const { status, data } = error.response;

      if (status === 401) {
        // Unauthorized - clear token and redirect to login
        localStorage.removeItem('token');
        window.location.href = '/login';
      }

      if (status === 403) {
        // Forbidden - show VIP upgrade modal if needed
        if (data.requiresVIP) {
          // Handle VIP required
          console.log('VIP access required');
        }
      }

      return Promise.reject(data || error.response);
    } else if (error.request) {
      // Request made but no response
      return Promise.reject({
        success: false,
        message: 'Tidak dapat terhubung ke server'
      });
    } else {
      // Something else happened
      return Promise.reject({
        success: false,
        message: error.message || 'Terjadi kesalahan'
      });
    }
  }
);

// API methods
export const authAPI = {
  googleLogin: (credential) => api.post('/auth/google', { credential }),
  getMe: () => api.get('/auth/me'),
  updateProfile: (data) => api.put('/auth/profile', data),
  logout: () => api.post('/auth/logout')
};

export const mangaAPI = {
  getAll: (params) => api.get('/manga', { params }),
  getById: (id) => api.get(`/manga/${id}`),
  getTrending: (limit) => api.get('/manga/trending', { params: { limit } }),
  getPopular: (limit) => api.get('/manga/popular', { params: { limit } }),
  getLatest: (limit) => api.get('/manga/latest', { params: { limit } }),
  create: (data) => api.post('/manga', data),
  update: (id, data) => api.put(`/manga/${id}`, data),
  delete: (id) => api.delete(`/manga/${id}`)
};

export const chapterAPI = {
  getByManga: (mangaId) => api.get(`/manga/${mangaId}/chapters`),
  getChapter: (mangaId, chapterNumber) => api.get(`/manga/${mangaId}/chapters/${chapterNumber}`),
  create: (mangaId, formData) => api.post(`/manga/${mangaId}/chapters`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  }),
  update: (mangaId, chapterId, data) => api.put(`/manga/${mangaId}/chapters/${chapterId}`, data),
  delete: (mangaId, chapterId) => api.delete(`/manga/${mangaId}/chapters/${chapterId}`)
};

export const commentAPI = {
  getByManga: (mangaId, params) => api.get(`/comments/manga/${mangaId}`, { params }),
  getByChapter: (chapterId, params) => api.get(`/comments/chapter/${chapterId}`, { params }),
  getReplies: (commentId) => api.get(`/comments/${commentId}/replies`),
  create: (mangaId, data) => api.post(`/comments/manga/${mangaId}`, data),
  update: (commentId, data) => api.put(`/comments/${commentId}`, data),
  delete: (commentId) => api.delete(`/comments/${commentId}`),
  like: (commentId) => api.post(`/comments/${commentId}/like`),
  report: (commentId, reason) => api.post(`/comments/${commentId}/report`, { reason })
};

export const userAPI = {
  getBookmarks: () => api.get('/user/bookmarks'),
  addBookmark: (mangaId) => api.post(`/user/bookmarks/${mangaId}`),
  removeBookmark: (mangaId) => api.delete(`/user/bookmarks/${mangaId}`),
  
  getFavorites: () => api.get('/user/favorites'),
  addFavorite: (mangaId) => api.post(`/user/favorites/${mangaId}`),
  removeFavorite: (mangaId) => api.delete(`/user/favorites/${mangaId}`),
  
  getHistory: (params) => api.get('/user/history', { params }),
  updateHistory: (data) => api.post('/user/history', data),
  
  rateManga: (mangaId, data) => api.post(`/user/rate/${mangaId}`, data),
  getUserRating: (mangaId) => api.get(`/user/rate/${mangaId}`)
};

export const vipAPI = {
  getPricing: () => api.get('/vip/pricing'),
  submitPayment: (formData) => api.post('/vip/payment', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  }),
  getPaymentHistory: () => api.get('/vip/payments'),
  
  // Admin
  getPendingPayments: (status) => api.get('/vip/admin/payments', { params: { status } }),
  verifyPayment: (paymentId) => api.post(`/vip/admin/payments/${paymentId}/verify`),
  rejectPayment: (paymentId, reason) => api.post(`/vip/admin/payments/${paymentId}/reject`, { reason })
};

export const adminAPI = {
  getStats: () => api.get('/admin/stats'),
  getUsers: (params) => api.get('/admin/users', { params }),
  banUser: (userId, data) => api.post(`/admin/users/${userId}/ban`, data),
  unbanUser: (userId) => api.post(`/admin/users/${userId}/unban`),
  getReportedComments: () => api.get('/admin/comments/reported'),
  deleteComment: (commentId) => api.delete(`/admin/comments/${commentId}`)
};

export default api;
