// AdminManga.js - Kelola manga dan upload chapter
import React, { useState, useEffect } from 'react';
import axios from '../../utils/axios';
import { FiPlus, FiEdit2, FiTrash2, FiUpload, FiX } from 'react-icons/fi';
import { toast } from 'react-toastify';

const GENRES_LIST = ['Action', 'Adventure', 'Comedy', 'Drama', 'Fantasy', 'Horror', 'Mystery', 'Romance', 'Sci-Fi', 'Slice of Life', 'Sports', 'Supernatural'];

export default function AdminManga() {
  const [manga, setManga] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [form, setForm] = useState({ title: '', description: '', author: '', artist: '', genres: [], status: 'ongoing', isVIPOnly: false, scheduleDay: 'Senin' });
  const [coverFile, setCoverFile] = useState(null);
  const [coverPreview, setCoverPreview] = useState(null);

  useEffect(() => {
    fetchManga();
  }, []);

  const fetchManga = async () => {
    try {
      const res = await axios.get('/api/admin/manga');
      setManga(res.data.manga || mockMangaList);
    } catch { setManga(mockMangaList); } finally { setLoading(false); }
  };

  const handleCoverChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setCoverFile(file);
    setCoverPreview(URL.createObjectURL(file));
  };

  const toggleGenre = (g) => {
    setForm(prev => ({
      ...prev,
      genres: prev.genres.includes(g) ? prev.genres.filter(x => x !== g) : [...prev.genres, g]
    }));
  };

  const submitManga = async () => {
    if (!form.title) { toast.error('Judul wajib diisi'); return; }
    setUploading(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => fd.append(k, Array.isArray(v) ? JSON.stringify(v) : v));
      if (coverFile) fd.append('cover', coverFile);
      if (editId) {
        await axios.put(`/api/admin/manga/${editId}`, fd, { headers: { 'Content-Type': 'multipart/form-data' } });
        toast.success('Manga diperbarui!');
      } else {
        await axios.post('/api/admin/manga', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
        toast.success('Manga ditambahkan!');
      }
      fetchManga();
      setShowForm(false);
      setForm({ title: '', description: '', author: '', artist: '', genres: [], status: 'ongoing', isVIPOnly: false, scheduleDay: 'Senin' });
      setCoverFile(null); setCoverPreview(null); setEditId(null);
    } catch { toast.error('Gagal menyimpan manga'); } finally { setUploading(false); }
  };

  const deleteManga = async (id) => {
    if (!window.confirm('Hapus manga ini? Semua chapter akan ikut terhapus!')) return;
    try {
      await axios.delete(`/api/admin/manga/${id}`);
      setManga(prev => prev.filter(m => m._id !== id));
      toast.success('Manga dihapus');
    } catch { toast.error('Gagal menghapus'); }
  };

  return (
    <div style={{ minHeight: '100vh', paddingTop: '64px' }}>
      <div style={{ background: 'var(--bg-secondary)', borderBottom: '1px solid var(--border-color)', padding: '24px 32px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1 style={{ fontSize: 24 }}>Kelola Manga</h1>
        <button onClick={() => setShowForm(!showForm)} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 20px', background: 'var(--gradient-primary)', color: 'white', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer' }}>
          <FiPlus /> Tambah Manga
        </button>
      </div>

      <div style={{ maxWidth: 1100, margin: '0 auto', padding: '24px' }}>
        {showForm && (
          <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 12, padding: 24, marginBottom: 24 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 20 }}>
              <h3 style={{ fontSize: 16 }}>{editId ? 'Edit Manga' : 'Tambah Manga Baru'}</h3>
              <button onClick={() => setShowForm(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: 20 }}><FiX /></button>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '200px 1fr', gap: 24 }}>
              <div>
                <label style={{ display: 'block', marginBottom: 8, fontSize: 12, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Cover</label>
                <label style={{ display: 'block', cursor: 'pointer' }}>
                  <div style={{ width: '100%', aspectRatio: '2/3', background: 'var(--bg-elevated)', border: '2px dashed var(--border-color)', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
                    {coverPreview ? <img src={coverPreview} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <FiUpload style={{ fontSize: 24, color: 'var(--text-muted)' }} />}
                  </div>
                  <input type="file" accept="image/*" onChange={handleCoverChange} hidden />
                </label>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {[
                  ['Judul*', 'title', 'text'], ['Judul Alternatif', 'altTitle', 'text'],
                  ['Author*', 'author', 'text'], ['Artist', 'artist', 'text']
                ].map(([label, key, type]) => (
                  <div key={key}>
                    <label style={{ display: 'block', fontSize: 12, color: 'var(--text-muted)', marginBottom: 4, textTransform: 'uppercase' }}>{label}</label>
                    <input type={type} value={form[key] || ''} onChange={e => setForm(p => ({ ...p, [key]: e.target.value }))}
                      style={{ width: '100%', padding: '8px 12px', background: 'var(--bg-elevated)', border: '1px solid var(--border-color)', borderRadius: 6, color: 'var(--text-primary)', fontSize: 14 }} />
                  </div>
                ))}
                <div>
                  <label style={{ display: 'block', fontSize: 12, color: 'var(--text-muted)', marginBottom: 4, textTransform: 'uppercase' }}>Sinopsis</label>
                  <textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} rows={3}
                    style={{ width: '100%', padding: '8px 12px', background: 'var(--bg-elevated)', border: '1px solid var(--border-color)', borderRadius: 6, color: 'var(--text-primary)', fontSize: 14, resize: 'vertical' }} />
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: 12, color: 'var(--text-muted)', marginBottom: 8, textTransform: 'uppercase' }}>Genre</label>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                    {GENRES_LIST.map(g => (
                      <button key={g} type="button" onClick={() => toggleGenre(g)}
                        style={{ padding: '4px 12px', borderRadius: 100, border: '1px solid', borderColor: form.genres.includes(g) ? 'var(--accent-primary)' : 'var(--border-color)', background: form.genres.includes(g) ? 'rgba(230,57,70,0.1)' : 'transparent', color: form.genres.includes(g) ? 'var(--accent-primary)' : 'var(--text-muted)', fontSize: 12, cursor: 'pointer' }}>
                        {g}
                      </button>
                    ))}
                  </div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
                  {[
                    ['Status', 'status', [['ongoing', 'Ongoing'], ['completed', 'Tamat'], ['hiatus', 'Hiatus']]],
                    ['Jadwal', 'scheduleDay', [['Senin', 'Senin'], ['Selasa', 'Selasa'], ['Rabu', 'Rabu'], ['Kamis', 'Kamis'], ['Jumat', 'Jumat'], ['Sabtu', 'Sabtu'], ['Minggu', 'Minggu']]]
                  ].map(([label, key, opts]) => (
                    <div key={key}>
                      <label style={{ display: 'block', fontSize: 12, color: 'var(--text-muted)', marginBottom: 4, textTransform: 'uppercase' }}>{label}</label>
                      <select value={form[key]} onChange={e => setForm(p => ({ ...p, [key]: e.target.value }))}
                        style={{ width: '100%', padding: '8px 12px', background: 'var(--bg-elevated)', border: '1px solid var(--border-color)', borderRadius: 6, color: 'var(--text-primary)', fontSize: 14 }}>
                        {opts.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                      </select>
                    </div>
                  ))}
                  <div>
                    <label style={{ display: 'block', fontSize: 12, color: 'var(--text-muted)', marginBottom: 4, textTransform: 'uppercase' }}>Konten VIP</label>
                    <label style={{ display: 'flex', alignItems: 'center', gap: 8, height: 36 }}>
                      <input type="checkbox" checked={form.isVIPOnly} onChange={e => setForm(p => ({ ...p, isVIPOnly: e.target.checked }))} style={{ width: 16, height: 16 }} />
                      <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>Hanya VIP</span>
                    </label>
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 8 }}>
                  <button onClick={() => setShowForm(false)} style={{ padding: '9px 20px', background: 'transparent', border: '1px solid var(--border-color)', borderRadius: 8, color: 'var(--text-secondary)', cursor: 'pointer' }}>Batal</button>
                  <button onClick={submitManga} disabled={uploading} style={{ padding: '9px 24px', background: 'var(--gradient-primary)', color: 'white', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer', opacity: uploading ? 0.6 : 1 }}>
                    {uploading ? 'Menyimpan...' : editId ? 'Perbarui' : 'Tambahkan'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 12, overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border-color)' }}>
                {['Cover', 'Judul', 'Author', 'Chapter', 'Status', 'Tipe', 'Aksi'].map(h => (
                  <th key={h} style={{ padding: '14px 16px', textAlign: 'left', fontSize: 12, color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? Array(5).fill(0).map((_, i) => (
                <tr key={i}><td colSpan={7} style={{ padding: 16 }}><div className="skeleton" style={{ height: 40, borderRadius: 4 }} /></td></tr>
              )) : manga.map(m => (
                <tr key={m._id} style={{ borderBottom: '1px solid rgba(255,255,255,0.03)' }}>
                  <td style={{ padding: '12px 16px' }}><img src={m.cover} style={{ width: 36, height: 48, objectFit: 'cover', borderRadius: 4 }} /></td>
                  <td style={{ padding: '12px 16px', fontSize: 14, fontWeight: 600, color: 'var(--text-primary)', maxWidth: 200 }}>{m.title}</td>
                  <td style={{ padding: '12px 16px', fontSize: 13, color: 'var(--text-muted)' }}>{m.author}</td>
                  <td style={{ padding: '12px 16px', fontSize: 13, color: 'var(--accent-primary)', fontWeight: 600 }}>{m.totalChapters} Ch</td>
                  <td style={{ padding: '12px 16px' }}>
                    <span style={{ padding: '2px 10px', borderRadius: 100, fontSize: 11, fontWeight: 700, background: m.status === 'ongoing' ? 'rgba(34,197,94,0.15)' : 'rgba(99,102,241,0.15)', color: m.status === 'ongoing' ? '#22c55e' : '#818cf8' }}>
                      {m.status === 'ongoing' ? 'Ongoing' : 'Tamat'}
                    </span>
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    {m.isVIPOnly && <span style={{ padding: '2px 8px', background: 'var(--gradient-vip)', color: 'white', borderRadius: 4, fontSize: 10, fontWeight: 700 }}>VIP</span>}
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ display: 'flex', gap: 6 }}>
                      <button onClick={() => { setEditId(m._id); setForm({ ...m }); setShowForm(true); }}
                        style={{ width: 32, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(59,130,246,0.1)', border: '1px solid rgba(59,130,246,0.2)', borderRadius: 6, color: '#3b82f6', cursor: 'pointer' }}>
                        <FiEdit2 />
                      </button>
                      <button onClick={() => deleteManga(m._id)}
                        style={{ width: 32, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(230,57,70,0.1)', border: '1px solid rgba(230,57,70,0.2)', borderRadius: 6, color: 'var(--accent-primary)', cursor: 'pointer' }}>
                        <FiTrash2 />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

const mockMangaList = Array(10).fill(0).map((_, i) => ({
  _id: String(i), title: `Manga Admin ${i + 1}`, author: `Author ${i + 1}`, totalChapters: 50 + i,
  status: i % 3 === 0 ? 'completed' : 'ongoing', isVIPOnly: i % 4 === 0,
  cover: `https://via.placeholder.com/36x48/16161f/e63946?text=M`
}));
