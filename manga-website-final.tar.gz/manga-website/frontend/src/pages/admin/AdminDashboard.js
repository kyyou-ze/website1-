import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from '../../utils/axios';
import { FiUsers, FiBook, FiDollarSign, FiMessageSquare, FiTrendingUp, FiShield, FiTag, FiFlag } from 'react-icons/fi';
import styles from './AdminDashboard.module.css';

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [recentPayments, setRecentPayments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      try {
        const [statsRes, paymentsRes] = await Promise.all([
          axios.get('/api/admin/stats'),
          axios.get('/api/admin/payments?limit=5&status=pending')
        ]);
        setStats(statsRes.data || mockStats);
        setRecentPayments(paymentsRes.data.payments || mockPayments);
      } catch { setStats(mockStats); setRecentPayments(mockPayments); } finally { setLoading(false); }
    };
    fetch();
  }, []);

  const statCards = [
    { icon: <FiBook />, label: 'Total Manga', value: stats?.totalManga || 0, color: '#e63946', link: '/admin/manga' },
    { icon: <FiUsers />, label: 'Total Pengguna', value: stats?.totalUsers || 0, color: '#3b82f6', link: '/admin/pengguna' },
    { icon: <FiDollarSign />, label: 'Subscriber VIP', value: stats?.totalVIP || 0, color: '#c084fc', link: '/admin/pembayaran' },
    { icon: <FiMessageSquare />, label: 'Laporan Komentar', value: stats?.reportedComments || 0, color: '#f59e0b', link: '/admin/komentar' },
  ];

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <h1>Admin Dashboard</h1>
        <p>Selamat datang di panel admin MangaKu</p>
      </div>

      <div className={styles.content}>
        {/* Stats */}
        <div className={styles.statsGrid}>
          {statCards.map(card => (
            <Link key={card.label} to={card.link} className={styles.statCard}>
              <div className={styles.statIcon} style={{ background: `${card.color}20`, color: card.color }}>
                {card.icon}
              </div>
              <div>
                <div className={styles.statValue}>{loading ? '...' : card.value.toLocaleString()}</div>
                <div className={styles.statLabel}>{card.label}</div>
              </div>
            </Link>
          ))}
        </div>

        {/* Quick Actions */}
        <div className={styles.section}>
          <h2 className={styles.sectionTitle}>Aksi Cepat</h2>
          <div className={styles.quickActions}>
            <Link to="/admin/manga" className={styles.quickAction}>
              <FiBook /> Tambah Manga
            </Link>
            <Link to="/admin/pembayaran" className={styles.quickAction}>
              <FiDollarSign /> Verifikasi Pembayaran
            </Link>
            <Link to="/admin/komentar" className={styles.quickAction}>
              <FiFlag /> Tinjau Laporan
            </Link>
            <Link to="/admin/promo" className={styles.quickAction}>
              <FiTag /> Kelola Promo
            </Link>
          </div>
        </div>

        {/* Pending Payments */}
        <div className={styles.section}>
          <h2 className={styles.sectionTitle}>Pembayaran Menunggu Verifikasi</h2>
          <div className={styles.paymentList}>
            {loading ? (
              Array(3).fill(0).map((_, i) => <div key={i} className={`skeleton ${styles.paymentSkeleton}`} />)
            ) : recentPayments.length === 0 ? (
              <div className={styles.empty}>✅ Semua pembayaran sudah diverifikasi</div>
            ) : recentPayments.map(p => (
              <div key={p._id} className={styles.paymentItem}>
                <div>
                  <strong>{p.user?.name}</strong>
                  <span className={styles.paymentPlan}>{p.plan === 'vip_plus' ? 'VIP+' : 'VIP'} · {p.period === 'monthly' ? 'Bulanan' : 'Tahunan'}</span>
                </div>
                <div className={styles.paymentRight}>
                  <span className={styles.paymentMethod}>{p.paymentMethod?.toUpperCase()}</span>
                  <span className={styles.paymentAmount}>Rp{p.amount?.toLocaleString('id-ID')}</span>
                  <Link to="/admin/pembayaran" className={styles.verifyBtn}>Verifikasi</Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

const mockStats = { totalManga: 247, totalUsers: 12543, totalVIP: 384, reportedComments: 7 };
const mockPayments = [
  { _id: '1', user: { name: 'Budi Santoso' }, plan: 'vip_plus', period: 'monthly', paymentMethod: 'dana', amount: 49000 },
  { _id: '2', user: { name: 'Siti Rahayu' }, plan: 'vip', period: 'yearly', paymentMethod: 'gopay', amount: 299000 },
];
