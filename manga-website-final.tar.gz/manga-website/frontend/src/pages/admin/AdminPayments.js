// AdminPayments.js
import React, { useState, useEffect } from 'react';
import axios from '../../utils/axios';
import { toast } from 'react-toastify';
import { FiCheck, FiX, FiEye } from 'react-icons/fi';

export default function AdminPayments() {
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('pending');
  const [proofModal, setProofModal] = useState(null);

  useEffect(() => {
    const fetch = async () => {
      setLoading(true);
      try {
        const res = await axios.get(`/api/admin/payments?status=${filter}`);
        setPayments(res.data.payments || mockPayments);
      } catch { setPayments(mockPayments); } finally { setLoading(false); }
    };
    fetch();
  }, [filter]);

  const verifyPayment = async (id, action) => {
    try {
      await axios.put(`/api/admin/payments/${id}`, { status: action });
      setPayments(prev => prev.filter(p => p._id !== id));
      toast.success(action === 'approved' ? '✅ Pembayaran disetujui!' : '❌ Pembayaran ditolak');
    } catch { toast.error('Gagal memproses'); }
  };

  return (
    <div style={{ minHeight: '100vh', paddingTop: '64px' }}>
      {proofModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.8)', zIndex: 3000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }} onClick={() => setProofModal(null)}>
          <div style={{ background: 'var(--bg-card)', borderRadius: 12, padding: 16, maxWidth: 500, width: '100%' }} onClick={e => e.stopPropagation()}>
            <img src={proofModal} style={{ width: '100%', borderRadius: 8 }} alt="Bukti Pembayaran" />
            <button onClick={() => setProofModal(null)} style={{ marginTop: 12, width: '100%', padding: 10, background: 'var(--bg-elevated)', border: 'none', borderRadius: 8, color: 'var(--text-secondary)', cursor: 'pointer' }}>Tutup</button>
          </div>
        </div>
      )}
      <div style={{ background: 'var(--bg-secondary)', borderBottom: '1px solid var(--border-color)', padding: '24px 32px' }}>
        <h1 style={{ fontSize: 24 }}>Verifikasi Pembayaran VIP</h1>
      </div>
      <div style={{ maxWidth: 1000, margin: '0 auto', padding: 24 }}>
        <div style={{ display: 'flex', gap: 4, marginBottom: 24 }}>
          {[['pending', 'Menunggu'], ['approved', 'Disetujui'], ['rejected', 'Ditolak']].map(([v, l]) => (
            <button key={v} onClick={() => setFilter(v)}
              style={{ padding: '8px 20px', border: '1px solid', borderColor: filter === v ? 'var(--accent-primary)' : 'var(--border-color)', borderRadius: 8, background: filter === v ? 'rgba(230,57,70,0.1)' : 'transparent', color: filter === v ? 'var(--accent-primary)' : 'var(--text-secondary)', fontSize: 13, cursor: 'pointer' }}>
              {l}
            </button>
          ))}
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {loading ? Array(4).fill(0).map((_, i) => <div key={i} className="skeleton" style={{ height: 80, borderRadius: 8 }} />) :
            payments.length === 0 ? <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)' }}>Tidak ada pembayaran</div> :
            payments.map(p => (
              <div key={p._id} style={{ display: 'flex', alignItems: 'center', gap: 16, padding: 16, background: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 8 }}>
                <div style={{ flex: 1 }}>
                  <p style={{ fontWeight: 700, marginBottom: 4 }}>{p.user?.name} <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>({p.user?.email})</span></p>
                  <div style={{ display: 'flex', gap: 12, fontSize: 13, color: 'var(--text-secondary)' }}>
                    <span>Paket: <strong style={{ color: 'var(--accent-vip)' }}>{p.plan === 'vip_plus' ? 'VIP+' : 'VIP'}</strong></span>
                    <span>Periode: {p.period === 'monthly' ? 'Bulanan' : 'Tahunan'}</span>
                    <span>Via: {p.paymentMethod?.toUpperCase()}</span>
                    <span style={{ color: 'var(--accent-primary)', fontWeight: 700 }}>Rp{p.amount?.toLocaleString('id-ID')}</span>
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button onClick={() => setProofModal(p.proofImage || 'https://via.placeholder.com/400x300/16161f/ffffff?text=Bukti+Transfer')}
                    style={{ width: 36, height: 36, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(99,102,241,0.1)', border: '1px solid rgba(99,102,241,0.2)', borderRadius: 6, color: '#818cf8', cursor: 'pointer' }}>
                    <FiEye />
                  </button>
                  {filter === 'pending' && (
                    <>
                      <button onClick={() => verifyPayment(p._id, 'approved')}
                        style={{ width: 36, height: 36, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(34,197,94,0.1)', border: '1px solid rgba(34,197,94,0.2)', borderRadius: 6, color: '#22c55e', cursor: 'pointer' }}>
                        <FiCheck />
                      </button>
                      <button onClick={() => verifyPayment(p._id, 'rejected')}
                        style={{ width: 36, height: 36, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(230,57,70,0.1)', border: '1px solid rgba(230,57,70,0.2)', borderRadius: 6, color: 'var(--accent-primary)', cursor: 'pointer' }}>
                        <FiX />
                      </button>
                    </>
                  )}
                </div>
              </div>
            ))
          }
        </div>
      </div>
    </div>
  );
}

const mockPayments = Array(5).fill(0).map((_, i) => ({
  _id: String(i), user: { name: `User ${i + 1}`, email: `user${i + 1}@email.com` },
  plan: i % 2 === 0 ? 'vip_plus' : 'vip', period: i % 3 === 0 ? 'yearly' : 'monthly',
  paymentMethod: ['dana', 'gopay', 'ovo'][i % 3],
  amount: i % 2 === 0 ? 49000 : 29000, proofImage: null
}));
