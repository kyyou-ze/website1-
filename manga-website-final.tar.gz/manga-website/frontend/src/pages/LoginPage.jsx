import React from 'react';
import { GoogleLogin } from '@react-oauth/google';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import './LoginPage.css';

const LoginPage = () => {
  const { loginWithGoogle, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  React.useEffect(() => {
    if (isAuthenticated) {
      navigate('/');
    }
  }, [isAuthenticated, navigate]);

  const handleSuccess = async (credentialResponse) => {
    const success = await loginWithGoogle(credentialResponse.credential);
    if (success) {
      navigate('/');
    }
  };

  const handleError = () => {
    console.error('Login Failed');
  };

  return (
    <div className="login-page">
      <div className="login-container">
        <div className="login-box">
          <div className="login-header">
            <h1>Selamat Datang</h1>
            <p>Masuk untuk mengakses semua fitur MangaHub</p>
          </div>

          <div className="login-content">
            <GoogleLogin
              onSuccess={handleSuccess}
              onError={handleError}
              useOneTap
              theme="filled_black"
              size="large"
              text="continue_with"
              shape="rectangular"
            />

            <div className="login-features">
              <h3>Dengan masuk, kamu bisa:</h3>
              <ul>
                <li>📖 Bookmark manga favoritmu</li>
                <li>💬 Komentar dan diskusi</li>
                <li>⭐ Beri rating manga</li>
                <li>📜 Lihat history bacaan</li>
                <li>🔔 Notifikasi chapter baru</li>
                <li>👑 Upgrade ke VIP</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
