// LoginPage.js
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { GoogleLogin } from '@react-oauth/google';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import styles from './LoginPage.module.css';

export default function LoginPage() {
  const { loginWithGoogle, isLoggedIn } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (isLoggedIn) navigate('/');
  }, [isLoggedIn]);

  const handleGoogleSuccess = async (credentialResponse) => {
    try {
      const user = await loginWithGoogle(credentialResponse.credential);
      toast.success(`Selamat datang, ${user.name}!`);
      navigate('/');
    } catch {
      toast.error('Login gagal, coba lagi');
    }
  };

  return (
    <div className={styles.page}>
      <div className={styles.card}>
        <div className={styles.logo}>
          <span>⛩</span>
          <h1>MANGA<span>KU</span></h1>
        </div>
        <h2>Masuk ke akun kamu</h2>
        <p>Nikmati manga tanpa batas dengan akun MangaKu</p>
        <div className={styles.googleBtn}>
          <GoogleLogin
            onSuccess={handleGoogleSuccess}
            onError={() => toast.error('Login gagal')}
            theme="filled_black"
            size="large"
            width="300"
            text="signin_with"
            locale="id"
          />
        </div>
        <div className={styles.features}>
          <div className={styles.feature}><span>🔖</span> Bookmark manga favorit</div>
          <div className={styles.feature}><span>💬</span> Komentar & diskusi</div>
          <div className={styles.feature}><span>📜</span> Riwayat baca tersimpan</div>
          <div className={styles.feature}><span>🔔</span> Notifikasi chapter baru</div>
        </div>
        <p className={styles.terms}>Dengan masuk, kamu menyetujui <a href="/terms">Syarat & Ketentuan</a> kami</p>
      </div>
    </div>
  );
}
