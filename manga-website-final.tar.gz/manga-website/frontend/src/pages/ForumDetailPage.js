import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import axios from '../utils/axios';
import { useAuth } from '../context/AuthContext';
import { FiArrowLeft, FiSend } from 'react-icons/fi';
import { toast } from 'react-toastify';
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import 'dayjs/locale/id';
dayjs.extend(relativeTime);
dayjs.locale('id');

export default function ForumDetailPage() {
  const { threadId } = useParams();
  const { user, isLoggedIn } = useAuth();
  const navigate = useNavigate();
  const [thread, setThread] = useState(null);
  const [replies, setReplies] = useState([]);
  const [replyText, setReplyText] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      try {
        const res = await axios.get(`/api/forum/${threadId}`);
        setThread(res.data.thread || mockThread);
        setReplies(res.data.replies || mockReplies);
      } catch { setThread(mockThread); setReplies(mockReplies); } finally { setLoading(false); }
    };
    fetch();
  }, [threadId]);

  const submitReply = async () => {
    if (!isLoggedIn) { navigate('/login'); return; }
    if (!replyText.trim()) return;
    try {
      const res = await axios.post(`/api/forum/${threadId}/reply`, { content: replyText });
      setReplies(prev => [...prev, res.data.reply]);
      setReplyText('');
      toast.success('Balasan dikirim!');
    } catch {
      const r = { _id: Date.now(), content: replyText, author: { name: user?.name }, createdAt: new Date() };
      setReplies(prev => [...prev, r]);
      setReplyText('');
    }
  };

  if (loading) return <div style={{ minHeight: '100vh', paddingTop: 100, textAlign: 'center', color: 'var(--text-muted)' }}>Memuat...</div>;

  return (
    <div style={{ minHeight: '100vh', paddingTop: '64px' }}>
      <div style={{ maxWidth: 800, margin: '0 auto', padding: '32px 24px 60px' }}>
        <button onClick={() => navigate('/forum')} style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'none', border: 'none', color: 'var(--accent-primary)', cursor: 'pointer', marginBottom: 24, fontSize: 14 }}>
          <FiArrowLeft /> Kembali ke Forum
        </button>
        {thread && (
          <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 12, padding: 24, marginBottom: 24 }}>
            <span style={{ padding: '2px 10px', background: 'rgba(230,57,70,0.1)', color: 'var(--accent-primary)', borderRadius: 4, fontSize: 11, fontWeight: 700, textTransform: 'uppercase', display: 'inline-block', marginBottom: 12 }}>{thread.category}</span>
            <h1 style={{ fontSize: 22, marginBottom: 12 }}>{thread.title}</h1>
            <p style={{ color: 'var(--text-secondary)', lineHeight: 1.7, marginBottom: 16 }}>{thread.content}</p>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--text-muted)' }}>
              <span>Oleh <strong style={{ color: 'var(--text-secondary)' }}>{thread.author?.name}</strong></span>
              <span>{dayjs(thread.createdAt).fromNow()}</span>
            </div>
          </div>
        )}

        <h3 style={{ marginBottom: 16, fontSize: 16 }}>{replies.length} Balasan</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 24 }}>
          {replies.map(r => (
            <div key={r._id} style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 8, padding: 16 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                <strong style={{ fontSize: 13 }}>{r.author?.name}</strong>
                <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{dayjs(r.createdAt).fromNow()}</span>
              </div>
              <p style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.6 }}>{r.content}</p>
            </div>
          ))}
        </div>

        <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 12, padding: 16 }}>
          <h4 style={{ marginBottom: 12, fontSize: 14 }}>Tulis Balasan</h4>
          <textarea value={replyText} onChange={e => setReplyText(e.target.value)}
            placeholder={isLoggedIn ? 'Tulis balasan...' : 'Login untuk membalas...'}
            disabled={!isLoggedIn} rows={4}
            style={{ width: '100%', padding: '10px 14px', background: 'var(--bg-elevated)', border: '1px solid var(--border-color)', borderRadius: 8, color: 'var(--text-primary)', fontSize: 14, resize: 'vertical', marginBottom: 12 }} />
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <button onClick={submitReply} disabled={!replyText.trim() || !isLoggedIn}
              style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 20px', background: 'var(--gradient-primary)', color: 'white', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer', opacity: (!replyText.trim() || !isLoggedIn) ? 0.5 : 1 }}>
              <FiSend /> Balas
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

const mockThread = { _id: '1', title: 'Diskusi Manga Favorit', content: 'Mari kita diskusikan manga favorit kita dan berbagi rekomendasi!', category: 'diskusi', author: { name: 'Budi Santoso' }, createdAt: new Date(Date.now() - 86400000) };
const mockReplies = Array(5).fill(0).map((_, i) => ({ _id: String(i), content: `Ini adalah balasan ${i + 1} dari diskusi ini.`, author: { name: `User ${i + 1}` }, createdAt: new Date(Date.now() - (5 - i) * 3600000) }));
