import React from 'react';
import { Link } from 'react-router-dom';

const NotFoundPage = () => {
  return (
    <div style={{ minHeight: 'calc(100vh - 70px)', marginTop: '70px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '2rem' }}>
      <h1 style={{ fontSize: '6rem', fontFamily: 'var(--font-display)', background: 'var(--accent-gradient)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>404</h1>
      <h2 style={{ fontSize: '2rem', marginBottom: '1rem' }}>Halaman Tidak Ditemukan</h2>
      <p style={{ color: 'var(--text-secondary)', marginBottom: '2rem' }}>Halaman yang kamu cari tidak ada atau telah dipindahkan.</p>
      <Link to="/" style={{ padding: '1rem 2rem', background: 'var(--accent-gradient)', color: 'white', borderRadius: 'var(--radius-lg)', fontFamily: 'var(--font-display)', fontWeight: '600' }}>
        Kembali ke Beranda
      </Link>
    </div>
  );
};

export default NotFoundPage;
