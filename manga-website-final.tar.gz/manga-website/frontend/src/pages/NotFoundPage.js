import React from 'react';
import { Link } from 'react-router-dom';

export default function NotFoundPage() {
  return (
    <div style={{ minHeight: '100vh', paddingTop: '64px', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 16, textAlign: 'center', padding: 24 }}>
      <div style={{ fontSize: 80, marginBottom: 8 }}>⛩</div>
      <h1 style={{ fontSize: 48, color: 'var(--accent-primary)' }}>404</h1>
      <p style={{ fontSize: 20, color: 'var(--text-primary)', marginBottom: 4 }}>Halaman Tidak Ditemukan</p>
      <p style={{ color: 'var(--text-muted)', maxWidth: 400 }}>Maaf, halaman yang kamu cari tidak ada atau sudah dipindahkan.</p>
      <Link to="/" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, marginTop: 16, padding: '12px 28px', background: 'var(--gradient-primary)', color: 'white', borderRadius: 8, fontWeight: 600, textDecoration: 'none' }}>
        ← Kembali ke Beranda
      </Link>
    </div>
  );
}
