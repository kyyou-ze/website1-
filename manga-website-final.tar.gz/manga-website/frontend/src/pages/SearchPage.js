import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import axios from '../utils/axios';
import MangaCard from '../components/manga/MangaCard';
import { FiSearch, FiFilter, FiX } from 'react-icons/fi';
import styles from './SearchPage.module.css';

const GENRES = ['Action', 'Adventure', 'Comedy', 'Drama', 'Fantasy', 'Horror', 'Mystery', 'Romance', 'Sci-Fi', 'Slice of Life', 'Sports', 'Supernatural', 'Thriller', 'Isekai', 'Mecha'];
const STATUSES = [{ value: '', label: 'Semua Status' }, { value: 'ongoing', label: 'Ongoing' }, { value: 'completed', label: 'Tamat' }];
const SORTS = [
  { value: 'latest', label: 'Terbaru' }, { value: 'popular', label: 'Terpopuler' },
  { value: 'rating', label: 'Rating Tertinggi' }, { value: 'title', label: 'A-Z' }
];

export default function SearchPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [manga, setManga] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showFilter, setShowFilter] = useState(false);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);

  const [query, setQuery] = useState(searchParams.get('q') || '');
  const [selectedGenres, setSelectedGenres] = useState(
    searchParams.get('genre') ? [searchParams.get('genre')] : []
  );
  const [status, setStatus] = useState(searchParams.get('status') || '');
  const [sort, setSort] = useState(searchParams.get('sort') || 'latest');

  useEffect(() => {
    fetchManga();
  }, [query, selectedGenres, status, sort, page]);

  const fetchManga = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        q: query, status, sort, page, limit: 24,
        genres: selectedGenres.join(',')
      });
      const res = await axios.get(`/api/manga?${params}`);
      setManga(res.data.manga || mockManga);
      setTotal(res.data.total || mockManga.length);
    } catch {
      setManga(mockManga);
      setTotal(mockManga.length);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    setPage(1);
    fetchManga();
  };

  const toggleGenre = (genre) => {
    setSelectedGenres(prev =>
      prev.includes(genre) ? prev.filter(g => g !== genre) : [...prev, genre]
    );
    setPage(1);
  };

  const clearFilters = () => {
    setSelectedGenres([]);
    setStatus('');
    setSort('latest');
    setQuery('');
    setPage(1);
  };

  const activeFilterCount = selectedGenres.length + (status ? 1 : 0);

  return (
    <div className={styles.page}>
      <div className={styles.pageHeader}>
        <h1 className={styles.pageTitle}>Cari Manga</h1>
        <p className={styles.pageDesc}>Temukan manga favoritmu dari koleksi kami</p>
      </div>

      <div className={styles.container}>
        {/* Search Bar */}
        <form onSubmit={handleSearch} className={styles.searchBar}>
          <FiSearch className={styles.searchIcon} />
          <input
            type="text"
            placeholder="Cari judul, author, genre..."
            value={query}
            onChange={e => setQuery(e.target.value)}
            className={styles.searchInput}
          />
          {query && (
            <button type="button" onClick={() => { setQuery(''); setPage(1); }} className={styles.clearBtn}>
              <FiX />
            </button>
          )}
          <button type="submit" className={styles.searchBtn}>Cari</button>
          <button
            type="button"
            className={`${styles.filterToggle} ${activeFilterCount > 0 ? styles.filterActive : ''}`}
            onClick={() => setShowFilter(!showFilter)}
          >
            <FiFilter /> Filter {activeFilterCount > 0 && <span className={styles.filterCount}>{activeFilterCount}</span>}
          </button>
        </form>

        {/* Filter Panel */}
        {showFilter && (
          <div className={styles.filterPanel}>
            <div className={styles.filterSection}>
              <label>Genre</label>
              <div className={styles.genreTags}>
                {GENRES.map(g => (
                  <button
                    key={g}
                    className={`${styles.genreTag} ${selectedGenres.includes(g) ? styles.genreTagActive : ''}`}
                    onClick={() => toggleGenre(g)}
                  >
                    {g}
                  </button>
                ))}
              </div>
            </div>
            <div className={styles.filterRow}>
              <div className={styles.filterSection}>
                <label>Status</label>
                <div className={styles.filterBtns}>
                  {STATUSES.map(s => (
                    <button
                      key={s.value}
                      className={`${styles.filterBtn} ${status === s.value ? styles.filterBtnActive : ''}`}
                      onClick={() => { setStatus(s.value); setPage(1); }}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>
              <div className={styles.filterSection}>
                <label>Urutkan</label>
                <div className={styles.filterBtns}>
                  {SORTS.map(s => (
                    <button
                      key={s.value}
                      className={`${styles.filterBtn} ${sort === s.value ? styles.filterBtnActive : ''}`}
                      onClick={() => { setSort(s.value); setPage(1); }}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            {activeFilterCount > 0 && (
              <button className={styles.clearAllBtn} onClick={clearFilters}>
                <FiX /> Hapus Semua Filter
              </button>
            )}
          </div>
        )}

        {/* Results */}
        <div className={styles.resultsHeader}>
          <span className={styles.resultCount}>
            {loading ? 'Mencari...' : `${total} manga ditemukan`}
            {query && ` untuk "${query}"`}
          </span>
          {!showFilter && (
            <select
              value={sort}
              onChange={e => { setSort(e.target.value); setPage(1); }}
              className={styles.sortSelect}
            >
              {SORTS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
            </select>
          )}
        </div>

        <div className="grid-manga">
          {loading ? (
            Array(24).fill(0).map((_, i) => (
              <div key={i} className={`skeleton ${styles.cardSkeleton}`} />
            ))
          ) : manga.length === 0 ? (
            <div className={styles.empty}>
              <span>😔</span>
              <p>Tidak ada manga yang ditemukan</p>
              <button onClick={clearFilters}>Hapus Filter</button>
            </div>
          ) : (
            manga.map(m => <MangaCard key={m._id} manga={m} />)
          )}
        </div>

        {/* Pagination */}
        {!loading && total > 24 && (
          <div className={styles.pagination}>
            <button
              className={styles.pageBtn}
              disabled={page === 1}
              onClick={() => setPage(p => p - 1)}
            >
              ← Sebelumnya
            </button>
            <span className={styles.pageInfo}>Halaman {page} dari {Math.ceil(total / 24)}</span>
            <button
              className={styles.pageBtn}
              disabled={page >= Math.ceil(total / 24)}
              onClick={() => setPage(p => p + 1)}
            >
              Berikutnya →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

const mockManga = Array(24).fill(0).map((_, i) => ({
  _id: String(i), title: `Manga Title ${i + 1}`, slug: `manga-title-${i + 1}`,
  cover: `https://via.placeholder.com/200x300/16161f/e63946?text=Manga+${i + 1}`,
  rating: parseFloat((Math.random() * 2 + 7).toFixed(1)),
  totalChapters: Math.floor(Math.random() * 200 + 10),
  status: Math.random() > 0.5 ? 'ongoing' : 'completed',
  genres: ['Action', 'Fantasy'],
  latestChapter: { number: Math.floor(Math.random() * 200), createdAt: new Date() }
}));
