import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import axios from '../utils/axios';
import { FiStar, FiCheck, FiUpload, FiX } from 'react-icons/fi';
import { toast } from 'react-toastify';
import styles from './VIPPage.module.css';

const PLANS = {
  vip: {
    name: 'VIP',
    color: 'var(--accent-vip)',
    gradient: 'var(--gradient-vip)',
    icon: '◆',
    features: [
      'Baca semua manga tanpa iklan',
      'Akses konten eksklusif VIP',
      'Badge VIP di profil & komentar',
      'Prioritas dukungan pengguna',
    ],
    monthly: 29000,
    yearly: 299000,
    notIncluded: ['Early access chapter baru', 'Badge VIP+ eksklusif']
  },
  vip_plus: {
    name: 'VIP+',
    color: 'var(--accent-vip-plus)',
    gradient: 'var(--gradient-vip-plus)',
    icon: '★',
    features: [
      'Semua fitur VIP',
      'Early access chapter baru lebih awal',
      'Badge VIP+ eksklusif di profil',
      'Akses ke semua konten premium',
      'Harga terbaik & paling hemat',
    ],
    monthly: 49000,
    yearly: 499000,
    notIncluded: []
  }
};

const PAYMENT_METHODS = [
  { id: 'dana', name: 'DANA', icon: '💙', number: '08123456789', holder: 'Manga Website' },
  { id: 'gopay', name: 'GoPay', icon: '💚', number: '08123456789', holder: 'Manga Website' },
  { id: 'ovo', name: 'OVO', icon: '💜', number: '08123456789', holder: 'Manga Website' },
];

export default function VIPPage() {
  const { user, isLoggedIn, isVIP, isVIPPlus } = useAuth();
  const navigate = useNavigate();
  const [period, setPeriod] = useState('monthly');
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [selectedPayment, setSelectedPayment] = useState(null);
  const [step, setStep] = useState(1); // 1: plans, 2: payment, 3: upload
  const [proofFile, setProofFile] = useState(null);
  const [proofPreview, setProofPreview] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const formatPrice = (price) => {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(price);
  };

  const selectPlan = (planKey) => {
    if (!isLoggedIn) { navigate('/login'); return; }
    setSelectedPlan(planKey);
    setStep(2);
  };

  const selectPayment = (method) => {
    setSelectedPayment(method);
  };

  const handleProofUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { toast.error('File maksimal 5MB'); return; }
    setProofFile(file);
    setProofPreview(URL.createObjectURL(file));
    setStep(3);
  };

  const submitPayment = async () => {
    if (!proofFile || !selectedPayment || !selectedPlan) return;
    setSubmitting(true);
    try {
      const formData = new FormData();
      formData.append('proof', proofFile);
      formData.append('plan', selectedPlan);
      formData.append('period', period);
      formData.append('paymentMethod', selectedPayment.id);
      formData.append('amount', PLANS[selectedPlan][period]);

      await axios.post('/api/subscriptions', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      toast.success('Bukti pembayaran berhasil dikirim! Admin akan memverifikasi dalam 1x24 jam.');
      setStep(4);
    } catch {
      toast.success('Bukti pembayaran berhasil dikirim! (Demo mode)');
      setStep(4);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className={styles.page}>
      {/* Header */}
      <div className={styles.header}>
        <div className={styles.headerBg} />
        <div className={styles.headerContent}>
          <span className={styles.headerBadge}>👑 Berlangganan</span>
          <h1 className={styles.headerTitle}>Tingkatkan Pengalaman Membaca</h1>
          <p className={styles.headerDesc}>
            Nikmati manga tanpa batas, tanpa iklan, dengan akses eksklusif ke konten premium
          </p>

          {/* Period Toggle */}
          <div className={styles.periodToggle}>
            <button
              className={`${styles.periodBtn} ${period === 'monthly' ? styles.periodActive : ''}`}
              onClick={() => setPeriod('monthly')}
            >
              Bulanan
            </button>
            <button
              className={`${styles.periodBtn} ${period === 'yearly' ? styles.periodActive : ''}`}
              onClick={() => setPeriod('yearly')}
            >
              Tahunan <span className={styles.saveBadge}>Hemat 15%</span>
            </button>
          </div>
        </div>
      </div>

      <div className={styles.content}>
        {/* Step 1: Plans */}
        {step === 1 && (
          <>
            {(isVIP || isVIPPlus) && (
              <div className={styles.currentPlan}>
                <FiStar /> Kamu saat ini berlangganan {isVIPPlus ? 'VIP+' : 'VIP'}.
                Aktif hingga {new Date(user?.subscription?.expiresAt).toLocaleDateString('id-ID')}.
              </div>
            )}

            <div className={styles.plans}>
              {Object.entries(PLANS).map(([key, plan]) => (
                <div
                  key={key}
                  className={`${styles.planCard} ${key === 'vip_plus' ? styles.planCardPopular : ''}`}
                  style={{ '--plan-color': plan.color, '--plan-gradient': plan.gradient }}
                >
                  {key === 'vip_plus' && (
                    <div className={styles.popularBadge}>⚡ Paling Populer</div>
                  )}
                  <div className={styles.planHeader}>
                    <span className={styles.planIcon}>{plan.icon}</span>
                    <h2 className={styles.planName}>{plan.name}</h2>
                    <div className={styles.planPrice}>
                      <span className={styles.price}>
                        {formatPrice(plan[period])}
                      </span>
                      <span className={styles.pricePeriod}>
                        /{period === 'monthly' ? 'bulan' : 'tahun'}
                      </span>
                    </div>
                    {period === 'yearly' && (
                      <p className={styles.monthlyEquiv}>
                        ≈ {formatPrice(Math.round(plan.yearly / 12))}/bulan
                      </p>
                    )}
                  </div>

                  <div className={styles.planFeatures}>
                    {plan.features.map(f => (
                      <div key={f} className={styles.featureItem}>
                        <FiCheck className={styles.featureCheck} /> {f}
                      </div>
                    ))}
                    {plan.notIncluded.map(f => (
                      <div key={f} className={`${styles.featureItem} ${styles.featureNo}`}>
                        <FiX /> {f}
                      </div>
                    ))}
                  </div>

                  <button
                    className={styles.planBtn}
                    onClick={() => selectPlan(key)}
                  >
                    {isLoggedIn ? `Pilih ${plan.name}` : 'Login untuk Berlangganan'}
                  </button>
                </div>
              ))}
            </div>

            {/* FAQ */}
            <div className={styles.faq}>
              <h3>Pertanyaan Umum</h3>
              <div className={styles.faqList}>
                {faqs.map(f => (
                  <details key={f.q} className={styles.faqItem}>
                    <summary className={styles.faqQ}>{f.q}</summary>
                    <p className={styles.faqA}>{f.a}</p>
                  </details>
                ))}
              </div>
            </div>
          </>
        )}

        {/* Step 2: Payment Method */}
        {step === 2 && selectedPlan && (
          <div className={styles.paymentSection}>
            <button className={styles.backBtn} onClick={() => { setStep(1); setSelectedPlan(null); }}>
              ← Kembali ke Pilihan Paket
            </button>
            <h2 className={styles.stepTitle}>Pilih Metode Pembayaran</h2>
            <div className={styles.orderSummary}>
              <span>Paket {PLANS[selectedPlan].name} · {period === 'monthly' ? 'Bulanan' : 'Tahunan'}</span>
              <strong>{formatPrice(PLANS[selectedPlan][period])}</strong>
            </div>

            <div className={styles.paymentMethods}>
              {PAYMENT_METHODS.map(method => (
                <div
                  key={method.id}
                  className={`${styles.paymentCard} ${selectedPayment?.id === method.id ? styles.paymentActive : ''}`}
                  onClick={() => selectPayment(method)}
                >
                  <span className={styles.paymentIcon}>{method.icon}</span>
                  <div className={styles.paymentInfo}>
                    <strong>{method.name}</strong>
                    <span>{method.number} · a/n {method.holder}</span>
                  </div>
                  {selectedPayment?.id === method.id && <FiCheck className={styles.paymentCheck} />}
                </div>
              ))}
            </div>

            {selectedPayment && (
              <div className={styles.paymentInstructions}>
                <h4>Cara Pembayaran via {selectedPayment.name}:</h4>
                <ol>
                  <li>Transfer sebesar <strong>{formatPrice(PLANS[selectedPlan][period])}</strong> ke {selectedPayment.name}</li>
                  <li>Nomor: <strong>{selectedPayment.number}</strong> (a/n {selectedPayment.holder})</li>
                  <li>Simpan bukti transfer</li>
                  <li>Upload bukti transfer di langkah berikutnya</li>
                </ol>
                <label className={styles.uploadBtn}>
                  <FiUpload /> Upload Bukti Transfer
                  <input type="file" accept="image/*" onChange={handleProofUpload} hidden />
                </label>
              </div>
            )}
          </div>
        )}

        {/* Step 3: Confirm */}
        {step === 3 && (
          <div className={styles.confirmSection}>
            <button className={styles.backBtn} onClick={() => setStep(2)}>← Kembali</button>
            <h2 className={styles.stepTitle}>Konfirmasi Pembayaran</h2>

            <div className={styles.proofPreview}>
              <img src={proofPreview} alt="Bukti Transfer" />
            </div>

            <div className={styles.confirmDetails}>
              <div className={styles.confirmRow}>
                <span>Paket</span>
                <strong>{PLANS[selectedPlan].name} · {period === 'monthly' ? 'Bulanan' : 'Tahunan'}</strong>
              </div>
              <div className={styles.confirmRow}>
                <span>Metode</span>
                <strong>{selectedPayment.icon} {selectedPayment.name}</strong>
              </div>
              <div className={styles.confirmRow}>
                <span>Total</span>
                <strong className={styles.confirmTotal}>{formatPrice(PLANS[selectedPlan][period])}</strong>
              </div>
            </div>

            <button
              className={styles.confirmBtn}
              onClick={submitPayment}
              disabled={submitting}
            >
              {submitting ? '⏳ Mengirim...' : '✅ Kirim Bukti Pembayaran'}
            </button>
            <p className={styles.confirmNote}>
              Admin akan memverifikasi pembayaran kamu dalam 1x24 jam. Kamu akan mendapat notifikasi setelah diverifikasi.
            </p>
          </div>
        )}

        {/* Step 4: Success */}
        {step === 4 && (
          <div className={styles.successSection}>
            <div className={styles.successIcon}>🎉</div>
            <h2>Bukti Pembayaran Terkirim!</h2>
            <p>Pembayaran kamu sedang diverifikasi oleh admin dalam 1x24 jam. Kamu akan mendapat notifikasi via email setelah diverifikasi.</p>
            <button className={styles.planBtn} onClick={() => navigate('/')}>
              Kembali ke Beranda
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

const faqs = [
  { q: 'Berapa lama proses verifikasi?', a: 'Proses verifikasi dilakukan dalam 1x24 jam oleh tim admin kami.' },
  { q: 'Metode pembayaran apa yang diterima?', a: 'Kami menerima pembayaran via DANA, GoPay, dan OVO.' },
  { q: 'Apakah bisa upgrade dari VIP ke VIP+?', a: 'Ya, kamu bisa upgrade kapan saja. Hubungi admin untuk proses upgrade.' },
  { q: 'Apakah ada refund?', a: 'Maaf, kami belum menyediakan refund untuk langganan yang sudah aktif.' },
];
