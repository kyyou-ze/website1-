import React from 'react';

const SearchPage = () => {
  return (
    <div style={{ minHeight: 'calc(100vh - 70px)', marginTop: '70px', padding: '2rem' }}>
      <div className="container">
        <h1 style={{ fontSize: '2rem', marginBottom: '1rem' }}>SearchPage</h1>
        <p style={{ color: 'var(--text-secondary)' }}>This page is under construction.</p>
      </div>
    </div>
  );
};

export default SearchPage;
