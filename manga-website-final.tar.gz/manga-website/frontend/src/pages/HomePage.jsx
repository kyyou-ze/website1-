import React, { useEffect, useState } from 'react';
import Hero from '../components/home/Hero';
import MangaSection from '../components/home/MangaSection';
import './HomePage.css';

const HomePage = () => {
  const [loading, setLoading] = useState(true);
  const [featuredManga, setFeaturedManga] = useState([]);
  const [latestManga, setLatestManga] = useState([]);
  const [popularManga, setPopularManga] = useState([]);
  const [trendingManga, setTrendingManga] = useState([]);

  useEffect(() => {
    // TODO: Fetch data from API
    // For now, using dummy data
    setTimeout(() => {
      setFeaturedManga(getDummyFeatured());
      setLatestManga(getDummyManga(12));
      setPopularManga(getDummyManga(12));
      setTrendingManga(getDummyManga(6));
      setLoading(false);
    }, 1000);
  }, []);

  if (loading) {
    return <div className="page-loading">Loading...</div>;
  }

  return (
    <div className="homepage">
      <Hero featuredManga={featuredManga} />
      
      <div className="container">
        {/* Latest Updates */}
        <MangaSection
          title="Update Terbaru"
          subtitle="Manga yang baru saja diupdate"
          manga={latestManga}
          viewAllLink="/latest"
          variant="grid"
          columns={6}
        />

        {/* Trending */}
        <MangaSection
          title="Sedang Trending 🔥"
          subtitle="Manga paling banyak dibaca minggu ini"
          manga={trendingManga}
          viewAllLink="/trending"
          variant="grid"
          columns={6}
        />

        {/* Popular */}
        <MangaSection
          title="Paling Populer"
          subtitle="Manga dengan rating tertinggi"
          manga={popularManga}
          viewAllLink="/popular"
          variant="grid"
          columns={6}
        />
      </div>
    </div>
  );
};

// Dummy data generators
const getDummyFeatured = () => {
  return [
    {
      id: 1,
      title: 'Jujutsu Kaisen',
      description: 'Yuji Itadori, seorang siswa SMA dengan kemampuan fisik luar biasa, bergabung dengan sekolah sihir untuk melawan kutukan yang mengancam umat manusia.',
      coverImage: 'https://images.unsplash.com/photo-1618336753974-aae8e04506aa?w=1200&h=600&fit=crop',
      rating: 4.8,
      genres: ['Action', 'Supernatural', 'School'],
      chapters: 245,
      status: 'Ongoing'
    },
    {
      id: 2,
      title: 'One Piece',
      description: 'Monkey D. Luffy dan kru bajak lautnya menjelajahi Grand Line untuk menemukan harta karun legendaris One Piece dan menjadi Raja Bajak Laut.',
      coverImage: 'https://images.unsplash.com/photo-1612036782180-6f0b6cd846fe?w=1200&h=600&fit=crop',
      rating: 4.9,
      genres: ['Adventure', 'Fantasy', 'Comedy'],
      chapters: 1098,
      status: 'Ongoing'
    },
    {
      id: 3,
      title: 'Attack on Titan',
      description: 'Dalam dunia yang dikuasai Titan pemakan manusia, Eren Yeager bersumpah untuk membasmi mereka semua setelah kehilangan segalanya.',
      coverImage: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=1200&h=600&fit=crop',
      rating: 4.7,
      genres: ['Action', 'Dark Fantasy', 'Military'],
      chapters: 139,
      status: 'Completed'
    }
  ];
};

const getDummyManga = (count) => {
  const titles = [
    'Chainsaw Man', 'Demon Slayer', 'My Hero Academia', 'Tokyo Ghoul',
    'Death Note', 'Naruto', 'Bleach', 'Hunter x Hunter', 'Fullmetal Alchemist',
    'Spy x Family', 'Blue Lock', 'Kaiju No. 8', 'One Punch Man', 'Berserk',
    'Vagabond', 'Vinland Saga', 'Kingdom', 'Solo Leveling'
  ];

  const genres = [
    ['Action', 'Supernatural'],
    ['Adventure', 'Fantasy'],
    ['Thriller', 'Mystery'],
    ['Romance', 'Comedy'],
    ['Horror', 'Psychological']
  ];

  const statuses = ['Ongoing', 'Completed', 'Hiatus'];

  return Array.from({ length: count }, (_, i) => ({
    id: i + 100,
    title: titles[i % titles.length],
    coverImage: `https://picsum.photos/seed/${i}/300/400`,
    rating: (4 + Math.random()).toFixed(1),
    genres: genres[i % genres.length],
    chapters: Math.floor(Math.random() * 200) + 50,
    status: statuses[i % statuses.length],
    views: Math.floor(Math.random() * 1000000),
    latestChapter: Math.floor(Math.random() * 200) + 50,
    lastUpdated: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
    isNew: i < 3,
    isVIPOnly: i % 5 === 0,
    isBookmarked: false,
    isFavorited: false
  }));
};

export default HomePage;
