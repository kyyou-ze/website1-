import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from '../utils/axios';
import { useAuth } from '../context/AuthContext';
import MangaCard from '../components/manga/MangaCard';
import { FiEdit2, FiBookmark, FiHeart, FiClock, FiStar } from 'react-icons/fi';
import { toast } from 'react-toastify';
import dayjs from 'dayjs';

export default function ProfilePage() {
  const { username } = useParams();
  const { user: currentUser, updateUser } = useAuth();
  const [profile, setProfile] = useState(null);
  const [activeTab, setActiveTab] = useState('bookmarks');
  const [bookmarks, setBookmarks] = useState([]);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [editName, setEditName] = useState('');
  const isOwnProfile = currentUser?.username === username;

  useEffect(() => {
    const fetch = async () => {
      try {
        const [profileRes, bmRes] = await Promise.all([
          axios.get(`/api/users/${username}`),
          axios.get('/api/user/bookmarks')
        ]);
        setProfile(profileRes.data.user || mockProfile);
        setBookmarks(bmRes.data.bookmarks || []);
        setEditName(profileRes.data.user?.name || '');
      } catch { setProfile(mockProfile); setEditName(mockProfile.name); } finally { setLoading(false); }
    };
    fetch();
  }, [username]);

  const saveProfile = async () => {
    try {
      await axios.put('/api/user/profile', { name: editName });
      updateUser({ name: editName });
      setProfile(prev => ({ ...prev, name: editName }));
      setEditing(false);
      toast.success('Profil diperbarui!');
    } catch { toast.error('Gagal menyimpan'); }
  };

  if (loading) return <div style={{ minHeight: '100vh', paddingTop: 100, textAlign: 'center', color: 'var(--text-muted)' }}>Memuat profil...</div>;
  if (!profile) return <div style={{ minHeight: '100vh', paddingTop: 100, textAlign: 'center', color: 'var(--text-muted)' }}>Pengguna tidak ditemukan</div>;

  const isVIP = profile.subscription?.tier === 'vip' || profile.subscription?.tier === 'vip_plus';
  const isVIPPlus = profile.subscription?.tier === 'vip_plus';

  return (
    <div style={{ minHeight: '100vh', paddingTop: '64px' }}>
      {/* Header */}
      <div style={{ background: 'var(--bg-secondary)', borderBottom: '1px solid var(--border-color)', padding: '40px 24px' }}>
        <div style={{ maxWidth: 900, margin: '0 auto', display: 'flex', gap: 24, alignItems: 'center' }}>
          <div style={{ position: 'relative' }}>
            <img src={profile.avatar || `https://ui-avatars.com/api/?name=${profile.name}&background=e63946&color=fff&size=80`}
              alt={profile.name} style={{ width: 80, height: 80, borderRadius: '50%', border: '3px solid var(--border-color)' }} />
            {(isVIP || isVIPPlus) && (
              <span style={{ position: 'absolute', bottom: 0, right: 0, background: isVIPPlus ? 'var(--gradient-vip-plus)' : 'var(--gradient-vip)', color: 'white', fontSize: 10, padding: '1px 6px', borderRadius: 4, fontWeight: 700 }}>
                {isVIPPlus ? 'VIP+' : 'VIP'}
              </span>
            )}
          </div>
          <div style={{ flex: 1 }}>
            {editing ? (
              <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
                <input value={editName} onChange={e => setEditName(e.target.value)} style={{ padding: '6px 12px', background: 'var(--bg-elevated)', border: '1px solid var(--border-color)', borderRadius: 6, color: 'var(--text-primary)', fontSize: 18, fontWeight: 700, width: 200 }} />
                <button onClick={saveProfile} style={{ padding: '6px 14px', background: 'var(--gradient-primary)', color: 'white', border: 'none', borderRadius: 6, cursor: 'pointer' }}>Simpan</button>
                <button onClick={() => setEditing(false)} style={{ padding: '6px 14px', background: 'transparent', border: '1px solid var(--border-color)', borderRadius: 6, color: 'var(--text-secondary)', cursor: 'pointer' }}>Batal</button>
              </div>
            ) : (
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                <h1 style={{ fontSize: 24, fontFamily: 'Noto Sans, sans-serif' }}>{profile.name}</h1>
                {isOwnProfile && <button onClick={() => setEditing(true)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: 16 }}><FiEdit2 /></button>}
              </div>
            )}
            <p style={{ color: 'var(--text-muted)', fontSize: 13, marginBottom: 12 }}>@{profile.username} · Bergabung {dayjs(profile.createdAt).format('MMMM YYYY')}</p>
            <div style={{ display: 'flex', gap: 24, fontSize: 14 }}>
              <span><strong style={{ color: 'var(--text-primary)' }}>{profile.bookmarkCount || 0}</strong> <span style={{ color: 'var(--text-muted)' }}>Bookmark</span></span>
              <span><strong style={{ color: 'var(--text-primary)' }}>{profile.favoriteCount || 0}</strong> <span style={{ color: 'var(--text-muted)' }}>Favorit</span></span>
              <span><strong style={{ color: 'var(--text-primary)' }}>{profile.readCount || 0}</strong> <span style={{ color: 'var(--text-muted)' }}>Dibaca</span></span>
            </div>
          </div>
          {isOwnProfile && !isVIP && (
            <Link to="/vip" style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 16px', background: 'var(--gradient-vip)', color: 'white', borderRadius: 8, fontSize: 13, fontWeight: 700, textDecoration: 'none' }}>
              <FiStar /> Upgrade VIP
            </Link>
          )}
        </div>
      </div>

      <div style={{ maxWidth: 900, margin: '0 auto', padding: '32px 24px 60px' }}>
        {isOwnProfile && (
          <>
            <div style={{ display: 'flex', gap: 4, borderBottom: '1px solid var(--border-color)', marginBottom: 24 }}>
              {[{ v: 'bookmarks', l: 'Bookmark', i: <FiBookmark /> }, { v: 'history', l: 'Riwayat', i: <FiClock /> }].map(t => (
                <button key={t.v} onClick={() => setActiveTab(t.v)}
                  style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '10px 20px', background: 'transparent', border: 'none', borderBottom: `2px solid ${activeTab === t.v ? 'var(--accent-primary)' : 'transparent'}`, color: activeTab === t.v ? 'var(--accent-primary)' : 'var(--text-secondary)', fontSize: 14, fontWeight: 500, cursor: 'pointer', marginBottom: -1 }}>
                  {t.i} {t.l}
                </button>
              ))}
            </div>
            {activeTab === 'bookmarks' && (
              bookmarks.length === 0 ? <p style={{ color: 'var(--text-muted)', textAlign: 'center', padding: 40 }}>Belum ada bookmark</p> :
              <div className="grid-manga">{bookmarks.map(m => <MangaCard key={m._id} manga={m} />)}</div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

const mockProfile = { _id: '1', name: 'Budi Santoso', username: 'budisantoso', avatar: null, subscription: { tier: 'vip' }, createdAt: new Date('2023-01-15'), bookmarkCount: 42, favoriteCount: 18, readCount: 367 };
